<?php

namespace Formedex\SecondaryBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * NewsCategory
 *
 * @ORM\Table(name="category")
 * @ORM\Entity
 */
class Category
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Institution")
     * @ORM\JoinColumn(name="institution", referencedColumnName="id")
     */
    private $institution;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return NewsCategory
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Get institution
     *
     * @return string 
     */
    public function getInstitution()
    {
        return $this->institution;
    }

    /**
     * Set institution
     *
     * @param \Formedex\UserBundle\Entity\Institution $institution
     * @return News
     */
    public function setInstitution(\Formedex\UserBundle\Entity\Institution $institution = null)
    {
        $this->institution = $institution;
        return $this;
    }


    public function __toString()
    {
        if(isset($this->id))
        {
            return (string) $this->id;
        }

        return '';
    }
}
