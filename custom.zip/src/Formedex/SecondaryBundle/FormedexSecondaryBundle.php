<?php

namespace Formedex\SecondaryBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FormedexSecondaryBundle extends Bundle
{
}
