<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Term
 *
 * @ORM\Table(name="scoreitems")
 * @ORM\Entity
 */
class Scoreitem
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="item_name", type="string", length=255)
     */
    private $itemName;

    /**
     * @var string
     *
     * @ORM\Column(name="item_description", type="text")
     */
    private $itemDescription;

    /**
     * @var string
     *
     * @ORM\Column(name="mini_value", type="string", length=255)
     */
    private $miniValue;


    /**
     * @var string
     *
     * @ORM\Column(name="max_value",type="string", length=255)
     */
    private $maxValue;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Classroom")
     * @ORM\JoinColumn(name="class", referencedColumnName="id")
     */
    private $class;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set itemName
     *
     * @param string $itemName
     * @return Scoreitem
     */
    public function setItemName($itemName)
    {
        $this->itemName = $itemName;

        return $this;
    }

    /**
     * Get itemName
     *
     * @return string 
     */
    public function getItemName()
    {
        return $this->itemName;
    }

    /**
     * Set itemDescription
     *
     * @param string $itemDescription
     * @return Scoreitem
     */
    public function setItemDescription($itemDescription)
    {
        $this->itemDescription = $itemDescription;

        return $this;
    }

    /**
     * Get itemDescription
     *
     * @return string 
     */
    public function getItemDescription()
    {
        return $this->itemDescription;
    }

    /**
     * Set miniValue
     *
     * @param string $miniValue
     * @return Scoreitem
     */
    public function setMiniValue($miniValue)
    {
        $this->miniValue = $miniValue;

        return $this;
    }

    /**
     * Get miniValue
     *
     * @return string 
     */
    public function getMiniValue()
    {
        return $this->miniValue;
    }

    /**
     * Set maxValue
     *
     * @param string $maxValue
     * @return Scoreitem
     */
    public function setMaxValue($maxValue)
    {
        $this->maxValue = $maxValue;

        return $this;
    }

    /**
     * Get maxValue
     *
     * @return string 
     */
    public function getMaxValue()
    {
        return $this->maxValue;
    }

    /**
     * Set class
     *
     * @param \Formedex\UserBundle\Entity\Classroom $class
     * @return Scoreitem
     */
    public function setClass(\Formedex\UserBundle\Entity\Classroom $class = null)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return \Formedex\UserBundle\Entity\Classroom 
     */
    public function getClass()
    {
        return $this->class;
    }


    public function __toString(){
        if(isset($this->itemName)){
            return $this->itemName;
        }
        return '';
    }
}
