<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * institution
 *
 * @ORM\Table(name="institution")
 * @ORM\Entity
 */
class Institution
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255)
     */
    private $code;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="logo", type="string", length=255)
     */
    private $logo;

    /**
     * @var string
     *
     * @ORM\Column(name="address", type="text")
     */
    private $address;

    /**
     * @var string
     *
     * @ORM\Column(name="location", type="string", length=255)
     */
    private $location;

    /**
     * @var string
     *
     * @ORM\Column(name="year_started", type="string", length=255)
     */
    private $year_started;

    /**
     * @var string
     *
     * @ORM\Column(name="url", type="string", length=255)
     */
    private $url;

    /**
     * @var string
     *
     * @ORM\Column(name="display_name", type="string", length=255)
     */
    private $display_name;

    /**
     * @var string
     *
     * @ORM\Column(name="motto", type="string", length=255)
     */
    private $motto;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Level")
     * @ORM\JoinColumn(name="level", referencedColumnName="id")
     */
    private $level;


    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    protected $image;
    
    /**
     * @ORM\ManyToMany(targetEntity="Formedex\UserBundle\Entity\Course", inversedBy="institutions")
     * 
     */
    protected $courses;

     /**
     * Constructor
     */
    public function __construct()
    {
        $this->courses = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return institution
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return institution
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set logo
     *
     * @param string $logo
     * @return institution
     */
    public function setLogo($logo)
    {
        $this->logo = $logo;

        return $this;
    }

    /**
     * Get logo
     *
     * @return string 
     */
    public function getLogo()
    {
        return $this->logo;
    }

    /**
     * Set level
     *
     * @param \Formedex\UserBundle\Entity\Level $level
     * @return Level
     */
    public function setLevel(\Formedex\UserBundle\Entity\Level $level = null)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return string 
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Get courses
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCourses()
    {
        return $this->courses;
    }

    /**
     * Add courses
     *
     * @param \Formedex\UserBundle\Entity\Course
     * @return courses
     */
    public function addCourses(\Formedex\UserBundle\Entity\Course $courses)
    {
        $this->courses[] = $courses;    
        return $this;
    }

    /**
     * Remove courses
     *
     * @param \Formedex\UserBundle\Entity\Course $sportStatGroups
     */
    public function removeCourses(\Formedex\UserBundle\Entity\Course $courses)
    {
        $this->courses->removeElement($courses);
    }

    

    /**
     * Set image
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $image
     * @return User
     */
    public function setImage(\Application\Sonata\MediaBundle\Entity\Media $image = null)
    {
        $this->image = $image;
    
        return $this;
    }

    /**
     * Get image
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getImage()
    {
        return $this->image;
    }  

    /**
     * Set code
     *
     * @param string $code
     * @return Institution
     */
    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    /**
     * Get code
     *
     * @return string 
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * Set address
     *
     * @param string $address
     * @return Institution
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address
     *
     * @return string 
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set location
     *
     * @param string $location
     * @return Institution
     */
    public function setLocation($location)
    {
        $this->location = $location;

        return $this;
    }

    /**
     * Get location
     *
     * @return string 
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set year_started
     *
     * @param string $yearStarted
     * @return Institution
     */
    public function setYearStarted($yearStarted)
    {
        $this->year_started = $yearStarted;

        return $this;
    }

    /**
     * Get year_started
     *
     * @return string 
     */
    public function getYearStarted()
    {
        return $this->year_started;
    }

    /**
     * Set url
     *
     * @param string $url
     * @return Institution
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     * Get url
     *
     * @return string 
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * Set display_name
     *
     * @param string $displayName
     * @return Institution
     */
    public function setDisplayName($displayName)
    {
        $this->display_name = $displayName;

        return $this;
    }

    /**
     * Get display_name
     *
     * @return string 
     */
    public function getDisplayName()
    {
        return $this->display_name;
    }

    /**
     * Set motto
     *
     * @param string $motto
     * @return Institution
     */
    public function setMotto($motto)
    {
        $this->motto = $motto;

        return $this;
    }

    /**
     * Get motto
     *
     * @return string 
     */
    public function getMotto()
    {
        return $this->motto;
    }

    /**
     * Add courses
     *
     * @param \Formedex\UserBundle\Entity\Course $courses
     * @return Institution
     */
    public function addCourse(\Formedex\UserBundle\Entity\Course $courses)
    {
        $this->courses[] = $courses;

        return $this;
    }

    /**
     * Remove courses
     *
     * @param \Formedex\UserBundle\Entity\Course $courses
     */
    public function removeCourse(\Formedex\UserBundle\Entity\Course $courses)
    {
        $this->courses->removeElement($courses);
    }

    public function __toString(){
        if(isset($this->name)){
            return $this->code."-".$this->name;
        }
        return '';
    }
}
