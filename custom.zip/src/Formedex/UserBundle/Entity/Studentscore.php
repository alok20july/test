<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Term
 *
 * @ORM\Table(name="studentscore")
 * @ORM\Entity
 */
class Studentscore
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;   

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Classroom")
     * @ORM\JoinColumn(name="class", referencedColumnName="id")
     */
    private $class;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Subject")
     * @ORM\JoinColumn(name="subject", referencedColumnName="id")
     */
    private $subject;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Scoreitem")
     * @ORM\JoinColumn(name="scoreitem", referencedColumnName="id")
     */
    private $scoreitem;

    /**
     * @ORM\OneToOne(targetEntity="Formedex\UserBundle\Entity\Student")
     * @ORM\JoinColumn(name="student", referencedColumnName="id")
     */
    private $student;

    /**
     * @var string
     *
     * @ORM\Column(name="student_score",  type="string", length=255)
     */
    private $studentScore;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set studentScore
     *
     * @param string $studentScore
     * @return Studentscore
     */
    public function setStudentScore($studentScore)
    {
        $this->studentScore = $studentScore;

        return $this;
    }

    /**
     * Get studentScore
     *
     * @return string 
     */
    public function getStudentScore()
    {
        return $this->studentScore;
    }

    /**
     * Set class
     *
     * @param \Formedex\UserBundle\Entity\Classroom $class
     * @return Studentscore
     */
    public function setClass(\Formedex\UserBundle\Entity\Classroom $class = null)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return \Formedex\UserBundle\Entity\Classroom 
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * Set subject
     *
     * @param \Formedex\UserBundle\Entity\Subject $subject
     * @return Studentscore
     */
    public function setSubject(\Formedex\UserBundle\Entity\Subject $subject = null)
    {
        $this->subject = $subject;

        return $this;
    }

    /**
     * Get subject
     *
     * @return \Formedex\UserBundle\Entity\Subject 
     */
    public function getSubject()
    {
        return $this->subject;
    }

    /**
     * Set scoreitem
     *
     * @param \Formedex\UserBundle\Entity\Scoreitem $scoreitem
     * @return Studentscore
     */
    public function setScoreitem(\Formedex\UserBundle\Entity\Scoreitem $scoreitem = null)
    {
        $this->scoreitem = $scoreitem;

        return $this;
    }

    /**
     * Get scoreitem
     *
     * @return \Formedex\UserBundle\Entity\Scoreitem 
     */
    public function getScoreitem()
    {
        return $this->scoreitem;
    }

    /**
     * Set student
     *
     * @param \Formedex\UserBundle\Entity\Student $student
     * @return Studentscore
     */
    public function setStudent(\Formedex\UserBundle\Entity\Student $student = null)
    {
        $this->student = $student;

        return $this;
    }

    /**
     * Get student
     *
     * @return \Formedex\UserBundle\Entity\Student 
     */
    public function getStudent()
    {
        return $this->student;
    }
}
