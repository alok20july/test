<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Term
 *
 * @ORM\Table(name="gradescales")
 * @ORM\Entity
 */
class Gradescale
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Classroom")
     * @ORM\JoinColumn(name="class", referencedColumnName="id")
     */
    private $class;

    /**
     * @var string
     *
     * @ORM\Column(name="grade",  type="string", length=255)
     */
    private $grade;

    /**
     * @var string
     *
     * @ORM\Column(name="lower_bound", type="string", length=255)
     */
    private $lowerBound;

    /**
     * @var string
     *
     * @ORM\Column(name="upper_bound",type="string", length=255)
     */
    private $upperBound;

    /**
     * @var string
     *
     * @ORM\Column(name="grade_point",type="string", length=255)
     */
    private $gradePoint;

    /**
     * @var string
     *
     * @ORM\Column(name="remark",type="string", length=255)
     */
    private $remark;   

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set grade
     *
     * @param string $grade
     * @return Gradescale
     */
    public function setGrade($grade)
    {
        $this->grade = $grade;

        return $this;
    }

    /**
     * Get grade
     *
     * @return string 
     */
    public function getGrade()
    {
        return $this->grade;
    }

    /**
     * Set lowerBound
     *
     * @param string $lowerBound
     * @return Gradescale
     */
    public function setLowerBound($lowerBound)
    {
        $this->lowerBound = $lowerBound;

        return $this;
    }

    /**
     * Get lowerBound
     *
     * @return string 
     */
    public function getLowerBound()
    {
        return $this->lowerBound;
    }

    /**
     * Set upperBound
     *
     * @param string $upperBound
     * @return Gradescale
     */
    public function setUpperBound($upperBound)
    {
        $this->upperBound = $upperBound;

        return $this;
    }

    /**
     * Get upperBound
     *
     * @return string 
     */
    public function getUpperBound()
    {
        return $this->upperBound;
    }

    /**
     * Set gradePoint
     *
     * @param string $gradePoint
     * @return Gradescale
     */
    public function setGradePoint($gradePoint)
    {
        $this->gradePoint = $gradePoint;

        return $this;
    }

    /**
     * Get gradePoint
     *
     * @return string 
     */
    public function getGradePoint()
    {
        return $this->gradePoint;
    }

    /**
     * Set remark
     *
     * @param string $remark
     * @return Gradescale
     */
    public function setRemark($remark)
    {
        $this->remark = $remark;

        return $this;
    }

    /**
     * Get remark
     *
     * @return string 
     */
    public function getRemark()
    {
        return $this->remark;
    }

    /**
     * Set class
     *
     * @param \Formedex\UserBundle\Entity\Classroom $class
     * @return Gradescale
     */
    public function setClass(\Formedex\UserBundle\Entity\Classroom $class = null)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return \Formedex\UserBundle\Entity\Classroom 
     */
    public function getClass()
    {
        return $this->class;
    }
}
