<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Level
 *
 * @ORM\Table(name="activityarea")
 * @ORM\Entity
 */
class Activityarea
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Activitygroup")
     * @ORM\JoinColumn(name="activitygroup", referencedColumnName="id")
     */
    private $activitygroup;

     /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Classroom")
     * @ORM\JoinColumn(name="class", referencedColumnName="id")
     */
    private $class;

    /**
     * @var string
     *
     * @ORM\Column(name="area", type="string", length=255)
     */
    private $area;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description; 

    /**
     * @var string
     *
     * @ORM\Column(name="min_score", type="string", length=255)
     */
    private $minScore;

    /**
     * @var string
     *
     * @ORM\Column(name="max_score", type="string", length=255)
     */
    private $maxScore;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set area
     *
     * @param string $area
     * @return Activityarea
     */
    public function setArea($area)
    {
        $this->area = $area;

        return $this;
    }

    /**
     * Get area
     *
     * @return string 
     */
    public function getArea()
    {
        return $this->area;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Activityarea
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set minScore
     *
     * @param string $minScore
     * @return Activityarea
     */
    public function setMinScore($minScore)
    {
        $this->minScore = $minScore;

        return $this;
    }

    /**
     * Get minScore
     *
     * @return string 
     */
    public function getMinScore()
    {
        return $this->minScore;
    }

    /**
     * Set maxScore
     *
     * @param string $maxScore
     * @return Activityarea
     */
    public function setMaxScore($maxScore)
    {
        $this->maxScore = $maxScore;

        return $this;
    }

    /**
     * Get maxScore
     *
     * @return string 
     */
    public function getMaxScore()
    {
        return $this->maxScore;
    }

    /**
     * Set activitygroup
     *
     * @param \Formedex\UserBundle\Entity\Activitygroup $activitygroup
     * @return Activityarea
     */
    public function setActivitygroup(\Formedex\UserBundle\Entity\Activitygroup $activitygroup = null)
    {
        $this->activitygroup = $activitygroup;

        return $this;
    }

    /**
     * Get activitygroup
     *
     * @return \Formedex\UserBundle\Entity\Activitygroup 
     */
    public function getActivitygroup()
    {
        return $this->activitygroup;
    }

    /**
     * Set class
     *
     * @param \Formedex\UserBundle\Entity\Classroom $class
     * @return Activityarea
     */
    public function setClass(\Formedex\UserBundle\Entity\Classroom $class = null)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return \Formedex\UserBundle\Entity\Classroom 
     */
    public function getClass()
    {
        return $this->class;
    }

    public function __toString(){
        if(isset($this->area)){
            return $this->area;
        }
        return '';
    }

}
