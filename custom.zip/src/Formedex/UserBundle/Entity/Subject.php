<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Subject
 *
 * @ORM\Table(name="subject")
 * @ORM\Entity
 */
class Subject
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description;

    /**
     * @ORM\ManyToMany(targetEntity="Formedex\UserBundle\Entity\Course",  mappedBy="subjects")
     * 
     */
    protected $courses;

     /**
     * @ORM\ManyToMany(targetEntity="Formedex\UserBundle\Entity\Classroom",  mappedBy="subjects")
     * 
     */
    protected $classes;

     /**
     * Constructor
     */
    public function __construct()
    {
        $this->courses = new \Doctrine\Common\Collections\ArrayCollection();
        $this->classes = new \Doctrine\Common\Collections\ArrayCollection();
    }


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Subject
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Subject
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Get courses
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCourses()
    {
        return $this->courses;
    }

    /**
     * Add courses
     *
     * @param \Formedex\UserBundle\Entity\Course
     * @return courses
     */
    public function addCourses(\Formedex\UserBundle\Entity\Course $courses)
    {
        $this->courses[] = $courses;    
        return $this;
    }

    /**
     * Remove courses
     *
     * @param \Formedex\UserBundle\Entity\Course $sportStatGroups
     */
    public function removeCourses(\Formedex\UserBundle\Entity\Course $courses)
    {
        $this->courses->removeElement($courses);
    }

    public function __toString(){
        if(isset($this->name)){
            return $this->name;
        }
        return '';
    }

    /**
     * Add courses
     *
     * @param \Formedex\UserBundle\Entity\Course $courses
     * @return Subject
     */
    public function addCourse(\Formedex\UserBundle\Entity\Course $courses)
    {
        $this->courses[] = $courses;

        return $this;
    }

    /**
     * Remove courses
     *
     * @param \Formedex\UserBundle\Entity\Course $courses
     */
    public function removeCourse(\Formedex\UserBundle\Entity\Course $courses)
    {
        $this->courses->removeElement($courses);
    }

    /**
     * Add classes
     *
     * @param \Formedex\UserBundle\Entity\Classroom $classes
     * @return Subject
     */
    public function addClass(\Formedex\UserBundle\Entity\Classroom $classes)
    {
        $this->classes[] = $classes;

        return $this;
    }

    /**
     * Remove classes
     *
     * @param \Formedex\UserBundle\Entity\Classroom $classes
     */
    public function removeClass(\Formedex\UserBundle\Entity\Classroom $classes)
    {
        $this->classes->removeElement($classes);
    }

    /**
     * Get classes
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getClasses()
    {
        return $this->classes;
    }
}
