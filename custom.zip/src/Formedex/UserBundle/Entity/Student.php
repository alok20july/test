<?php

namespace Formedex\UserBundle\Entity;
use Application\Sonata\MediaBundle\Entity\Gallery;
use Doctrine\Common\Collections\ArrayCollection;
use Sonata\UserBundle\Entity\BaseUser;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="students")
 */
class Student
{


    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\OneToOne(targetEntity="User", mappedBy="student", cascade={"persist"})
     * @ORM\JoinColumn(name="user", referencedColumnName="id")
     */
    private $user;

    /**
     * @var string
     *
     * @ORM\Column(name="other_name", type="string", length=255)
     */
    private $otherName;

    /**
     * @var string
     *
     * @ORM\Column(name="dob", type="date")
     */
    private $dob;

    /**
     * @var string
     *
     * @ORM\Column(name="state_of_origin",  type="string", length=255)
     */
    private $stateOfOrigin;

     /**
     * @var string
     *
     * @ORM\Column(name="lga_of_origin",  type="string", length=255)
     */
    private $lgaOfOrigin;

    /**
     * @var string
     *
     * @ORM\Column(name="address", type="string", length=255)
     */
    private $address;

     /**
     * @var string
     *
     * @ORM\Column(name="registration_number", type="string", length=255)
     */
    private $registrationNumber;

     /**
     * @var string
     *
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Session")
     * @ORM\JoinColumn(name="session_admitted", referencedColumnName="id")
     */
    private $sessionAdmitted;

    /**
     * @var string
     *
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Classroom")
     * @ORM\JoinColumn(name="current_class", referencedColumnName="id")
     */
    private $currentClass;

    /**
     * @var string
     *
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Classroom")
     * @ORM\JoinColumn(name="next_class", referencedColumnName="id")
     */
    private $nextClass;

    /**
     * @var string
     *
     * @ORM\Column(name="designation", type="string", length=255)
     */
    private $designation;

    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    protected $passportImage;

    /**
     * @ORM\ManyToMany(targetEntity="Formedex\UserBundle\Entity\Subject", inversedBy="staff")
     * 
     */
    protected $subjects;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set otherName
     *
     * @param string $otherName
     * @return Student
     */
    public function setOtherName($otherName)
    {
        $this->otherName = $otherName;

        return $this;
    }

    /**
     * Get otherName
     *
     * @return string 
     */
    public function getOtherName()
    {
        return $this->otherName;
    }

    /**
     * Set dob
     *
     * @param \DateTime $dob
     * @return Student
     */
    public function setDob($dob)
    {
        $this->dob = $dob;

        return $this;
    }

    /**
     * Get dob
     *
     * @return \DateTime 
     */
    public function getDob()
    {
        return $this->dob;
    }

    /**
     * Set stateOfOrigin
     *
     * @param string $stateOfOrigin
     * @return Student
     */
    public function setStateOfOrigin($stateOfOrigin)
    {
        $this->stateOfOrigin = $stateOfOrigin;

        return $this;
    }

    /**
     * Get stateOfOrigin
     *
     * @return string 
     */
    public function getStateOfOrigin()
    {
        return $this->stateOfOrigin;
    }

    /**
     * Set lgaOfOrigin
     *
     * @param string $lgaOfOrigin
     * @return Student
     */
    public function setLgaOfOrigin($lgaOfOrigin)
    {
        $this->lgaOfOrigin = $lgaOfOrigin;

        return $this;
    }

    /**
     * Get lgaOfOrigin
     *
     * @return string 
     */
    public function getLgaOfOrigin()
    {
        return $this->lgaOfOrigin;
    }

    /**
     * Set address
     *
     * @param string $address
     * @return Student
     */
    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    /**
     * Get address
     *
     * @return string 
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set registrationNumber
     *
     * @param string $registrationNumber
     * @return Student
     */
    public function setRegistrationNumber($registrationNumber)
    {
        $this->registrationNumber = $registrationNumber;

        return $this;
    }

    /**
     * Get registrationNumber
     *
     * @return string 
     */
    public function getRegistrationNumber()
    {
        return $this->registrationNumber;
    }

    /**
     * Set designation
     *
     * @param string $designation
     * @return Student
     */
    public function setDesignation($designation)
    {
        $this->designation = $designation;

        return $this;
    }

    /**
     * Get designation
     *
     * @return string 
     */
    public function getDesignation()
    {
        return $this->designation;
    }

    /**
     * Set user
     *
     * @param \Formedex\UserBundle\Entity\User $user
     * @return Student
     */
    public function setUser(\Formedex\UserBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Formedex\UserBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set sessionAdmitted
     *
     * @param \Formedex\UserBundle\Entity\Session $sessionAdmitted
     * @return Student
     */
    public function setSessionAdmitted(\Formedex\UserBundle\Entity\Session $sessionAdmitted = null)
    {
        $this->sessionAdmitted = $sessionAdmitted;

        return $this;
    }

    /**
     * Get sessionAdmitted
     *
     * @return \Formedex\UserBundle\Entity\Session 
     */
    public function getSessionAdmitted()
    {
        return $this->sessionAdmitted;
    }

    /**
     * Set currentClass
     *
     * @param \Formedex\UserBundle\Entity\Classroom $currentClass
     * @return Student
     */
    public function setCurrentClass(\Formedex\UserBundle\Entity\Classroom $currentClass = null)
    {
        $this->currentClass = $currentClass;

        return $this;
    }

    /**
     * Get currentClass
     *
     * @return \Formedex\UserBundle\Entity\Classroom 
     */
    public function getCurrentClass()
    {
        return $this->currentClass;
    }

    /**
     * Set nextClass
     *
     * @param \Formedex\UserBundle\Entity\Classroom $nextClass
     * @return Student
     */
    public function setNextClass(\Formedex\UserBundle\Entity\Classroom $nextClass = null)
    {
        $this->nextClass = $nextClass;

        return $this;
    }

    /**
     * Get nextClass
     *
     * @return \Formedex\UserBundle\Entity\Classroom 
     */
    public function getNextClass()
    {
        return $this->nextClass;
    }

    /**
     * Set passportImage
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $passportImage
     * @return Student
     */
    public function setPassportImage(\Application\Sonata\MediaBundle\Entity\Media $passportImage = null)
    {
        $this->passportImage = $passportImage;

        return $this;
    }

    /**
     * Get passportImage
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getPassportImage()
    {
        return $this->passportImage;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->subjects = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add subjects
     *
     * @param \Formedex\UserBundle\Entity\Subject $subjects
     * @return Student
     */
    public function addSubject(\Formedex\UserBundle\Entity\Subject $subjects)
    {
        $this->subjects[] = $subjects;

        return $this;
    }

    /**
     * Remove subjects
     *
     * @param \Formedex\UserBundle\Entity\Subject $subjects
     */
    public function removeSubject(\Formedex\UserBundle\Entity\Subject $subjects)
    {
        $this->subjects->removeElement($subjects);
    }

    /**
     * Get subjects
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSubjects()
    {
        return $this->subjects;
    }

    public function __toString(){
        if(isset($this->registrationNumber)){
            return $this->registrationNumber." ".$this->otherName;
        }
        return '';
    }
}
