<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Level
 *
 * @ORM\Table(name="subterm")
 * @ORM\Entity
 */
class Subterm
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Session")
     * @ORM\JoinColumn(name="session", referencedColumnName="id")
     */
    private $session;

     /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Term")
     * @ORM\JoinColumn(name="term", referencedColumnName="id")
     */
    private $term;

    /**
     * @var string
     *
     * @ORM\Column(name="start_date", type="date")
     */
    private $startDate;


    /**
     * @var string
     *
     * @ORM\Column(name="end_date", type="date")
     */
    private $endDate;
    

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set startDate
     *
     * @param \DateTime $startDate
     * @return Subterm
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return \DateTime 
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set endDate
     *
     * @param \DateTime $endDate
     * @return Subterm
     */
    public function setEndDate($endDate)
    {
        $this->endDate = $endDate;

        return $this;
    }

    /**
     * Get endDate
     *
     * @return \DateTime 
     */
    public function getEndDate()
    {
        return $this->endDate;
    }

    /**
     * Set session
     *
     * @param \Formedex\UserBundle\Entity\Session $session
     * @return Subterm
     */
    public function setSession(\Formedex\UserBundle\Entity\Session $session = null)
    {
        $this->session = $session;

        return $this;
    }

    /**
     * Get session
     *
     * @return \Formedex\UserBundle\Entity\Session 
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * Set term
     *
     * @param \Formedex\UserBundle\Entity\Term $term
     * @return Subterm
     */
    public function setTerm(\Formedex\UserBundle\Entity\Term $term = null)
    {
        $this->term = $term;

        return $this;
    }

    /**
     * Get term
     *
     * @return \Formedex\UserBundle\Entity\Term 
     */
    public function getTerm()
    {
        return $this->term;
    }
}
