<?php

namespace Formedex\UserBundle\Entity;

use Application\Sonata\MediaBundle\Entity\Gallery;
use Doctrine\ORM\Mapping as ORM;

/**
 * Course
 *
 * @ORM\Table(name="course")
 * @ORM\Entity
 */
class Course
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="text")
     */
    private $description;

    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    private $image;

    /**
     * @var string
     *
     * @ORM\Column(name="fee", type="string", length=255)
     */
    private $fee;
    
    /**
     * @ORM\ManyToMany(targetEntity="Formedex\UserBundle\Entity\Institution",  mappedBy="courses")
     * 
     */
    protected $institutions;

     /**
     * @ORM\ManyToMany(targetEntity="Formedex\UserBundle\Entity\Subject", inversedBy="courses")
     * 
     */
    protected $subjects;


    public function __construct()
    {
        $this->institution = new \Doctrine\Common\Collections\ArrayCollection();
        $this->subjects = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add institutions
     *
     * @param \Formedex\UserBundle\Entity\Institution $institutions
     * @return Institutions
     */
    public function addInstitutions(\Formedex\UserBundle\Entity\Institution $institutions)
    {
        $this->institutions[] = $institutions;
    
        return $this;
    }

    /**
     * Remove institutions
     *
     * @param \Formedex\UserBundle\Entity\Institution $institutions
     */
    public function removeInstitutions(\Formedex\UserBundle\Entity\Institution $institutions)
    {
        $this->institutions->removeElement($institutions);
    }

    /**
     * Get institutions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getInstitutions()
    {
        return $this->institutions;
    }

    /**
     * Add subjects
     *
     * @param \Formedex\UserBundle\Entity\Subject $subjects
     * @return Subjects
     */
    public function addSubjects(\Formedex\UserBundle\Entity\Subject $subjects)
    {
        $this->subjects[] = $subjects;
    
        return $this;
    }

    /**
     * Remove subjects
     *
     * @param \Formedex\UserBundle\Entity\Subject $subjects
     */
    public function removeSubjects(\Formedex\UserBundle\Entity\Subject $subjects)
    {
        $this->subjects->removeElement($subjects);
    }

    /**
     * Get institutions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSubjects()
    {
        return $this->subjects;
    }


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return Course
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Course
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set image
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $image
     * @return User
     */
    public function setImage(\Application\Sonata\MediaBundle\Entity\Media $image = null)
    {
        $this->image = $image;
    
        return $this;
    }

    /**
     * Get image
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set fee
     *
     * @param string $fee
     * @return Course
     */
    public function setFee($fee)
    {
        $this->fee = $fee;

        return $this;
    }

    /**
     * Get fee
     *
     * @return string 
     */
    public function getFee()
    {
        return $this->fee;
    }

    public function __toString(){
        if(isset($this->title)){
            return $this->title;
        }
        return '';
    }
}
