<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Term
 *
 * @ORM\Table(name="classcoordinator")
 * @ORM\Entity
 */
class Classcoordinator
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\OneToOne(targetEntity="Formedex\UserBundle\Entity\Staff")
     * @ORM\JoinColumn(name="staff", referencedColumnName="id")
     */
    private $staff;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Classroom")
     * @ORM\JoinColumn(name="class", referencedColumnName="id")
     */
    private $class;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Session")
     * @ORM\JoinColumn(name="session", referencedColumnName="id")
     */
    private $session;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Term")
     * @ORM\JoinColumn(name="term", referencedColumnName="id")
     */
    private $term;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set staff
     *
     * @param \Formedex\UserBundle\Entity\Staff $staff
     * @return Classcoordinator
     */
    public function setStaff(\Formedex\UserBundle\Entity\Staff $staff = null)
    {
        $this->staff = $staff;

        return $this;
    }

    /**
     * Get staff
     *
     * @return \Formedex\UserBundle\Entity\Staff 
     */
    public function getStaff()
    {
        return $this->staff;
    }

    /**
     * Set class
     *
     * @param \Formedex\UserBundle\Entity\Classroom $class
     * @return Classcoordinator
     */
    public function setClass(\Formedex\UserBundle\Entity\Classroom $class = null)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return \Formedex\UserBundle\Entity\Classroom 
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * Set session
     *
     * @param \Formedex\UserBundle\Entity\Session $session
     * @return Classcoordinator
     */
    public function setSession(\Formedex\UserBundle\Entity\Session $session = null)
    {
        $this->session = $session;

        return $this;
    }

    /**
     * Get session
     *
     * @return \Formedex\UserBundle\Entity\Session 
     */
    public function getSession()
    {
        return $this->session;
    }

    /**
     * Set term
     *
     * @param \Formedex\UserBundle\Entity\Term $term
     * @return Classcoordinator
     */
    public function setTerm(\Formedex\UserBundle\Entity\Term $term = null)
    {
        $this->term = $term;

        return $this;
    }

    /**
     * Get term
     *
     * @return \Formedex\UserBundle\Entity\Term 
     */
    public function getTerm()
    {
        return $this->term;
    }
}
