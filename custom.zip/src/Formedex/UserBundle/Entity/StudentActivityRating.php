<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * StudentActivityRating
 *
 * @ORM\Table(name="student_activity_ratings")
 * @ORM\Entity
 */
class StudentActivityRating
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;   

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Classroom")
     * @ORM\JoinColumn(name="class", referencedColumnName="id")
     */
    private $class;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Activityarea")
     * @ORM\JoinColumn(name="activityarea", referencedColumnName="id")
     */
    private $activityarea;

    /**
     * @ORM\OneToOne(targetEntity="Formedex\UserBundle\Entity\Student")
     * @ORM\JoinColumn(name="student", referencedColumnName="id")
     */
    private $student;

    /**
     * @var string
     *
     * @ORM\Column(name="student_rating",  type="string", length=255)
     */
    private $studentRating;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set studentRating
     *
     * @param string $studentRating
     * @return StudentActivityRating
     */
    public function setStudentRating($studentRating)
    {
        $this->studentRating = $studentRating;

        return $this;
    }

    /**
     * Get studentRating
     *
     * @return string 
     */
    public function getStudentRating()
    {
        return $this->studentRating;
    }

    /**
     * Set class
     *
     * @param \Formedex\UserBundle\Entity\Classroom $class
     * @return StudentActivityRating
     */
    public function setClass(\Formedex\UserBundle\Entity\Classroom $class = null)
    {
        $this->class = $class;

        return $this;
    }

    /**
     * Get class
     *
     * @return \Formedex\UserBundle\Entity\Classroom 
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * Set activityarea
     *
     * @param \Formedex\UserBundle\Entity\activityarea $activityarea
     * @return StudentActivityRating
     */
    public function setActivityarea(\Formedex\UserBundle\Entity\activityarea $activityarea = null)
    {
        $this->activityarea = $activityarea;

        return $this;
    }

    /**
     * Get activityarea
     *
     * @return \Formedex\UserBundle\Entity\activityarea 
     */
    public function getActivityarea()
    {
        return $this->activityarea;
    }

    /**
     * Set student
     *
     * @param \Formedex\UserBundle\Entity\Student $student
     * @return StudentActivityRating
     */
    public function setStudent(\Formedex\UserBundle\Entity\Student $student = null)
    {
        $this->student = $student;

        return $this;
    }

    /**
     * Get student
     *
     * @return \Formedex\UserBundle\Entity\Student 
     */
    public function getStudent()
    {
        return $this->student;
    }
}
