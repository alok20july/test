<?php

namespace Formedex\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Level
 *
 * @ORM\Table(name="subsession")
 * @ORM\Entity
 */
class Subsession
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Formedex\UserBundle\Entity\Session")
     * @ORM\JoinColumn(name="session", referencedColumnName="id")
     */
    private $session;


    /**
     * @var string
     *
     * @ORM\Column(name="start_date", type="date")
     */
    private $startDate;


    /**
     * @var string
     *
     * @ORM\Column(name="end_date", type="date")
     */
    private $endDate;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set startDate
     *
     * @param string $startDate
     * @return Subsession
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return string 
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set endDate
     *
     * @param string $endDate
     * @return Subsession
     */
    public function setEndDate($endDate)
    {
        $this->endDate = $endDate;

        return $this;
    }

    /**
     * Get endDate
     *
     * @return string 
     */
    public function getEndDate()
    {
        return $this->endDate;
    }

    /**
     * Set session
     *
     * @param \Formedex\UserBundle\Entity\Session $session
     * @return Subsession
     */
    public function setSession(\Formedex\UserBundle\Entity\Session $session = null)
    {
        $this->session = $session;

        return $this;
    }

    /**
     * Get session
     *
     * @return \Formedex\UserBundle\Entity\Session 
     */
    public function getSession()
    {
        return $this->session;
    }
}
