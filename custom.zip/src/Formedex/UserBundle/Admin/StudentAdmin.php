<?php

namespace Formedex\UserBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Formedex\UserBundle\Entity;
use Sonata\AdminBundle\Route\RouteCollection;

class StudentAdmin extends Admin
{
    /**
     * @param \Sonata\AdminBundle\Form\FormMapper $formMapper
     *
     * @return void
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
       $formMapper
            ->with('General')
            ->add('user', 'sonata_type_model_list')
            ->add('otherName')
            ->add('dob')
            ->add('stateOfOrigin')
            ->add('lgaOfOrigin')
            ->add('address')
            ->add('registrationNumber')
            ->add('sessionAdmitted')
            ->add('currentClass','sonata_type_model', array( 'attr' => array('onchange' => 'updateSubjectlist()', 'class'=> 'student_class')))
            ->add('nextClass')
            ->add('designation')
            ->add('passportImage', 'sonata_type_model_list', array('required' => false), array('link_parameters' => array('context' => 'default')))
            ->add('subjects', 'sonata_type_model', array('multiple' => true, 'attr' => array('class' => 'student_subjects')))
            ->end();
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\ListMapper $listMapper
     *
     * @return void
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper->addIdentifier('id')
             ->add('otherName');
    }

    protected function configureRoutes(RouteCollection $collection)
    {
        $collection->add('clone', $this->getRouterIdParameter().'/clone');
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\DatagridMapper $datagridMapper
     *
     * @return void
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper->add('otherName');
    }


    /**
     * {@inheritdoc}
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper->with('General')
                   ->add('otherName')
                   ->end();
    }
}