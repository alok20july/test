<?php

namespace Formedex\UserBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Formedex\UserBundle\Entity;


class StaffAdmin extends Admin
{
    /**
     * @param \Sonata\AdminBundle\Form\FormMapper $formMapper
     *
     * @return void
     */
    protected function configureFormFields(FormMapper $formMapper){

       $formMapper
            ->with('General')
            ->add('user',  'sonata_type_model_list')
            ->add('otherName')
            ->add('dob')
            ->add('stateOfOrigin')
            ->add('lgaOfOrigin')
            ->add('address')
            ->add('staffId')
            ->add('employmentDate', 'date')
            ->add('rank', 'choice', array(
                'choices'   => array(
                    "" => "Select",
                    "Class Teacher"=> "Class Teacher",
                    "Default Rank"=>"Default Rank"), 
                'required'  => false))
            ->add('designation', 'choice', array(
                'choices'   => array(
                    "" => "Select",
                    "Default" => "Default",
                    "Food Prefect" => "Food Prefect",
                    "Form Master" => "Form Master",
                    "Head Boy" => "Head Boy",
                    "Head Girl" => "Head Girl",
                    "Principal" => "Principal",
                    "Student" => "Student"
                    ), 
                'required'  => false))
             ->add('qualification', 'choice', array(
                'choices'   => array(
                    "" => "Select",
                    "BSc" => "BSc", 
                    "Default" => "Default", 
                    "FSLC" => "FSLC", 
                    "SSCE" => "SSCE"), 
                'required'  => false))
            ->add('areaOfSpecialisation')             
            ->add('passportImage', 'sonata_type_model_list', array('required' => false), array('link_parameters' => array('context' => 'default')))
            ->add('subjects', 'sonata_type_model', array('multiple' => true))
            ->end();
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\ListMapper $listMapper
     *
     * @return void
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper->addIdentifier('id')
                ->add('otherName');
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\DatagridMapper $datagridMapper
     *
     * @return void
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper->add('otherName');
    }


    /**
     * {@inheritdoc}
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper->with('General')
                   ->add('otherName')
                   ->end();
    }

}