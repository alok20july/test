<?php

namespace Formedex\UserBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use Formedex\UserBundle\Entity;

class GradescaleAdmin extends Admin
{
    /**
     * @param \Sonata\AdminBundle\Form\FormMapper $formMapper
     *
     * @return void
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')
            ->add('class', 'sonata_type_model_list')      
            ->add('grade','choice', array(
                'choices'   => array(' A'=>'A','B'=>'B','C'=>'C','D'=>'D','E'=>'E'), 'required'  => true,))      
            ->add('lowerBound')      
            ->add('upperBound')  
            ->add('gradePoint','choice', array(
                'choices'   => array(1,2,3,4,5), 'required'  => true))   
            ->add('remark','choice', array(
                'choices'   => array(
                        "Excellent" =>"Excellent",
                        "Very Good" =>"Very Good",
                        "Good" =>"Good",
                        "Fair" =>"Fair",
                        "Poor" =>"Poor",
                        "Fail" =>"Fail",
                    ), 'required'  => true))          
            ->end()

        ;
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\ListMapper $listMapper
     *
     * @return void
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->addIdentifier('id')
            ->add('class')      
            ->add('grade')      
            ->add('lowerBound')      
            ->add('upperBound')  
            ->add('gradePoint')  
            ->add('remark')
        ;
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\DatagridMapper $datagridMapper
     *
     * @return void
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('class')      
            ->add('grade')      
            ->add('lowerBound')      
            ->add('upperBound')  
            ->add('gradePoint')  
            ->add('remark') 
        ;
    }


    /**
     * {@inheritdoc}
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->with('General')
            ->add('class')      
            ->add('grade')      
            ->add('lowerBound')      
            ->add('upperBound')  
            ->add('gradePoint')  
            ->add('remark') 
            ->end()
        ;
    }
}
