<?php

namespace Formedex\UserBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class RegistrationControllerTest extends WebTestCase
{
    public function testStudentregistration()
    {
        $client = static::createClient();

        $crawler = $client->request('GET', 'student');
    }

}
