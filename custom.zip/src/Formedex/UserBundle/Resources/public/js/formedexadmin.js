$(document).ready(function(){
	updateSubjectlist();
});
function updateSubjectlist(){	
	var value = $("select.student_class").val();
	$.ajax({
	  url: "/app_dev.php/get_subject_by_class/"+value,
	}).done(function(data) {
	  $(".student_subjects").find('option').remove();
	  $("select.student_subjects").append(data);
	});
}
