// JavaScript Document

$(document).ready(function() {		
//	var hederHeight = $(window).height();
//	var hederHeight2 = $("body").height();	
	//var c = hederHeight - hederHeight2;
	//$(".header").css("height", hederHeight);
	//alert(hederHeight);
})



$('.selectpicker').selectpicker({
   // style: 'btn-info',
    size: 6
});

jQuery(window).bind('load', function () {
	parallaxInit();						  
});
function parallaxInit() {
    jQuery('.parallax').each(function(){
        jQuery(this).parallax("30%", 0.1);
    });
}


var sticky_navigation_offset_top = $('#sticky_navigation').offset().top;
	var sticky_navigation = function(){
		var scroll_top = $(window).scrollTop();
		if (scroll_top > sticky_navigation_offset_top) { 
			$('#sticky_navigation').addClass("fixed_header");
		} else {
			$('#sticky_navigation').removeClass("fixed_header");
		}   
	};
	sticky_navigation();
	$(window).scroll(function() {
		 sticky_navigation();
});



jQuery(function() {
			jQuery('#allinone_carousel_charming').allinone_carousel({
				skin: 'charming',
				width: 990,
				height: 454,
				responsive:true,
				autoPlay: 3,
				resizeImages:true,
				autoHideBottomNav:false,
				showElementTitle:false,
				verticalAdjustment:50,
				showPreviewThumbs:false,
				//easing:'easeOutBounce',
				numberOfVisibleItems:5,
				nextPrevMarginTop:23,
				playMovieMarginTop:0,
				bottomNavMarginBottom:-10
			});		
});


$('.bxslider').bxSlider({
  adaptiveHeight: true,
  mode: 'fade'
});


$(document).ready(function() {
      $("#owl-demo").owlCarousel({
        autoPlay : false,
        stopOnHover : true,
        navigation:false,
        paginationSpeed : 1000,
        goToFirstSpeed : 2000,
        singleItem : true,
        autoHeight : true,
        transitionStyle:"fade"
      });
});


$(document).ready(function() {

      $("#owl-demo1").owlCarousel({
        items : 7,
        lazyLoad : true,
        navigation : true,
								pagination:false
      });

});
				