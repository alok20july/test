<?php

namespace Formedex\UserBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController as Controller;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;

/**
 * Studentscore controller.
 *
 */
class StudentscoreAdminController extends Controller
{

    function listAction(){
    	$em = $this->getDoctrine()->getManager();
        $classes = $em->getRepository('FormedexUserBundle:Classroom')->findAll();
        return $this->render('FormedexUserBundle:StaffassignAdmin:list.html.twig', array(
            'classes' => $classes,
        ));
    }
}
