<?php

namespace Formedex\UserBundle\Controller;
use FOS\UserBundle\FOSUserEvents;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use FOS\UserBundle\Model\UserInterface;
use FOS\UserBundle\Controller\RegistrationController as BaseRegistrationController;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class RegistrationController extends Controller
{
    public function studentRegistrationAction(Request $request){
        /*
         *  @var $formFactory
        */
        $form = $this->container->get('fos_user.registration.form');
        $formHandler = $this->container->get('fos_user.registration.form.handler');
        $confirmationEnabled = $this->container->getParameter('fos_user.registration.confirmation.enabled');

        // exit(\Doctrine\Common\Util\Debug::dump($form));
        $process = $formHandler->process($confirmationEnabled);
        if ($process) {
            $em = $this->container->get('doctrine')->getManager();
            $user = $form->getData();
            $groupStudent = $em->getRepository('FormedexUserBundle:Group')->find(1);
            $user->addGroup($groupStudent);
            // we initialize athlete
            //$user->initStudent();
            $this->container->get('fos_user.user_manager')->updateUser($user);
            $authUser = false;
            if ($confirmationEnabled) {
                $this->container->get('session')->set('fos_user_send_confirmation_email/email', $user->getEmail());
                $route = 'fos_user_registration_check_email';
            } else {
                $authUser = true;
                $route = '';
            }
            //$this->setFlash('fos_user_success', 'registration.flash.user_created');
            $url = $this->container->get('router')->generate($route);
            $response = new RedirectResponse($url);
            if ($authUser) {
                $this->authenticateUser($user, $response);
            }
            //return $response->($this->generateUrl(''));
           return $response;
        }

        return $this->container->get('templating')->renderResponse('FormedexUserBundle:Registration:studentRegistration.html.twig', array(
            'form' => $form->createView(),
        ));
    }
}
