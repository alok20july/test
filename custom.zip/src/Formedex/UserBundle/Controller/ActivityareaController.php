<?php

namespace Formedex\UserBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use Formedex\UserBundle\Entity\Activityarea;
use Formedex\UserBundle\Form\ActivityareaType;

/**
 * Activityarea controller.
 *
 */
class ActivityareaController extends Controller
{

    /**
     * Lists all Activityarea entities.
     *
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $entities = $em->getRepository('FormedexUserBundle:Activityarea')->findAll();

        return $this->render('FormedexUserBundle:Activityarea:index.html.twig', array(
            'entities' => $entities,
        ));
    }
    /**
     * Creates a new Activityarea entity.
     *
     */
    public function createAction(Request $request)
    {
        $entity = new Activityarea();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();

            return $this->redirect($this->generateUrl('activityarea_show', array('id' => $entity->getId())));
        }

        return $this->render('FormedexUserBundle:Activityarea:new.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    /**
     * Creates a form to create a Activityarea entity.
     *
     * @param Activityarea $entity The entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createCreateForm(Activityarea $entity)
    {
        $form = $this->createForm(new ActivityareaType(), $entity, array(
            'action' => $this->generateUrl('activityarea_create'),
            'method' => 'POST',
        ));

        $form->add('submit', 'submit', array('label' => 'Create'));

        return $form;
    }

    /**
     * Displays a form to create a new Activityarea entity.
     *
     */
    public function newAction()
    {
        $entity = new Activityarea();
        $form   = $this->createCreateForm($entity);

        return $this->render('FormedexUserBundle:Activityarea:new.html.twig', array(
            'entity' => $entity,
            'form'   => $form->createView(),
        ));
    }

    /**
     * Finds and displays a Activityarea entity.
     *
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('FormedexUserBundle:Activityarea')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Activityarea entity.');
        }

        $deleteForm = $this->createDeleteForm($id);

        return $this->render('FormedexUserBundle:Activityarea:show.html.twig', array(
            'entity'      => $entity,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing Activityarea entity.
     *
     */
    public function editAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('FormedexUserBundle:Activityarea')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Activityarea entity.');
        }

        $editForm = $this->createEditForm($entity);
        $deleteForm = $this->createDeleteForm($id);

        return $this->render('FormedexUserBundle:Activityarea:edit.html.twig', array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
    * Creates a form to edit a Activityarea entity.
    *
    * @param Activityarea $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createEditForm(Activityarea $entity)
    {
        $form = $this->createForm(new ActivityareaType(), $entity, array(
            'action' => $this->generateUrl('activityarea_update', array('id' => $entity->getId())),
            'method' => 'PUT',
        ));

        $form->add('submit', 'submit', array('label' => 'Update'));

        return $form;
    }
    /**
     * Edits an existing Activityarea entity.
     *
     */
    public function updateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('FormedexUserBundle:Activityarea')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Activityarea entity.');
        }

        $deleteForm = $this->createDeleteForm($id);
        $editForm = $this->createEditForm($entity);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $em->flush();

            return $this->redirect($this->generateUrl('activityarea_edit', array('id' => $id)));
        }

        return $this->render('FormedexUserBundle:Activityarea:edit.html.twig', array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }
    /**
     * Deletes a Activityarea entity.
     *
     */
    public function deleteAction(Request $request, $id)
    {
        $form = $this->createDeleteForm($id);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $entity = $em->getRepository('FormedexUserBundle:Activityarea')->find($id);

            if (!$entity) {
                throw $this->createNotFoundException('Unable to find Activityarea entity.');
            }

            $em->remove($entity);
            $em->flush();
        }

        return $this->redirect($this->generateUrl('activityarea'));
    }

    /**
     * Creates a form to delete a Activityarea entity by id.
     *
     * @param mixed $id The entity id
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm($id)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('activityarea_delete', array('id' => $id)))
            ->setMethod('DELETE')
            ->add('submit', 'submit', array('label' => 'Delete'))
            ->getForm()
        ;
    }
}
