<?php

namespace Formedex\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('FormedexUserBundle:Default:index.html.twig');
    }

    public function loginAction()
    {
        return $this->render('FormedexUserBundle:Default:login.html.twig');
    }

    public function getmediaImagesAction($type=1, $gallery){
    	$path = array();
    	$mediaManager = $this->container->get('sonata.media.manager.gallery');
    	$imagemanager = $this->container->get('sonata.media.provider.image');    
    	$gallery = $mediaManager->find($gallery);
    	$medias = $gallery->getGalleryHasMedias();
    	$i = 0;
        foreach ($medias as $media) {
			$image = $media->getMedia();
			$path[$i]['name'] = $image;
        	$format = $imagemanager->getFormatName($image, 'big');
			$path[$i]['path'] = $imagemanager->generatePublicUrl($image, $format);
			$i++;
    	}
    	return $this->render('FormedexUserBundle:Default:sliders.html.twig', array('images' => $path, "type" => $type ));
    }
}
