<?php

/*
 * This file is part of the FOSUserBundle package.
 *
 * (c) FriendsOfSymfony <http://friendsofsymfony.github.com/>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Formedex\UserBundle\Form\Type;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use FOS\UserBundle\Form\Type\RegistrationFormType as FormType;

class RegistrationFormType extends FormType
{
    public function buildForm(FormBuilderInterface $builder, array $options){
        //$builder->add('firstname', null, array('label' => 'First Name'));
        //$builder->add('lastname', null, array('label' => 'Last Name'));
        parent::buildForm($builder, $options);
        $builder->remove('username');
    }

    public function getName(){
        return 'formedex_student_registration';
    }

}
