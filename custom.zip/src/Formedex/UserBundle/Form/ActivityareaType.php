<?php

namespace Formedex\UserBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ActivityareaType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('area')
            ->add('description')
            ->add('minScore')
            ->add('maxScore')
            ->add('activitygroup')
            ->add('class')
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Formedex\UserBundle\Entity\Activityarea'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'formedex_userbundle_activityarea';
    }
}
