<?php

namespace Formedex\UserBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class GradescaleType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('grade')
            ->add('lowerBound')
            ->add('upperBound')
            ->add('gradePoint')
            ->add('remark')
            ->add('class')
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Formedex\UserBundle\Entity\Gradescale'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'formedex_userbundle_gradescale';
    }
}
