<?php

namespace Formedex\UserBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class StudentActivityRatingType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('studentRating')
            ->add('class')
            ->add('activityarea')
            ->add('student')
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Formedex\UserBundle\Entity\StudentActivityRating'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'formedex_userbundle_studentactivityrating';
    }
}
