<?php

namespace Formedex\UserBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class StaffType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('otherName')
            ->add('dob')
            ->add('stateOfOrigin')
            ->add('lgaOfOrigin')
            ->add('address')
            ->add('staffId')
            ->add('employmentDate')
            ->add('rank')
            ->add('designation')
            ->add('qualification')
            ->add('user')
            ->add('areaOfSpecialisation')
            ->add('passportImage')
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Formedex\UserBundle\Entity\Staff'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'formedex_userbundle_staff';
    }
}
