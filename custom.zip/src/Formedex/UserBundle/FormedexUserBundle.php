<?php

namespace Formedex\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FormedexUserBundle extends Bundle
{
}
