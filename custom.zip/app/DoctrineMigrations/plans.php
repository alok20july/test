<?php
ob_start();

/**
 * Plugin Name: Custom Plans
 * Plugin URI: mailto: a.mehta.1605@gmail.com
 * Description: Plugin for manageing Premium plan and Email wizard plan
 * Version:  1.0
 * Author: Surbhi 
 * Author URI: mailto: a.mehta.1605@gmail.com
 * License: GPL2

 * Adds a box to the main column on the Post and Page edit screens.
 */
function subscriptionplans_add_meta_box() {

    $screens = array('plan');

    foreach ($screens as $screen) {

        add_meta_box(
                'subscriptionplans_sectionid', __('Additional Plan options', 'subscriptionplans_textdomain'), 'subscriptionplans_meta_box_callback', $screen
        );
    }
}

add_action('add_meta_boxes', 'subscriptionplans_add_meta_box');

/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function subscriptionplans_meta_box_callback($post) {

    // Add an nonce field so we can check for it later.
    wp_nonce_field('subscriptionplans_meta_box', 'subscriptionplans_meta_box_nonce');

    /*
     * Use get_post_meta() to retrieve an existing value
     * from the database and use the value for the form.
     */
    $subscriptionplans_price = get_post_meta($post->ID, 'subscriptionplans_price', true);
    $plan_custom_link = get_post_meta($post->ID, '_plan_custom_link', true);
    $subscriptionplans_courses = explode(",", get_post_meta($post->ID, '_plan_product', true));

    echo '<label for="subscriptionplans_price">';
    _e('Plan Price :', 'subscriptionplans_textdomain');
    echo '</label> ';
    echo '<input type="text" id="subscriptionplans_price" name="subscriptionplans_price" value="' . esc_attr($subscriptionplans_price) . '" size="25" /> please note: if price zero link will redirect to courses page.';

    echo '<br/><br/><label for="_plan_custom_link">';
    _e('Plan Custom Link :', 'subscriptionplans_textdomain');
    echo '</label> ';
    echo '<input type="text" id="_plan_custom_link" name="_plan_custom_link" value="' . esc_attr($plan_custom_link) . '" size="25" />';

    echo '<br/><br/><label for="subscriptionplans_courses">';
    _e('Plan Courses :', 'subscriptionplans_textdomain');
    echo '</label><br/> ';
    $products = get_posts('post_type=course&post_status=publish');

    foreach ($products as $product) {
        $productID = get_post_meta($product->ID, '_course_product', true);
        if (in_array($productID, $subscriptionplans_courses)) {
            $selected = 'checked="checked"';
        } else {
            $selected = '';
        };
        echo '&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" ' . $selected . '  name="_plan_product[]" value="' . esc_attr($productID) . '" />' . $product->post_title . "<br/>";
    }
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function subscriptionplans_save_meta_box_data($post_id) {
    /*
     * We need to verify this came from our screen and with proper authorization,
     * because the save_post action can be triggered at other times.
     */

    // Check if our nonce is set.
    if (!isset($_POST['subscriptionplans_meta_box_nonce'])) {
        return;
    }

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($_POST['subscriptionplans_meta_box_nonce'], 'subscriptionplans_meta_box')) {
        return;
    }

    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    // Check the user's permissions.
    if (isset($_POST['post_type']) && 'plan' == $_POST['post_type']) {

        /* OK, it's safe for us to save the data now. */

        // Make sure that it is set.
        if (isset($_POST['subscriptionplans_price']) && !empty($_POST['subscriptionplans_price'])) {

            $my_data = sanitize_text_field($_POST['subscriptionplans_price']);
            // Update the meta field in the database.
            update_post_meta($post_id, 'subscriptionplans_price', $my_data);
        }

        if (isset($_POST['_plan_product']) && !empty($_POST['_plan_product'])) {
            update_post_meta($post_id, '_plan_product', implode(",", $_POST['_plan_product']));
        }

        if (isset($_POST['_plan_custom_link']) && !empty($_POST['_plan_custom_link'])) {
            update_post_meta($post_id, '_plan_custom_link', $_POST['_plan_custom_link']);
        }
    }

    // Sanitize user input.
}

add_action('save_post', 'subscriptionplans_save_meta_box_data');

add_action('woocommerce_calculate_totals', 'calculate_totals', 10, 1);

function calculate_totals($totals) {
    $planvalue = 0;
    foreach ($totals->cart_contents as $values) {
        $planvalue = $values['planvalue'];
    }
    if ($planvalue != 0) {
        $totals->add_fee('Plan Susbcription discount', $totals->cart_contents_total - $planvalue, true, '');
        $totals->cart_contents_total = $planvalue;
    }
    return $totals;
}

add_action('wp_ajax_show_email', 'prefix_ajax_show_email');
add_action('wp_ajax_nopriv_show_email', 'prefix_ajax_show_email');

function prefix_ajax_show_email() {
    global $wpdb;
    $data= array();
    $table_name = $wpdb->prefix . 'customtable';
    $sql = "SELECT * FROM $table_name ORDER BY RAND() LIMIT 1";
    $result = $wpdb->get_results($sql);
    if ($result) {
        $data['header'] = $result[0]->header;
        $data['description'] = str_replace("\n", "<br/>", $result[0]->description);
        echo json_encode($data);
    }
    die;
}

function add_to_aweber_list($data) {
    $_aweber_listname = get_post_meta($data['pre_page_id'], '_aweber_listname', true);
    $_aweber_webform_id = get_post_meta($data['pre_page_id'], '_aweber_webform_id', true);
    if($_aweber_webform_id==''){
       $_aweber_webform_id = '1806793836';
    }
     if($_aweber_listname==''){
       $_aweber_listname = 'awlist3831228';
    }
    $ch = curl_init();
    $fields = array(
        'meta_web_form_id' => $_aweber_webform_id ,
        'meta_split_id' => '',
        'listname' => $_aweber_listname,
        'redirect' => '',
        'meta_adtracking'=> '',
        'meta_message' => '1',
        'meta_tooltip' => '',
        'meta_required' => 'name,email',
        'name' => $data['user_login'],
        'email' => $data['user_email'],
        'submit' => 'Submit'
    );
    $postvars = '';
    foreach ($fields as $key => $value) {
        $postvars .= $key . "=" . $value . "&";
    }
    $url = "http://www.aweber.com/scripts/addlead.pl";
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);                //0 for a get request
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postvars);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    $response = curl_exec($ch);
    print "curl response is:" . $response;
    curl_close($ch);    
}

/// jv zoo site ajax

add_action('wp_ajax_jvzoo_check', 'prefix_ajax_jvzoo_check');
add_action('wp_ajax_nopriv_jvzoo_check', 'prefix_ajax_jvzoo_check');

function prefix_ajax_jvzoo_check() {
    global $wpdb;
    $url = $_POST['url'];
    $pageid = $_POST['pageid'];
    if (!is_user_logged_in()) {
        $str = preg_replace('#^https?://#', '', $url);
        $url = ThemexCore::getURL('register') . "/?rd=" . $str . "&pageid=" . $pageid;
    }
    echo $url;
    die;
}

/* * **********Aweber settings for sales page functionality***********
 * Adds a box to the main column on the Post and Page edit screens.
 */

function aweber_add_meta_box() {

    $screens = array('plan', 'product', 'course', 'page');

    foreach ($screens as $screen) {

        add_meta_box(
                'aweber_sectionid', __('Jvzoo and Aweber options', 'aweber_textdomain'), 'aweber_meta_box_callback', $screen
        );
    }
}

add_action('add_meta_boxes', 'aweber_add_meta_box');

/**
 * Prints the box content.
 * 
 * @param WP_Post $post The object for the current post/page.
 */
function aweber_meta_box_callback($post) {

    // Add an nonce field so we can check for it later.
    wp_nonce_field('aweber_meta_box', 'aweber_meta_box_nonce');

    /*
     * Use get_post_meta() to retrieve an existing value
     * from the database and use the value for the form.
     */
    $_aweber_listname = get_post_meta($post->ID, '_aweber_listname', true);
    $_aweber_webform_id = get_post_meta($post->ID, '_aweber_webform_id', true);
    if($post->post_type!='page' && $post->post_type!='post'){
        echo "ID: ".$post->ID."<br/><br/>Please use this URL in jvzoo as product Thanksyou URL: <label><b>".get_permalink( get_page_by_path( 'jvzooipn-details' ) )."?pid=".$post->ID."</b></label>";
    }
    echo '<br/><br/><label for="_aweber_listname">';
    _e('Aweber List Name :', 'aweber_textdomain');
    echo '</label> ';
    echo '<input type="text" id="_aweber_listname" name="_aweber_listname" value="' . esc_attr($_aweber_listname) . '" size="25" />';

    echo '<br/><br/><label for="_aweber_webform_id">';
    _e('Web Form Id:', 'aweber_textdomain');
    echo '</label>';
    echo '<input type="text" id="_aweber_webform_id" name="_aweber_webform_id" value="' . esc_attr($_aweber_webform_id) . '" size="25" />';
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function aweber_save_meta_box_data($post_id) {
    /*
     * We need to verify this came from our screen and with proper authorization,
     * because the save_post action can be triggered at other times.
     */

    // Check if our nonce is set.
    if (!isset($_POST['aweber_meta_box_nonce'])) {
        return;
    }

    // Verify that the nonce is valid.
    if (!wp_verify_nonce($_POST['aweber_meta_box_nonce'], 'aweber_meta_box')) {
        return;
    }

    // If this is an autosave, our form has not been submitted, so we don't want to do anything.
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
 $screens = array('plan', 'product', 'course', 'page');
    // Check the user's permissions.
    if (isset($_POST['post_type']) && in_array($_POST['post_type'], $screens) ) {
        /* OK, it's safe for us to save the data now. */

        // Make sure that it is set.
        if (isset($_POST['_aweber_listname']) && !empty($_POST['_aweber_listname'])) {

            $my_data = sanitize_text_field($_POST['_aweber_listname']);
            // Update the meta field in the database.
            update_post_meta($post_id, '_aweber_listname', $my_data);
        }

        if (isset($_POST['_aweber_webform_id']) && !empty($_POST['_aweber_webform_id'])) {

            $_aweber_webform_id = sanitize_text_field($_POST['_aweber_webform_id']);
            // Update the meta field in the database.
            update_post_meta($post_id, '_aweber_webform_id', $_aweber_webform_id);
        }
    }
    // Sanitize user input.
}

add_action('save_post', 'aweber_save_meta_box_data');


function custom_order_table($order,$price = false) {

        foreach($order->get_items() as $item) : 

        $_product = $order->get_product_from_item( $item );

        $file = $sku = $variation = $image = '';

        if ($show_image) :
          $src = wp_get_attachment_image_src( get_post_thumbnail_id( $_product->id ), 'thumbnail');
          $image = apply_filters('woocommerce_order_product_image', '<img src="'.$src[0].'" alt="Product Image" height="'.$image_size[1].'" width="'.$image_size[0].'" style="vertical-align:middle; margin-right: 10px;" />', $_product);
        endif;

        if ($show_sku && $_product->get_sku()) :
          $sku = ' (#' . $_product->get_sku() . ')';
        endif;


        $return .= '<tr>
          <td style="text-align:left; vertical-align:middle; border: 1px solid #eee;">'. $image . apply_filters('woocommerce_order_product_title', $item['name'], $_product) . $sku . $file . $variation . '</td>
          <td style="text-align:left; vertical-align:middle; border: 1px solid #eee;">'.$item['qty'].'</td>';
        if ($price):
          $return .= '<td style="text-align:left; vertical-align:middle; border: 1px solid #eee;">';

            if ( $order->display_cart_ex_tax || !$order->prices_include_tax ) : 
              $ex_tax_label = ( $order->prices_include_tax ) ? 1 : 0;
              $return .= woocommerce_price( $order->get_line_subtotal( $item ), array('ex_tax_label' => $ex_tax_label ));
            else :
              $return .= woocommerce_price( $order->get_line_subtotal( $item, true ) );
            endif;

          $return .= '</td>';
        endif;
        $return .= '</tr>';

        // Show any purchase notes
        if ($show_purchase_note) :
          if ($purchase_note = get_post_meta( $_product->id, '_purchase_note', true)) :
            $return .= '<tr><td colspan="3" style="text-align:left; vertical-align:middle; border: 1px solid #eee;">' . apply_filters('the_content', $purchase_note) . '</td></tr>';
          endif;
        endif;

      endforeach;

      echo $return;
      }