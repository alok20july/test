<?php
ini_set("display_errors", true);
ini_set("max_execution_time", 300);
error_reporting(E_ALL);
include '../config.inc.php';
include 'BCAPI.class.php';

$connect = mysql_connect($dbconfig['db_server'] , $dbconfig['db_username'] , $dbconfig['db_password']);
$db = mysql_select_db($dbconfig['db_name'] , $connect);
$sql = mysql_query("select crmid, cf_851, cf_634, email1 from vtiger_crmentity JOIN vtiger_account ON vtiger_account.accountid = vtiger_crmentity.crmid JOIN vtiger_accountscf ON vtiger_accountscf.accountid = vtiger_crmentity.crmid WHERE cf_612 = 'Artist' and deleted = 0");
if(empty($sql) == false){
    while($result = mysql_fetch_array($sql)){
    	$array =  array('artistDetails' => array(), 'commissionsDetails' => array());
		$crmId = $result['crmid'];
		$ArtistId = $result['cf_851'];
		$EmailId = $result['email1'];
		$name = $result['cf_634'];
		$BCGatewayObj = new BCAPI(); 
		$BCGatewayObj->setAPIKey( 'MUZMN-SKCZX-RBZER-PTDFW-VP9KA-DOFDU');
		$BCGatewayObj->setAPIGateway( 'http://www.managebusinesscards.com/API.php' );
		$BCGatewayObj->setContentType( 'PHPSERIAL' ); // no dependencies needed
		if(!empty($ArtistId)===true){
			$array['artistDetails'] = $BCGatewayObj->ArtistGet($ArtistId);
			$array['commissionsDetails'] = $BCGatewayObj->CommissionsGetSummary($ArtistId);
		}else{
			$searchResult = $BCGatewayObj->ArtistSearch($EmailId);
			if($searchResult['numberResults']>0){
				foreach ($searchResult['results'] as $result) {					
					if($result['vAccountId'] == $crmId ){
						$array['artistDetails'] = $BCGatewayObj->ArtistGet($result['id']);
						$array['commissionsDetails'] = $BCGatewayObj->CommissionsGetSummary($result['id']);
				    }
		  		}
	  		}       
		}
		if(isset($array['artistDetails']['results']) && isset($array['commissionsDetails']['results'])){
			$crmid = $array['artistDetails']['results'][0]['vAccountId'];
//echo " - ";
		    // User Name  : cf_850
			$username = $array['artistDetails']['results'][0]['artistLogin'];
//echo " - ";
			//Artist Code  : cf_851
			$artistCode = $array['artistDetails']['results'][0]['id'];
//echo " - ";
			//Bio URL : cf_834
			$bioURL = $array['artistDetails']['results'][0]['bioURL'];
//echo " - ";
			//Approved as New Artist : cf_661
			$approvedArtist = ($array['artistDetails']['results'][0]['approvedArtist']=="No")?0:1;
//echo " - ";
			//Biography  : cf_660
			$biography = ($array['artistDetails']['results'][0]['bioPublished']=="No")?0:1;
//echo " - ";
			//Template Count  : cf_852
			$totalImages = $array['artistDetails']['results'][0]['totalImages'];
//echo " - ";
			//Sale Count	: cf_853			
			$sale = $array['commissionsDetails']['results']['TotalSold'];
			//echo "<br/>";
				/* cf_660 = ".$biography.", */
			
			mysql_query("update vtiger_accountscf set 
						cf_850 = '".$username."',
						cf_661 = ".$approvedArtist.",					
						cf_852 = '".$totalImages."',
						cf_851 = '".$artistCode."', 
						cf_853 = '".$sale."',
						cf_834 = '".$bioURL."'
						where accountid = ".$crmid."");
	    }
	}
}