<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 1/23/14
 * Time: 10:28 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\DependencyInjection\Compiler;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class OverrideServiceCompilerPass implements CompilerPassInterface{

    public function process(ContainerBuilder $container)
    {
        $definition = $container->getDefinition('sonata.media.admin.media');
        $tags = $definition->getTags();
        $tags['sonata.admin'][0]['audit'] = false;
        $definition->setTags($tags);
        $container->setDefinition('sonata.media.admin.media', $definition);

        $definition = $container->getDefinition('sonata.media.admin.gallery');
        $tags = $definition->getTags();
        $tags['sonata.admin'][0]['audit'] = false;
        $definition->setTags($tags);
        $container->setDefinition('sonata.media.admin.gallery', $definition);

        $definition = $container->getDefinition('sonata.media.admin.gallery_has_media');
        $tags = $definition->getTags();
        $tags['sonata.admin'][0]['audit'] = false;
        $definition->setTags($tags);
        $container->setDefinition('sonata.media.admin.gallery', $definition);
    }
}