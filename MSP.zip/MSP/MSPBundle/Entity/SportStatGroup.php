<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/10/13
 * Time: 4:21 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_sport_stat_group")
 */
class SportStatGroup
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=50)
     */
    protected $name;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $tooltip;

    /**
     * @ORM\ManyToMany(targetEntity="SportPosition", inversedBy="sportStatGroups")
     * @ORM\JoinTable(name="sport_position_stat_groups")
     */
    protected $sportPositions;

    /**
     * @ORM\ManyToOne(targetEntity="Sport")
     * @ORM\JoinColumn(name="sport_id", referencedColumnName="id")
     */
    protected $sport;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return SportStatGroup
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set tooltip
     *
     * @param string $tooltip
     * @return SportStatGroup
     */
    public function setTooltip($tooltip)
    {
        $this->tooltip = $tooltip;
    
        return $this;
    }

    /**
     * Get tooltip
     *
     * @return string 
     */
    public function getTooltip()
    {
        return $this->tooltip;
    }

    /**
     * Set sportPosition
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportPosition
     * @return SportStatGroup
     */
    public function setSportPosition(\MSP\MSPBundle\Entity\SportPosition $sportPosition = null)
    {
        $this->sportPosition = $sportPosition;
    
        return $this;
    }

    /**
     * Get sportPosition
     *
     * @return \MSP\MSPBundle\Entity\SportPosition 
     */
    public function getSportPosition()
    {
        return $this->sportPosition;
    }

    /**
     * Set sport
     *
     * @param \MSP\MSPBundle\Entity\Sport $sport
     * @return SportStatGroup
     */
    public function setSport(\MSP\MSPBundle\Entity\Sport $sport = null)
    {
        $this->sport = $sport;
    
        return $this;
    }

    /**
     * Get sport
     *
     * @return \MSP\MSPBundle\Entity\Sport 
     */
    public function getSport()
    {
        return $this->sport;
    }

    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->sportPositions = new \Doctrine\Common\Collections\ArrayCollection();
    }
    


    /**
     * Add sportPositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportPositions
     * @return SportStatGroup
     */
    public function addSportPosition(\MSP\MSPBundle\Entity\SportPosition $sportPositions)
    {
        $this->sportPositions[] = $sportPositions;
    
        return $this;
    }

    /**
     * Remove sportPositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportPositions
     */
    public function removeSportPosition(\MSP\MSPBundle\Entity\SportPosition $sportPositions)
    {
        $this->sportPositions->removeElement($sportPositions);
    }

    /**
     * Get sportPositions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportPositions()
    {
        return $this->sportPositions;
    }
}