<?php
/**
 * Created by Alok Kumar
 * User: alok
 * Date: 6/4/13
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_custom_newsfeed")
 */
class CustomNewsFeed
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="text", nullable=false)
     */
    protected $content;

    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="date")
     */
    protected $created;

    /**
     * @ORM\ManyToOne(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id", nullable=false)
     */
    protected $user;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $status;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set content
     *
     * @param string $content
     * @return CustomNewsFeed
     */
    public function setContent($content)
    {
        $this->content = $content;    
        return $this;
    }

    /**
     * Get content
     *
     * @return string 
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return CustomNewsFeed
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user = null)
    {
        $this->user = $user;    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set status
     *
     * @param boolean $status
     * @return CustomNewsFeed
     */
    public function setStatus($status)
    {
        $this->status = $status;    
        return $this;
    }

    /**
     * Get status
     *
     * @return boolean 
     */
    public function getStatus()
    {
        return $this->status;
    }


    /**
     * Get created
     *
     * @return datetime 
     */
    public function getCreated()
    {
        return $this->created;
    }

	/**
     * Set status
     *
     * @param datetime $created
     * @return CustomNewsFeed
     */
    public function setCreated($created)
    {
        $this->created = $created;
        return $this;
    }
}