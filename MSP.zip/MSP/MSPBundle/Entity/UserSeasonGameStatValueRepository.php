<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 7/11/14
 * Time: 11:10 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;

class UserSeasonGameStatValueRepository extends EntityRepository{

    public function getUserSeasonGameStatus($user, $userTeamSeason, $sportStatGroup, $sportStat)
    {
        return $this->getEntityManager()
            ->createQuery(
                "SELECT usgsv
                 FROM MSPBundle:UserSeasonGameStatValue usgsv
                 Where usgsv.user = :user
                 AND usgsv.userTeamSeason = :userTeamSeason
                 AND usgsv.sportStatGroup = :sportStatGroup
                 AND usgsv.sportStat = :sportStat
                 AND usgsv.isStatus = 1
                 "
            )->setParameters(
                array(
                    'user' => $user,
                    'userTeamSeason' => $userTeamSeason,
                    'sportStatGroup' => $sportStatGroup,
                    'sportStat' => $sportStat
                )
            )
            ->getOneOrNullResult();
    }
}