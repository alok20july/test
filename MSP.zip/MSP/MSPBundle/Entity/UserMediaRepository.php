<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 14/05/14
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;
use MSP\MSPBundle\Entity\Connection;
use Application\Sonata\MediaBundle\Entity\Gallery;
use Application\Sonata\MediaBundle\Entity\Media as Media;

class UserMediaRepository extends EntityRepository
{

    /*
    *  get all media user by user id and media context
    *  MSPGallery $media_type = 1
    *  MYGallery $media_type = 0
    */
    
    public function getUserMediaById(User $user, $media_type)
    {
        $condition = '';
        // MSPGallery $media_type = 1
        // MYGallery  $media_type = 0
        if(1 == $media_type){
            $condition = "AND (um.gallery_type = ".$media_type.")";
        }

        return $this->getEntityManager()->createQuery(
        "SELECT um
            FROM MSPBundle:UserMedia um,
            MSPBundle:User u
            WHERE
            (um.user = :user)
            ".$condition."
            ORDER BY um.id desc
        "
        )
        ->setParameters(array(
            'user' => $user->getId()
        ))
        ->getResult();
    }
}