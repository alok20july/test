<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 7/11/14
 * Time: 11:10 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;

class UserSeasonStatValueRepository extends EntityRepository{

    public function getUserSeasonStatus($user, $team, $sportStatGroup, $sportStat)
    {
        // echo '<li>'.$user, $sportStat, $sport;
        return $this->getEntityManager()
            ->createQuery(
                "SELECT ussv
                 FROM MSPBundle:UserSeasonStatValue ussv
                 Where ussv.user = :user
                 AND ussv.team = :team
                 AND ussv.sportStatGroup = :sportStatGroup
                 AND ussv.sportStat = :sportStat
                 AND ussv.isStatus = 1
                 "
            )->setParameters(
                array(
                    'user' => $user,
                    'team' => $team,
                    'sportStatGroup' => $sportStatGroup,
                    'sportStat' => $sportStat
                )
            )
            ->getOneOrNullResult();
    }
}