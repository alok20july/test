<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/9/13
 * Time: 10:37 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_sport_position")
 */
class SportPosition
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50, nullable=false)
     */
    protected $name;

    /**
     * @ORM\Column(type="string", length=10)
     */
    protected $abreviation;

    /**
     * @ORM\ManyToOne(targetEntity="Sport", inversedBy="sportpositions")
     * @ORM\JoinColumn(name="sport_id", referencedColumnName="id")
     */
    protected $sport;

    /**
     * @ORM\ManyToMany(targetEntity="SportStat", mappedBy="sportPositions")
     * @ORM\OrderBy({"sortOrder" = "ASC"})
     */
    protected $sportStats;

    /**
     * @ORM\ManyToMany(targetEntity="SportStatGroup", mappedBy="sportPositions")
     * @ORM\JoinTable(name="msp_sport_stat_group")
     *
     */
    protected $sportStatGroups;



    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return SportPosition
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set abreviation
     *
     * @param string $abreviation
     * @return SportPosition
     */
    public function setAbreviation($abreviation)
    {
        $this->abreviation = $abreviation;
    
        return $this;
    }

    /**
     * Get abreviation
     *
     * @return string 
     */
    public function getAbreviation()
    {
        return $this->abreviation;
    }

    /**
     * Set sport
     *
     * @param \MSP\MSPBundle\Entity\Sport $sport
     * @return SportPosition
     */
    public function setSport(\MSP\MSPBundle\Entity\Sport $sport = null)
    {
        $this->sport = $sport;
    
        return $this;
    }

    /**
     * Get sport
     *
     * @return \MSP\MSPBundle\Entity\Sport 
     */
    public function getSport()
    {
        return $this->sport;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->sportStats = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Add sportStats
     *
     * @param \MSP\MSPBundle\Entity\SportStat $sportStats
     * @return SportPosition
     */
    public function addSportStat(\MSP\MSPBundle\Entity\SportStat $sportStats)
    {
        $this->sportStats[] = $sportStats;
    
        return $this;
    }

    /**
     * Remove sportStats
     *
     * @param \MSP\MSPBundle\Entity\SportStat $sportStats
     */
    public function removeSportStat(\MSP\MSPBundle\Entity\SportStat $sportStats)
    {
        $this->sportStats->removeElement($sportStats);
    }

    /**
     * Get sportStats
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportStats()
    {
        return $this->sportStats;
    }



    /**
     * Add sportStatGroups
     *
     * @param \MSP\MSPBundle\Entity\SportStatGroup $sportStatGroups
     * @return SportPosition
     */
    public function addSportStatGroup(\MSP\MSPBundle\Entity\SportStatGroup $sportStatGroups)
    {
        $this->sportStatGroups[] = $sportStatGroups;
    
        return $this;
    }

    /**
     * Remove sportStatGroups
     *
     * @param \MSP\MSPBundle\Entity\SportStatGroup $sportStatGroups
     */
    public function removeSportStatGroup(\MSP\MSPBundle\Entity\SportStatGroup $sportStatGroups)
    {
        $this->sportStatGroups->removeElement($sportStatGroups);
    }

    /**
     * Get sportStatGroups
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportStatGroups()
    {
        return $this->sportStatGroups;
    }
}