<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 14/05/14
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_gallery_user_media")
 * @ORM\Entity(repositoryClass="UserMediaRepository")
 */
class UserMedia
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    protected $content;

    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    protected $image;
    
    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    protected $video;
    
    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="posts")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $sort_position;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $gallery_type;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set content
     *
     * @param string $content
     * @return UserMedia
     */
    public function setContent($content)
    {
        $this->content = $content;    
        return $this;
    }

    /**
     * Get content
     *
     * @return string 
     */
    public function getContent()
    {
        return $this->content;
    }


    /**
     * Set sortPosition
     *
     * @param int $sortPosition
     * @return UserMedia
     */
    public function setSortPosition($sortPosition)
    {
        $this->sortPosition = $sortPosition;    
        return $this;
    }

    /**
     * Get sortPosition
     *
     * @return int 
     */
    public function getSortPosition()
    {
        return $this->sortPosition;
    }

    /**
     * Set gallery_type
     *
     * @param int $gallery_type
     * @return UserMedia
     */
    public function setGalleryType($gallery_type)
    {
        $this->gallery_type = $gallery_type;    
        return $this;
    }

    /**
     * Get gallery_type
     *
     * @return int 
     */
    public function getGalleryType()
    {
        return $this->gallery_type;
    }
    
   /**
     * Constructor
     */
    public function __construct()
    {
        $this->comments = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    
    /**
     * Set image
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $image
     * @return UserMedia
     */
    public function setImage(\Application\Sonata\MediaBundle\Entity\Media $image = null)
    {
        $this->image = $image;
        return $this;
    }

    /**
     * Get image
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getImage()
    {
        return $this->image;
    }
    
    /**
     * Set video
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $video
     * @return WallPost
     */
    public function setVideo(\Application\Sonata\MediaBundle\Entity\Media $video = null)
    {
        $this->video = $video;
    
        return $this;
    }

    /**
     * Get video
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getVideo()
    {
        return $this->video;
    }


    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return UserMedia
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user = null)
    {
        $this->user = $user;    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }


    public function __toString()
    {
        if(isset($this->id))
        {
            return (string) $this->id;
        }
        return '';
    }
}