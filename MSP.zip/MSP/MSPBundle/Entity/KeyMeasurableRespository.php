<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 2/18/14
 * Time: 1:44 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\Query\ResultSetMappingBuilder;

class KeyMeasurableRespository extends EntityRepository{

    public function getUserKeyMeasurableList(User $user)
    {
        $userKeyMeasurableList = array();
        $userSportIdList = array();

        $userSportLists  = $user->getSports();

        if($userSportLists){
            foreach($userSportLists as $sport){
                array_push($userSportIdList, $sport->getId());
            } 
        }

        if($userSportIdList)         
            $userSportsId = implode($userSportIdList, ',');
        else
            $userSportsId = 0;

        $allKeyMeasurables = $this->getEntityManager()
            ->createQuery(
                "SELECT km
                 FROM MSPBundle:KeyMeasurable km
                "
            )
            ->getResult();

        if($allKeyMeasurables){
            foreach($allKeyMeasurables as $keyMeasurables){
                foreach ($keyMeasurables->getSports() as $sports) {
                    if(in_array($sports->getId(), $userSportIdList)){
                        array_push($userKeyMeasurableList, $keyMeasurables->getId());
                    }
                }                
            } 
        }

        $userKeyMeasurableList = array_unique($userKeyMeasurableList);
        if($userKeyMeasurableList)         
            $userKeMeasurableId = implode($userKeyMeasurableList, ',');
        else
            $userKeMeasurableId = 0;

        // print_r($userKeMeasurableId);

        return $this->getEntityManager()
            ->createQuery(
                "SELECT km
                 FROM MSPBundle:KeyMeasurable km
                 WHERE km.isPhysical != 1
                 AND ( km.isGlobal = 1 OR km.id IN (".$userKeMeasurableId.") )
                "
            )
            ->getResult();
    }
}