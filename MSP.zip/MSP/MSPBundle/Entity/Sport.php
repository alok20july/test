<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/3/13
 * Time: 4:25 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_sport")
 */
class Sport {

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50, nullable=false)
     */
    protected $name;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    protected $description;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isTeamSport;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isPerEventSport;

    /**
     * @ORM\OneToMany(targetEntity="SportPosition", mappedBy="sport")
     */
    protected $sportpositions;

    /**
     * @ORM\OneToMany(targetEntity="SportStat", mappedBy="sport")
     * @ORM\OrderBy({"sortOrder" = "ASC"})
     */
    protected $sportStats;


    /**
     * @ORM\ManyToOne(targetEntity="MSP\MSPBundle\Entity\Season", cascade={"persist"})
     */
    protected $season;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Sport
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Sport
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set isTeamSport
     *
     * @param boolean $isTeamSport
     * @return Sport
     */
    public function setIsTeamSport($isTeamSport)
    {
        $this->isTeamSport = $isTeamSport;
    
        return $this;
    }

    /**
     * Get isTeamSport
     *
     * @return boolean 
     */
    public function getIsTeamSport()
    {
        return $this->isTeamSport;
    }

    /**
     * Set isPerEventSport
     *
     * @param boolean $isPerEventSport
     * @return Sport
     */
    public function setIsPerEventSport($isPerEventSport)
    {
        $this->isPerEventSport = $isPerEventSport;
    
        return $this;
    }

    /**
     * Get isPerEventSport
     *
     * @return boolean 
     */
    public function getIsPerEventSport()
    {
        return $this->isPerEventSport;
    }

    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->sportpositions = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Add sportpositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportpositions
     * @return Sport
     */
    public function addSportposition(\MSP\MSPBundle\Entity\SportPosition $sportpositions)
    {
        $this->sportpositions[] = $sportpositions;
    
        return $this;
    }

    /**
     * Remove sportpositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportpositions
     */
    public function removeSportposition(\MSP\MSPBundle\Entity\SportPosition $sportpositions)
    {
        $this->sportpositions->removeElement($sportpositions);
    }

    /**
     * Get sportpositions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportpositions()
    {
        return $this->sportpositions;
    }


    /**
     * Add sportStats
     *
     * @param \MSP\MSPBundle\Entity\SportStat $sportStats
     * @return Sport
     */
    public function addSportStat(\MSP\MSPBundle\Entity\SportStat $sportStats)
    {
        $this->sportStats[] = $sportStats;
    
        return $this;
    }

    /**
     * Remove sportStats
     *
     * @param \MSP\MSPBundle\Entity\SportStat $sportStats
     */
    public function removeSportStat(\MSP\MSPBundle\Entity\SportStat $sportStats)
    {
        $this->sportStats->removeElement($sportStats);
    }

    /**
     * Get sportStats
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportStats()
    {
        return $this->sportStats;
    }

    /**
     * Set season
     *
     * @param \MSP\MSPBundle\Entity\Season $season
     * @return Sport
     */
    public function setSeason(\MSP\MSPBundle\Entity\Season $season = null)
    {
        $this->season = $season;
    
        return $this;
    }

    /**
     * Get season
     *
     * @return \MSP\MSPBundle\Entity\Season 
     */
    public function getSeason()
    {
        return $this->season;
    }
}