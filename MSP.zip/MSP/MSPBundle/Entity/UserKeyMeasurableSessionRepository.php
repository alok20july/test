<?php
/**
 * Created by Alok Kumar
 * User: alok
 * Date: 6/26/14
 * Time: 12:25 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use MSP\MSPBundle\Entity\User;
use MSP\MSPBundle\Entity\KeyMeasurable;
use MSP\MSPBundle\Entity\KeyMeasurableValue;
use MSP\MSPBundle\Entity\UserKeyMeasurableSession;

use Doctrine\ORM\EntityRepository;

class UserKeyMeasurableSessionRepository extends EntityRepository{

    public function getUserSessionChart($userId)
    {
        $results = $this->getEntityManager()
        ->createQuery(
            'SELECT ukms
            FROM MSPBundle:UserKeyMeasurableSession ukms
            WHERE ukms.user = :user
            AND ukms.isStatus = 1
            '
        )
        ->setParameters(
            array(
                'user' => $userId
            )
        )
        ->getResult();
        
        $ids = array();
        foreach ($results as $result){
            array_push($ids, $result->getKeyMeasurable()->getId());
        }

        if($ids){
            $ids = implode(',', $ids);
            $results = $this->getEntityManager()
                ->createQuery(
                    'SELECT kmv
                    FROM MSPBundle:KeyMeasurableValue kmv
                    JOIN MSPBundle:TrainingSession ts
                    WHERE ts.id = kmv.keyTrainingSession
                    AND kmv.user = :user
                    AND kmv.keyMeasurable IN ('.$ids.')
                    ORDER BY ts.sessionCreated DESC
                    '
                )
                ->setParameters(
                    array(
                        'user' => $userId
                    )
                )
                ->getResult();
            return $results;
        } else{
            return false;
        }
    }


    public function getChartListByUser(User $user){
        return $this->getEntityManager()
            ->createQuery(
                "SELECT ukms                 
                 FROM MSPBundle:UserKeyMeasurableSession ukms
                 JOIN MSPBundle:KeyMeasurableValue kmv
                 WHERE ukms.keyMeasurable = kmv.keyMeasurable
                 AND ukms.user = kmv.user
                 AND ukms.user = :user
                 AND kmv.keyTrainingSession != ''
                 GROUP BY ukms.keyMeasurable
                "
            )
            ->setParameter('user', $user)
            ->getResult();
    }
}