<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/11/13
 * Time: 11:25 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_career_stat_value")
 */
class CareerStatValue
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string")
     */
    protected $value;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $calculatedValue;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $useCalculated;

    /**
     * @ORM\ManyToOne(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * @ORM\ManyToOne(targetEntity="SportStat",  inversedBy="careerStatValues")
     * @ORM\JoinColumn(name="sport_stat_id", referencedColumnName="id")
     */
    protected $sportStat;

    public function __toString()
    {
        if(isset($this->value))
        {
            return $this->value;
        }

        return '';
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set value
     *
     * @param integer $value
     * @return CareerStatValue
     */
    public function setValue($value)
    {
        $this->value = $value;
    
        return $this;
    }

    /**
     * Get value
     *
     * @return integer 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set calculatedValue
     *
     * @param integer $calculatedValue
     * @return CareerStatValue
     */
    public function setCalculatedValue($calculatedValue)
    {
        $this->calculatedValue = $calculatedValue;
    
        return $this;
    }

    /**
     * Get calculatedValue
     *
     * @return integer 
     */
    public function getCalculatedValue()
    {
        return $this->calculatedValue;
    }

    /**
     * Set useCalculated
     *
     * @param boolean $useCalculated
     * @return CareerStatValue
     */
    public function setUseCalculated($useCalculated)
    {
        $this->useCalculated = $useCalculated;
    
        return $this;
    }

    /**
     * Get useCalculated
     *
     * @return boolean 
     */
    public function getUseCalculated()
    {
        return $this->useCalculated;
    }

    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return CareerStatValue
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user = null)
    {
        $this->user = $user;
    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set sportStat
     *
     * @param \MSP\MSPBundle\Entity\SportStat $sportStat
     * @return CareerStatValue
     */
    public function setSportStat(\MSP\MSPBundle\Entity\SportStat $sportStat = null)
    {
        $this->sportStat = $sportStat;
    
        return $this;
    }

    /**
     * Get sportStat
     *
     * @return \MSP\MSPBundle\Entity\SportStat 
     */
    public function getSportStat()
    {
        return $this->sportStat;
    }
}