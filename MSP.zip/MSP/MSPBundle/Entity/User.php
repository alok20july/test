<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/2/13
 * Time: 12:43 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

#use FOS\UserBundle\Model\User as BaseUser;
use Application\Sonata\MediaBundle\Entity\Gallery;
use Doctrine\Common\Collections\ArrayCollection;
use Sonata\UserBundle\Entity\BaseUser;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints\Date;
use Gedmo\Mapping\Annotation as Gedmo;
use MSP\MSPBundle\Entity\School;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="fos_user")
 * @ORM\Entity(repositoryClass="UserRepository")
 */
class User extends BaseUser
{


    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=50, nullable=false)
     */
   // protected $firstName;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $middleName;

    /**
     * @Gedmo\Slug(fields={"firstname", "lastname"})
     * @ORM\Column(length=128, unique=true)
     */
    private $slug;

    /**
     * @ORM\Column(type="string", length=50, nullable=false)
     */
    //protected $lastName;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $nickName;


    /**
     * @ORM\Column(type="string", length=10, nullable=true)
     */
    protected $height;

    /**
     * @ORM\Column(type="decimal", precision=8, scale=2, nullable=true)
     * @Assert\Range(min="0", minMessage="Value should be greate than 0")
     */
    protected $weight;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    protected $bio;


    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $address;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $address2;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $city;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $stateRegion;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $country;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $postalCode;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $twitterHandle;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $ncaaClearinghouseId;


    /**
     * @ORM\ManyToMany(targetEntity="MSP\MSPBundle\Entity\Group")
     * @ORM\JoinTable(name="user_group_fos_user",
     *      joinColumns={@ORM\JoinColumn(name="user_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="group_id", referencedColumnName="id")}
     * )
     */
    protected $groups;

    /**
     *
     *
     * @ORM\ManyToMany(targetEntity="Sport")
     * @ORM\JoinTable(name="msp_sport_fos_user",
     *      joinColumns={@ORM\JoinColumn(name="user_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="sport_id", referencedColumnName="id")}
     * )
     */
    protected $sports;

    /**
     *
     * @ORM\ManyToOne(targetEntity="Sport")
     * @ORM\JoinColumn(name="main_sport_id", referencedColumnName="id")
     */
    protected $mainSport;

    /**
     * @ORM\ManyToMany(targetEntity="SportPosition", cascade={"all"})
     * @ORM\JoinTable(name="msp_sport_position_fos_user",
     *      joinColumns={@ORM\JoinColumn(name="user_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="sport_position_id", referencedColumnName="id")}
     * )
     */
    protected $sportpositions;

    /**
     * @ORM\OneToOne(targetEntity="UserAcademicInformation", mappedBy="user", cascade={"all"})
     */
    protected $userAcademicInformation;

    /**
     * @ORM\OneToMany(targetEntity="UserTeamSeason", mappedBy="user", cascade={"all"})
     */
    protected $userTeamSeason;
    
    /**
     * @ORM\OneToMany(targetEntity="KeyMeasurableValue", mappedBy="user", cascade={"all"})
     */
    protected $keyMeasurableValues;

    /**
     * @ORM\OneToMany(targetEntity="Game", mappedBy="creator")
     */
    protected $games;

    /**
     * @ORM\OneToMany(targetEntity="Meet", mappedBy="creator")
     */
    protected $meets;

    /**
     * @ORM\OneToMany(targetEntity="WallPost", mappedBy="user")
     * @ORM\OrderBy({"created" = "DESC"})
     */
    protected $posts;

    /**
     * @ORM\ManyToMany(targetEntity="Meet", mappedBy="competitors")
     */
    protected $races;

    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    protected $image;

    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    protected $mspHeaderImage;

    /**
     * @ORM\Column(type="string", length=20, nullable=true)
     */
    protected $standing;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isEmailConfirmed;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isFirstTimeUser;

    /**
     * Stores all the media added thru the wall posts or thru media page.
     * @ORM\ManyToMany(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     * @ORM\JoinTable(name="msp_user_media")
     */
    protected $myMedia;


    /**
     * Gallery of mySportPage media
     * @ORM\OneToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Gallery", cascade={"persist"})
     */
    protected $mspGallery;


    /**
     *
     * @ORM\ManyToMany(targetEntity="Team", cascade={"all"})
     * @ORM\JoinTable(name="msp_team_fos_user",
     *      joinColumns={@ORM\JoinColumn(name="user_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="team_id", referencedColumnName="id")}
     * )
     */
    protected $teams;


    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $extraCurricular;


    /**
     *
     * @ORM\ManyToOne(targetEntity="School")
     * @ORM\JoinColumn(name="school_id", referencedColumnName="id")
     */

    protected $school;


    /**
     * @ORM\Column(type="float", nullable=true)
     * @Assert\Range(min="0", minMessage="Value should be greate than 0")
     */
    protected $gpa;

    /**
     * @ORM\Column(type="integer", nullable=true)
     * @Assert\Range(min="0", minMessage="Value should be greate than 0")
     */
    protected $satTotalScore;

    /**
     * @ORM\Column(type="integer", nullable=true)
     * @Assert\Range(min="0", minMessage="Value should be greate than 0")
     */
    protected $actTotalScore;

    /**
     * @ORM\Column(type="integer", nullable=true)
     * @Assert\Range(min="0", minMessage="Value should be greate than 0")
     */
    protected $classRank;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $classRankOutOf;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $inHonorClasses;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $inAPClasses;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isAnAuthor;

    /**
     * @ORM\Column(type="text",  nullable=true)
     */
    protected $academicAccomplishments;


    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="MSP\MSPBundle\Entity\Connection", mappedBy="requestedUser", cascade={"all"}, orphanRemoval=true)
     */
    protected $myRequestedConnections;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="MSP\MSPBundle\Entity\Connection", mappedBy="requesterUser", cascade={"all"}, orphanRemoval=true)
     */
    protected $myRequestingConnections;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $class;

    public function __toString()
    {
        if($this->getUsername())
        {
            return $this->getUsername();
        }

        return '';
    }


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct();

        $this->groups = new ArrayCollection();
        $this->sportpositions = new ArrayCollection();
        $this->sports = new ArrayCollection();
        $this->sportpositions = new ArrayCollection();
        $this->userTeamSeason = new ArrayCollection();
        $this->keyMeasurableValues = new ArrayCollection();
        $this->games = new ArrayCollection();
        $this->meets = new ArrayCollection();
        $this->posts = new ArrayCollection();
    }

    /**
     * Get groups
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getGroups()
    {
        return $this->groups;
    }




    /**
     * Add groups
     *
     * @param \MSP\MSPBundle\Entity\Group $groups
     * @return User
     */
    public function addGroup(\FOS\UserBundle\Model\GroupInterface  $groups)
    {
        $this->groups[] = $groups;

        return $this;
    }

    /**
     * Remove groups
     *
     * @param \MSP\MSPBundle\Entity\Group $groups
     */
    public function removeGroup(\FOS\UserBundle\Model\GroupInterface  $groups)
    {
        $this->groups->removeElement($groups);
    }

    /**
     * Set middleName
     *
     * @param string $middleName
     * @return User
     */
    public function setMiddleName($middleName)
    {
        $this->middleName = $middleName;
    
        return $this;
    }

    /**
     * Get middleName
     *
     * @return string 
     */
    public function getMiddleName()
    {
        return $this->middleName;
    }



    /**
     * Set nickName
     *
     * @param string $nickName
     * @return User
     */
    public function setNickName($nickName)
    {
        if($nickName != null)
        {
            $this->nickName = $nickName;
        }
        else
        {
            $this->nickName = User::getFirstName();
        }

        return $this;
    }

    /**
     * Get nickName
     *
     * @return string 
     */
    public function getNickName()
    {
        return $this->nickName;
    }

    /**
     * Set dob
     *
     * @param \DateTime $dob
     * @return User
     */
    public function setDob($dob)
    {
        $this->dob = $dob;
    
        return $this;
    }

    /**
     * Get dob
     *
     * @return \DateTime 
     */
    public function getDob()
    {
        return $this->dob;
    }

    /**
     * Get gender
     *
     * @return \varchar 
     */
    public function getGender()
    {
        if($this->gender == 'F')
            return 'Female';
        elseif($this->gender == 'M')
            return 'Male';
        else
            return null;
    }

    /**
     * Set height
     *
     * @param string $height
     * @return User
     */
    public function setHeight($height)
    {
        $this->height = $height;
    
        return $this;
    }

    /**
     * Get height
     *
     * @return string 
     */
    public function getHeight()
    {
        return $this->height;
    }

    /**
     * Set weight
     *
     * @param string $weight
     * @return User
     */
    public function setWeight($weight)
    {
        $this->weight = $weight;
    
        return $this;
    }

    /**
     * Get weight
     *
     * @return string 
     */
    public function getWeight()
    {
        return $this->weight;
    }

    /**
     * Set bio
     *
     * @param string $bio
     * @return User
     */
    public function setBio($bio)
    {
        $this->bio = $bio;
    
        return $this;
    }

    /**
     * Get bio
     *
     * @return string 
     */
    public function getBio()
    {
        return $this->bio;
    }

    /**
     * Set phone
     *
     * @param string $phone
     * @return User
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    
        return $this;
    }

    /**
     * Get phone
     *
     * @return string 
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set address
     *
     * @param string $address
     * @return User
     */
    public function setAddress($address)
    {
        $this->address = $address;
    
        return $this;
    }

    /**
     * Get address
     *
     * @return string 
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set city
     *
     * @param string $city
     * @return User
     */
    public function setCity($city)
    {
        $this->city = $city;
    
        return $this;
    }

    /**
     * Get city
     *
     * @return string 
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set stateRegion
     *
     * @param string $stateRegion
     * @return User
     */
    public function setStateRegion($stateRegion)
    {
        $this->stateRegion = $stateRegion;
    
        return $this;
    }

    /**
     * Get stateRegion
     *
     * @return string 
     */
    public function getStateRegion()
    {
        return $this->stateRegion;
    }

    /**
     * Set country
     *
     * @param string $country
     * @return User
     */
    public function setCountry($country)
    {
        $this->country = $country;
    
        return $this;
    }

    /**
     * Get country
     *
     * @return string 
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set postalCode
     *
     * @param string $postalCode
     * @return User
     */
    public function setPostalCode($postalCode)
    {
        $this->postalCode = $postalCode;
    
        return $this;
    }

    /**
     * Get postalCode
     *
     * @return string 
     */
    public function getPostalCode()
    {
        return $this->postalCode;
    }

    /**
     * Add sports
     *
     * @param \MSP\MSPBundle\Entity\Sport $sports
     * @return User
     */
    public function addSport(\MSP\MSPBundle\Entity\Sport $sports)
    {
        $this->sports[] = $sports;
    
        return $this;
    }

    /**
     * Remove sports
     *
     * @param \MSP\MSPBundle\Entity\Sport $sports
     */
    public function removeSport(\MSP\MSPBundle\Entity\Sport $sports)
    {
        $this->sports->removeElement($sports);
    }

    /**
     * Get sports
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSports()
    {
        return $this->sports;
    }

    /**
     * Add sportpositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportpositions
     * @return User
     */
    public function addSportposition(\MSP\MSPBundle\Entity\SportPosition $sportpositions)
    {
        $this->sportpositions[] = $sportpositions;
    
        return $this;
    }

    /**
     * Remove sportpositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportpositions
     */
    public function removeSportposition(\MSP\MSPBundle\Entity\SportPosition $sportpositions)
    {
        $this->sportpositions->removeElement($sportpositions);
    }

    /**
     * Get sportpositions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportpositions()
    {
        return $this->sportpositions;
    }

    /**
     * Set sports
     *
     * @param string $sports
     * @return User
     */
    public function setSports($sports)
    {
        $this->sports = $sports;
    
        return $this;
    }

    /**
     * Get if user has a sport
     *
     * @return boolean
     */
    public function hasSport(\MSP\MSPBundle\Entity\Sport $sport)
    {
        $mySport = $this->getSports();

        foreach($mySport as $sp)
        {
            if($sp->getId() == $sport->getId())
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Add userTeamSeason
     *
     * @param \MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason
     * @return User
     */
    public function addUserTeamSeason(\MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason)
    {


        $this->userTeamSeason[] = $userTeamSeason;
    
        return $this;
    }

    /**
     * Remove userTeamSeason
     *
     * @param \MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason
     */
    public function removeUserTeamSeason(\MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason)
    {
        $this->userTeamSeason->removeElement($userTeamSeason);
    }

    /**
     * Get userTeamSeason
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getUserTeamSeason()
    {
        return $this->userTeamSeason;
    }

    /**
     * Add keyMeasurableValues
     *
     * @param \MSP\MSPBundle\Entity\KeyMeasurableValue $keyMeasurableValues
     * @return User
     */
    public function addKeyMeasurableValue(\MSP\MSPBundle\Entity\KeyMeasurableValue $keyMeasurableValues)
    {
        $this->keyMeasurableValues[] = $keyMeasurableValues;
    
        return $this;
    }

    /**
     * Remove keyMeasurableValues
     *
     * @param \MSP\MSPBundle\Entity\KeyMeasurableValue $keyMeasurableValues
     */
    public function removeKeyMeasurableValue(\MSP\MSPBundle\Entity\KeyMeasurableValue $keyMeasurableValues)
    {
        $this->keyMeasurableValues->removeElement($keyMeasurableValues);
    }

    /**
     * Get keyMeasurableValues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getKeyMeasurableValues()
    {
        return $this->keyMeasurableValues;
    }

    /**
     * Get if user has a sportPosition
     *
     * @return boolean
     */
    public function hasSportPosition(\MSP\MSPBundle\Entity\SportPosition $sportPosition)
    {
        $mySportPositions = $this->getSportpositions();

        foreach($mySportPositions as $sp)
        {
            if($sp->getId() == $sportPosition->getId())
            {
                return true;
            }
        }
        return false;
    }

    /**
     * @param \MSP\MSPBundle\Entity\KeyMeasurable $keyMeasurable
     *
     * @return \MSP\MSPBundle\Entity\KeyMeasurableValue or null $value
     */

    public function getValueForKeyMeasurable($keyMeasurable)
    {
        $values = $this->getKeyMeasurableValues();
        $i = 0;
        foreach($values as $v)
        {
            if ($keyMeasurable == $values->get($i)->getKeyMeasurable())
            {
                return $values->get($i);
            }
            ++$i;
        }
        return null;
    }

    /**
     * Set userAcademicInformation
     *
     * @param \MSP\MSPBundle\Entity\UserAcademicInformation $userAcademicInformation
     * @return User
     */
    public function setUserAcademicInformation(\MSP\MSPBundle\Entity\UserAcademicInformation $userAcademicInformation = null)
    {
        $this->userAcademicInformation = $userAcademicInformation;
    
        return $this;
    }

    /**
     * Get userAcademicInformation
     *
     * @return \MSP\MSPBundle\Entity\UserAcademicInformation 
     */
    public function getUserAcademicInformation()
    {
        return $this->userAcademicInformation;
    }

    /**
     * Add games
     *
     * @param \MSP\MSPBundle\Entity\Game $games
     * @return User
     */
    public function addGame(\MSP\MSPBundle\Entity\Game $games)
    {
        $this->games[] = $games;
    
        return $this;
    }

    /**
     * Remove games
     *
     * @param \MSP\MSPBundle\Entity\Game $games
     */
    public function removeGame(\MSP\MSPBundle\Entity\Game $games)
    {
        $this->games->removeElement($games);
    }

    /**
     * Get games
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getGames()
    {
        return $this->games;
    }

    /**
     * Add posts
     *
     * @param \MSP\MSPBundle\Entity\WallPost $posts
     * @return User
     */
    public function addPost(\MSP\MSPBundle\Entity\WallPost $posts)
    {
        $this->posts[] = $posts;
    
        return $this;
    }

    /**
     * Remove posts
     *
     * @param \MSP\MSPBundle\Entity\WallPost $posts
     */
    public function removePost(\MSP\MSPBundle\Entity\WallPost $posts)
    {
        $this->posts->removeElement($posts);
    }

    /**
     * Get posts
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPosts()
    {

        return $this->posts;
    }

    /**
     * Add meets
     *
     * @param \MSP\MSPBundle\Entity\Meet $meets
     * @return User
     */
    public function addMeet(\MSP\MSPBundle\Entity\Meet $meets)
    {
        $this->meets[] = $meets;
    
        return $this;
    }

    /**
     * Remove meets
     *
     * @param \MSP\MSPBundle\Entity\Meet $meets
     */
    public function removeMeet(\MSP\MSPBundle\Entity\Meet $meets)
    {
        $this->meets->removeElement($meets);
    }

    /**
     * Get meets
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMeets()
    {
        return $this->meets;
    }

    /**
     * Add races
     *
     * @param \MSP\MSPBundle\Entity\Meet $races
     * @return User
     */
    public function addRace(\MSP\MSPBundle\Entity\Meet $races)
    {
        $this->races[] = $races;
    
        return $this;
    }

    /**
     * Remove races
     *
     * @param \MSP\MSPBundle\Entity\Meet $races
     */
    public function removeRace(\MSP\MSPBundle\Entity\Meet $races)
    {
        $this->races->removeElement($races);
    }

    /**
     * Get races
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getRaces()
    {
        return $this->races;
    }

    /**
     * Set image
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $image
     * @return User
     */
    public function setImage(\Application\Sonata\MediaBundle\Entity\Media $image = null)
    {
        $this->image = $image;
    
        return $this;
    }

    /**
     * Get image
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set standing
     *
     * @param string $standing
     * @return User
     */
    public function setStanding($standing)
    {
        $this->standing = $standing;
    
        return $this;
    }

    /**
     * Get standing
     *
     * @return string 
     */
    public function getStanding()
    {
        return $this->standing;
    }

    /*public function getAge()
    {
        //die($this->getDob());
        return date('Y')- (date_format($this->getDob()))->getYear();
    }*/

    public function recentTeamSeason()
    {
        return $this->getUserTeamSeason()->get(count($this->getUserTeamSeason()) - 1);
    }


    public function getMainSport()
    {
        if($this->mainSport){
            return $this->mainSport;
        }

        return $this->getSports()->first();
    }



    /**
     * Set twitterHandle
     *
     * @param string $twitterHandle
     * @return User
     */
    public function setTwitterHandle($twitterHandle)
    {
        $this->twitterHandle = $twitterHandle;
    
        return $this;
    }

    /**
     * Get twitterHandle
     *
     * @return string 
     */
    public function getTwitterHandle()
    {
        return $this->twitterHandle;
    }

    /**
     * Set ncaaClearinghouseId
     *
     * @param string $ncaaClearinghouseId
     * @return User
     */
    public function setNcaaClearinghouseId($ncaaClearinghouseId)
    {
        $this->ncaaClearinghouseId = $ncaaClearinghouseId;
    
        return $this;
    }

    /**
     * Get ncaaClearinghouseId
     *
     * @return string 
     */
    public function getNcaaClearinghouseId()
    {
        return $this->ncaaClearinghouseId;
    }

    /**
     * Set mainSport
     *
     * @param \MSP\MSPBundle\Entity\Sport $mainSport
     * @return User
     */
    public function setMainSport(\MSP\MSPBundle\Entity\Sport $mainSport = null)
    {
        $this->mainSport = $mainSport;
    
        return $this;
    }

    /**
     * Set address2
     *
     * @param string $address2
     * @return User
     */
    public function setAddress2($address2)
    {
        $this->address2 = $address2;
    
        return $this;
    }

    /**
     * Get address2
     *
     * @return string 
     */
    public function getAddress2()
    {
        return $this->address2;
    }

    /**
     * Set isEmailConfirmed
     *
     * @param boolean $isEmailConfirmed
     * @return User
     */
    public function setIsEmailConfirmed($isEmailConfirmed)
    {
        $this->isEmailConfirmed = $isEmailConfirmed;
    
        return $this;
    }

    /**
     * Get isEmailConfirmed
     *
     * @return boolean 
     */
    public function getIsEmailConfirmed()
    {
        return $this->isEmailConfirmed;
    }

    /**
     * Set isFirstTimeUser
     *
     * @param boolean $isFirstTimeUser
     * @return User
     */
    public function setIsFirstTimeUser($isFirstTimeUser)
    {
        $this->isFirstTimeUser = $isFirstTimeUser;
    
        return $this;
    }

    /**
     * Get isFirstTimeUser
     *
     * @return boolean 
     */
    public function getIsFirstTimeUser()
    {
        return $this->isFirstTimeUser;
    }

    public function initAthlete()
    {
        $this->setIsFirstTimeUser(true);
        $this->setGender('M');
        $gallery = new Gallery();
        $gallery->setEnabled(true);
        $gallery->setContext('msp');
        $gallery->setDefaultFormat('big');
        $gallery->setName('MSP-'.$this->getUserName());
        $this->setMspGallery($gallery);
    }

    public function getStatsForSport(Sport $sport)
    {
        $sportPositions = $this->getSportpositions();
        $mySportStats = $sport->getSportStats()->filter(
            function($entry) use ($sportPositions) {
                if($entry->getIsGlobal() && !$entry->getIsCalculation()){
                    return true;
                }else{
                    foreach($entry->getSportPositions() as $position)
                    {
                        if($sportPositions->contains($position) && !$entry->getIsCalculation())
                            return true;
                    }

                    return false;
                }
            }
        );

        return $mySportStats;
    }

    public function getMyTeamOptions()
    {
        $teams = array();

        foreach($this->getUserTeamSeason() as $teamSeason){
            $team = $teamSeason->getTeam();
            $teams[$team->getId()] = $team;
        }

        return $teams;
    }

    /**
     * Sets the email.
     *
     * @param string $email
     * @return User
     */
    public function setEmail($email)
    {
        $this->setUsername($email);

        return parent::setEmail($email);
    }

    /**
     * Set the canonical email.
     *
     * @param string $emailCanonical
     * @return User
     */
    public function setEmailCanonical($emailCanonical)
    {
        $this->setUsernameCanonical($emailCanonical);

        return parent::setEmailCanonical($emailCanonical);
    }




    /**
     * Add teams
     *
     * @param \MSP\MSPBundle\Entity\Team $teams
     * @return User
     */
    public function addTeam(\MSP\MSPBundle\Entity\Team $teams)
    {
        $this->teams[] = $teams;
    
        return $this;
    }

    /**
     * Remove teams
     *
     * @param \MSP\MSPBundle\Entity\Team $teams
     */
    public function removeTeam(\MSP\MSPBundle\Entity\Team $teams)
    {
        $this->teams->removeElement($teams);
    }

    /**
     * Get teams
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getTeams()
    {
        return $this->teams;
    }

    public function getSlug()
    {
        return $this->slug;
    }

    public function getAge(){
        $yearBorn = $this->getDateOfBirth();
        $age = null;
        if($yearBorn){
            $age = date("Y") - $yearBorn->format("Y");
        }
        return $age;
    }

    public function getJerseyNumber(){
        $this->getTeams();
    }

    /**
     * Set slug
     *
     * @param string $slug
     * @return User
     */
    public function setSlug($slug)
    {
        $this->slug = $slug;
    
        return $this;
    }

    /**
     * Set mspHeaderImage
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $mspHeaderImage
     * @return User
     */
    public function setMspHeaderImage(\Application\Sonata\MediaBundle\Entity\Media $mspHeaderImage = null)
    {
        $this->mspHeaderImage = $mspHeaderImage;
    
        return $this;
    }

    /**
     * Get mspHeaderImage
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getMspHeaderImage()
    {
        return $this->mspHeaderImage;
    }

    /**
     * Add myMedia
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $myMedia
     * @return User
     */
    public function addMyMedia(\Application\Sonata\MediaBundle\Entity\Media $myMedia)
    {
        $this->myMedia[] = $myMedia;
    
        return $this;
    }

    /**
     * Remove myMedia
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $myMedia
     */
    public function removeMyMedia(\Application\Sonata\MediaBundle\Entity\Media $myMedia)
    {
        $this->myMedia->removeElement($myMedia);
    }

    /**
     * Get myMedia
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMyMedia()
    {
        return $this->myMedia;
    }

    /**
     * Set mspGallery
     *
     * @param \Application\Sonata\MediaBundle\Entity\Gallery $mspGallery
     * @return User
     */
    public function setMspGallery(\Application\Sonata\MediaBundle\Entity\Gallery $mspGallery = null)
    {
        $this->mspGallery = $mspGallery;
    
        return $this;
    }

    /**
     * Get mspGallery
     *
     * @return \Application\Sonata\MediaBundle\Entity\Gallery 
     */
    public function getMspGallery()
    {
        return $this->mspGallery;
    }

    /**
     * Set extraCurricular
     *
     * @param string $extraCurricular
     * @return User
     */
    public function setExtraCurricular($extraCurricular)
    {
        $this->extraCurricular = $extraCurricular;
    
        return $this;
    }

    /**
     * Get extraCurricular
     *
     * @return string 
     */
    public function getExtraCurricular()
    {
        return $this->extraCurricular;
    }

    /**
     * Set school
     *
     * @param \MSP\MSPBundle\Entity\School $school
     * @return User
     */
    public function setSchool(\MSP\MSPBundle\Entity\School $school = null)
    {
        $this->school = $school;
    
        return $this;
    }

    /**
     * Get school
     *
     * @return \MSP\MSPBundle\Entity\School 
     */
    public function getSchool()
    {
        return $this->school;
    }

    /**
     * Set class
     *
     * @param string $class
     * @return User
     */
    public function setClass($class)
    {
        $this->class = $class;
    
        return $this;
    }

    /**
     * Get class
     *
     * @return string 
     */
    public function getClass()
    {
        return $this->class;
    }

    /**
     * Set gpa
     *
     * @param float $gpa
     * @return User
     */
    public function setGpa($gpa)
    {
        $this->gpa = $gpa;
    
        return $this;
    }

    /**
     * Get gpa
     *
     * @return float 
     */
    public function getGpa()
    {
        return $this->gpa;
    }

    /**
     * Set satTotalScore
     *
     * @param integer $satTotalScore
     * @return User
     */
    public function setSatTotalScore($satTotalScore)
    {
        $this->satTotalScore = $satTotalScore;
    
        return $this;
    }

    /**
     * Get satTotalScore
     *
     * @return integer 
     */
    public function getSatTotalScore()
    {
        return $this->satTotalScore;
    }

    /**
     * Set actTotalScore
     *
     * @param integer $actTotalScore
     * @return User
     */
    public function setActTotalScore($actTotalScore)
    {
        $this->actTotalScore = $actTotalScore;
    
        return $this;
    }

    /**
     * Get actTotalScore
     *
     * @return integer 
     */
    public function getActTotalScore()
    {
        return $this->actTotalScore;
    }

    /**
     * Set classRank
     *
     * @param integer $classRank
     * @return User
     */
    public function setClassRank($classRank)
    {
        $this->classRank = $classRank;
    
        return $this;
    }

    /**
     * Get classRank
     *
     * @return integer 
     */
    public function getClassRank()
    {
        return $this->classRank;
    }

    /**
     * Set classRankOutOf
     *
     * @param integer $classRankOutOf
     * @return User
     */
    public function setClassRankOutOf($classRankOutOf)
    {
        $this->classRankOutOf = $classRankOutOf;
    
        return $this;
    }

    /**
     * Get classRankOutOf
     *
     * @return integer 
     */
    public function getClassRankOutOf()
    {
        return $this->classRankOutOf;
    }

    /**
     * Set inHonorClasses
     *
     * @param boolean $inHonorClasses
     * @return User
     */
    public function setInHonorClasses($inHonorClasses)
    {
        $this->inHonorClasses = $inHonorClasses;
    
        return $this;
    }

    /**
     * Get inHonorClasses
     *
     * @return boolean 
     */
    public function getInHonorClasses()
    {
        return $this->inHonorClasses;
    }

    /**
     * Set inAPClasses
     *
     * @param boolean $inAPClasses
     * @return User
     */
    public function setInAPClasses($inAPClasses)
    {
        $this->inAPClasses = $inAPClasses;
    
        return $this;
    }

    /**
     * Get inAPClasses
     *
     * @return boolean 
     */
    public function getInAPClasses()
    {
        return $this->inAPClasses;
    }

    /**
     * Set academicAccomplishments
     *
     * @param string $academicAccomplishments
     * @return User
     */
    public function setAcademicAccomplishments($academicAccomplishments)
    {
        $this->academicAccomplishments = $academicAccomplishments;
    
        return $this;
    }

    /**
     * Get academicAccomplishments
     *
     * @return string 
     */
    public function getAcademicAccomplishments()
    {
        return $this->academicAccomplishments;
    }

    /**
     * Add myRequestedConnections
     *
     * @param \MSP\MSPBundle\Entity\Connection $myRequestedConnections
     * @return User
     */
    public function addMyRequestedConnection(\MSP\MSPBundle\Entity\Connection $myRequestedConnections)
    {
        $this->myRequestedConnections[] = $myRequestedConnections;
    
        return $this;
    }

    /**
     * Remove myRequestedConnections
     *
     * @param \MSP\MSPBundle\Entity\Connection $myRequestedConnections
     */
    public function removeMyRequestedConnection(\MSP\MSPBundle\Entity\Connection $myRequestedConnections)
    {
        $this->myRequestedConnections->removeElement($myRequestedConnections);
    }

    /**
     * Get myRequestedConnections
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMyRequestedConnections()
    {
        return $this->myRequestedConnections;
    }

    /**
     * Add myRequestingConnections
     *
     * @param \MSP\MSPBundle\Entity\Connection $myRequestingConnections
     * @return User
     */
    public function addMyRequestingConnection(\MSP\MSPBundle\Entity\Connection $myRequestingConnections)
    {
        $this->myRequestingConnections[] = $myRequestingConnections;
    
        return $this;
    }

    /**
     * Remove myRequestingConnections
     *
     * @param \MSP\MSPBundle\Entity\Connection $myRequestingConnections
     */
    public function removeMyRequestingConnection(\MSP\MSPBundle\Entity\Connection $myRequestingConnections)
    {
        $this->myRequestingConnections->removeElement($myRequestingConnections);
    }

    /**
     * Get myRequestingConnections
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMyRequestingConnections()
    {
        return $this->myRequestingConnections;
    }
}