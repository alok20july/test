<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/11/13
 * Time: 11:25 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_season_stat_value")
 */
class SeasonStatValue
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=10, nullable=true)
     */
    protected $value;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $useCalculated;

    /**
     * @ORM\ManyToOne(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * @ORM\ManyToOne(targetEntity="SportStat",  inversedBy="seasonStatValues")
     * @ORM\JoinColumn(name="sport_stat_id", referencedColumnName="id")
     * @ORM\OrderBy({"sortOrder" = "ASC"})
     */
    protected $sportStat;

    /**
     * @ORM\ManyToOne(targetEntity="UserTeamSeason", inversedBy="seasonStats")
     * @ORM\JoinColumn(name="user_team_season_id", referencedColumnName="id", onDelete="CASCADE")
     */
    protected $userTeamSeason;

    public function __toString()
    {
        if(isset($this->value))
        {
            return $this->value;
        }

        return '';
    }


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set value
     *
     * @param string $value
     * @return SeasonStatValue
     */
    public function setValue($value)
    {
        $this->value = $value;
    
        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        /*$games = 0;
        $total = 0;
        if($this->getUseCalculated())
        {
            foreach($this->getUserTeamSeason()->getGames() as $game)
            {
                foreach ($game->getGameStatValues() as $value)
                {
                    if ($value->getSportStat() == $this->getSportStat() && $value->getValue() != null)
                    {
                        ++$games;
                        $total += (float) $value;
                    }
                }
            }
        }
        //$this->value = $total/$games;
        var_dump('Total Games' . $games);
        var_dump('Total Value' . $value);
        var_dump(' ' . $total/$games . ' ');*/

        return $this->value;
    }

    /**
     * Set useCalculated
     *
     * @param boolean $useCalculated
     * @return SeasonStatValue
     */
    public function setUseCalculated($useCalculated)
    {
        $this->useCalculated = $useCalculated;
    
        return $this;
    }

    /**
     * Get useCalculated
     *
     * @return boolean 
     */
    public function getUseCalculated()
    {
        return $this->useCalculated;
    }

    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return SeasonStatValue
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user = null)
    {
        $this->user = $user;
    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set sportStat
     *
     * @param \MSP\MSPBundle\Entity\SportStat $sportStat
     * @return SeasonStatValue
     */
    public function setSportStat(\MSP\MSPBundle\Entity\SportStat $sportStat = null)
    {
        $this->sportStat = $sportStat;
    
        return $this;
    }

    /**
     * Get sportStat
     *
     * @return \MSP\MSPBundle\Entity\SportStat 
     */
    public function getSportStat()
    {
        return $this->sportStat;
    }

    /**
     * Set userTeamSeason
     *
     * @param \MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason
     * @return SeasonStatValue
     */
    public function setUserTeamSeason(\MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason = null)
    {
        $this->userTeamSeason = $userTeamSeason;
    
        return $this;
    }

    /**
     * Get userTeamSeason
     *
     * @return \MSP\MSPBundle\Entity\UserTeamSeason 
     */
    public function getUserTeamSeason()
    {
        return $this->userTeamSeason;
    }
}