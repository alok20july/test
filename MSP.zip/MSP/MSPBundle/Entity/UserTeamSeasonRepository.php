<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 2/18/14
 * Time: 1:44 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;

class UserTeamSeasonRepository extends EntityRepository{

    /*public function getUsersForTeamSeason($team, $season, $year)
    {
        $users =  $this->getEntityManager()
            ->createQuery(
                "SELECT u
                 FROM MSPBundle:User u
                 JOIN MSPBundle:UserTeamSeason uts
                 Where uts.user = u.id
                 AND uts.team = :team
                 AND uts.year = :year
                 AND uts.season = :season"
            )->setParameters(
                array(
                    'team' => $team,
                    'season' => $season,
                    'year' => $year
            ))
            ->getResult();

        return $users;
    }*/

    public function getUsersForTeamSeason($school, $sport)
    {
        $users =  $this->getEntityManager()
            ->createQuery(
                "SELECT u
                 FROM MSPBundle:User u
                 JOIN MSPBundle:UserTeamSeason uts
                 Where uts.user = u.id
                 AND uts.school = :school
                 AND uts.sport = :sport
                 "
            )->setParameters(
                array(
                    'school' => $school,
                    'sport' => $sport
            ))
            ->getResult();

        return $users;
    }


    public function getAllSeasonStatsValues(UserTeamSeason $uts)
    {
        $seasonStatValues =  $this->getEntityManager()
            ->createQuery(
            "SELECT ssv
             FROM MSPBundle:SeasonStatValue ssv
             WHERE ssv.userTeamSeason = :uts
            "
            )->setParameters(
            array('uts' => $uts)
            )->getResult();

        return $seasonStatValues;
    }
}