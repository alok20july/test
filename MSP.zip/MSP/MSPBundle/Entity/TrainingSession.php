<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 26/05/14
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
/**
 * @ORM\Entity
 * @ORM\Table(name="msp_key_training_session")
 */
class TrainingSession
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;


    /**
     * @ORM\Column(type="date")
     */
    protected $sessionCreated;
    
    /**
     * @ORM\OneToMany(targetEntity="KeyMeasurableValue", mappedBy="keyTrainingSession")
     */
    protected $keyMeasurableValues;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

   
    public function __toString()
    {
        if(isset($this->sessionCreated))
        {
            return (string) $this->sessionCreated;
        }
        return '';
    }

    /**
     * Get sessionCreated     
     *
     * @return \Date 
     */
    
    public function getSessionCreated()
    {
        return $this->sessionCreated;
    }

    /**
     * Set updated
     *
     * @param \Date $sessionCreated
     * @return trainingSession
     */
    public function setSessionCreated($sessionCreated)
    {
        $this->sessionCreated = $sessionCreated;    
        return $this;
    }

    /**
     * Add keyMeasurableValues
     *
     * @param \MSP\MSPBundle\Entity\KeyMeasurableValue $keyMeasurableValues
     * @return Game
     */
    public function addKeyMeasurableValue(\MSP\MSPBundle\Entity\KeyMeasurableValue $keyMeasurableValues)
    {
        $this->keyMeasurableValues[] = $keyMeasurableValues;
    
        return $this;
    }

    /**
     * Remove keyMeasurableValues
     *
     * @param \MSP\MSPBundle\Entity\KeyMeasurableValue $keyMeasurableValues
     */
    public function removeKeyMeasurableValue(\MSP\MSPBundle\Entity\KeyMeasurableValue $keyMeasurableValues)
    {
        $this->keyMeasurableValues->removeElement($keyMeasurableValues);
    }

    /**
     * Get keyMeasurableValues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getKeyMeasurableValue()
    {
        return $this->keyMeasurableValues;
    }
}