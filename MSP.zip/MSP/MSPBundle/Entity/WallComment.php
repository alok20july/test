<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/11/13
 * Time: 2:26 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_wall_comment")
 */
class WallComment
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="text")
     */
    protected $content;


    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $created;

    /**
     * @ORM\ManyToOne(targetEntity="WallComment")
     * @ORM\JoinColumn(name="parent_id", referencedColumnName="id")
     */
    protected $parentID;

    /**
     * @ORM\ManyToOne(targetEntity="WallPost", inversedBy="comments")
     * @ORM\JoinColumn(name="wall_post_id", referencedColumnName="id", onDelete="CASCADE")
     */
    protected $wallPost;

    /**
     * @ORM\ManyToOne(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;


    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $thumbsUpCount;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $thumbsDownCount;

    /**
     * @ORM\JoinTable(name="msp_thumbs_up_user_comment")
     * @ORM\ManyToMany(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $thumbsUpUsers;

    /**
     * @ORM\JoinTable(name="msp_thumbs_down_user_comment")
     * @ORM\ManyToMany(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $thumbsDownUsers;


    public function __toString()
    {
        if(isset($this->id))
        {
            return (string) $this->id;
        }

        return '';
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set content
     *
     * @param string $content
     * @return WallComment
     */
    public function setContent($content)
    {
        $this->content = $content;
    
        return $this;
    }

    /**
     * Get content
     *
     * @return string 
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set wallPost
     *
     * @param \MSP\MSPBundle\Entity\WallPost $wallPost
     * @return WallComment
     */
    public function setWallPost(\MSP\MSPBundle\Entity\WallPost $wallPost = null)
    {
        $this->wallPost = $wallPost;
    
        return $this;
    }

    /**
     * Get wallPost
     *
     * @return \MSP\MSPBundle\Entity\WallPost 
     */
    public function getWallPost()
    {
        return $this->wallPost;
    }

    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return WallComment
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user = null)
    {
        $this->user = $user;
    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set parentID
     *
     * @param \MSP\MSPBundle\Entity\WallComment $parentID
     * @return WallComment
     */
    public function setParentID(\MSP\MSPBundle\Entity\WallComment $parentID = null)
    {
        $this->parentID = $parentID;
    
        return $this;
    }

    /**
     * Get parentID
     *
     * @return \MSP\MSPBundle\Entity\WallComment 
     */
    public function getParentID()
    {
        return $this->parentID;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->thumbsUpUsers = new \Doctrine\Common\Collections\ArrayCollection();
        $this->thumbsDownUsers = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Add thumbsUpUsers
     *
     * @param \MSP\MSPBundle\Entity\User $thumbsUpUsers
     * @return WallComment
     */
    public function addThumbsUpUser(\MSP\MSPBundle\Entity\User $thumbsUpUsers)
    {
        $this->thumbsUpUsers[] = $thumbsUpUsers;
    
        return $this;
    }

    /**
     * Remove thumbsUpUsers
     *
     * @param \MSP\MSPBundle\Entity\User $thumbsUpUsers
     */
    public function removeThumbsUpUser(\MSP\MSPBundle\Entity\User $thumbsUpUsers)
    {
        $this->thumbsUpUsers->removeElement($thumbsUpUsers);
    }

    /**
     * Get thumbsUpUsers
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getThumbsUpUsers()
    {
        return $this->thumbsUpUsers;
    }

    /**
     * Add thumbsDownUsers
     *
     * @param \MSP\MSPBundle\Entity\User $thumbsDownUsers
     * @return WallComment
     */
    public function addThumbsDownUser(\MSP\MSPBundle\Entity\User $thumbsDownUsers)
    {
        $this->thumbsDownUsers[] = $thumbsDownUsers;
    
        return $this;
    }

    /**
     * Remove thumbsDownUsers
     *
     * @param \MSP\MSPBundle\Entity\User $thumbsDownUsers
     */
    public function removeThumbsDownUser(\MSP\MSPBundle\Entity\User $thumbsDownUsers)
    {
        $this->thumbsDownUsers->removeElement($thumbsDownUsers);
    }

    /**
     * Get thumbsDownUsers
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getThumbsDownUsers()
    {
        return $this->thumbsDownUsers;
    }

    public function getThumbsDownCount()
    {
        return $this->thumbsDownCount;
    }

    /**
     * Set ThumbsDownCount
     *
     * @param integer $thumbsDownCount
     * @return WallComment
     */
    public function setThumbsDownCount($thumbsDownCount = null)
    {
        $this->thumbsDownCount = $thumbsDownCount;

        return $this;
    }

    public function getThumbsUpCount()
    {
        return $this->thumbsUpCount;
    }

    /**
     * Set ThumbsUpCount
     *
     * @param integer $thumbsUpCount
     * @return WallComment
     */
    public function setThumbsUpCount($thumbsUpCount = null)
    {
        $this->thumbsUpCount = $thumbsUpCount;

        return $this;
    }

    public function getCreated()
    {
        return $this->created;
    }

    public function setCreated($created)
    {
        return $this->created = $created;
    }
}