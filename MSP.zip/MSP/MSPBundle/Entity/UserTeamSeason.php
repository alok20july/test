<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/10/13
 * Time: 10:47 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Validator\Constraints as Assert;
use MSP\MSPBundle\Validator\Constraints as MSPAssert;
use MSP\MSPBundle\Entity;

/**
 * @UniqueEntity({"user", "sport", "team", "season", "year"})
 * @ORM\Entity(repositoryClass="UserTeamSeasonRepository")
 * @ORM\Table(name="msp_user_team_season",uniqueConstraints={
 * @ORM\UniqueConstraint(columns={"user_id", "sport_id", "team_id", "season_id", "year"})})
 */
class UserTeamSeason
{

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="userTeamSeason")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * @ORM\ManyToOne(targetEntity="Team")
     * @ORM\JoinColumn(name="team_id", referencedColumnName="id", nullable=false)
     */
    protected $team;

    /**
     * @ORM\ManyToOne(targetEntity="Season")
     * @ORM\JoinColumn(name="season_id", referencedColumnName="id")
     */
    protected $season;

    /**
     * @ORM\ManyToOne(targetEntity="School")
     * @ORM\JoinColumn(name="school_id", referencedColumnName="id")
     */
    protected $school;

    /**
     * @Assert\NotBlank
     * @ORM\Column(type="integer")
     * @MSPAssert\CheckYear
     */
    protected $year;

    /**
     * @ORM\ManyToMany(targetEntity="SportPosition")
     * @ORM\JoinTable(name="msp_user_team_season_position",
     *      joinColumns={@ORM\JoinColumn(name="user_team_season_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="sport_position_id", referencedColumnName="id")}
     * )
     */
    protected $sportpositions;


    /**
     * @ORM\OneToMany(targetEntity="Game", mappedBy="userTeamSeason", cascade={"persist"})
     */
    protected $games;

    /**
     * @ORM\ManyToOne(targetEntity="Sport")
     * @ORM\JoinColumn(name="sport_id", referencedColumnName="id")
     */
    protected $sport;

    /**
     * @ORM\Column(type="string", nullable=true)
     */
    protected $jerseyNumber;

    /**
     * @ORM\Column(type="string", nullable=false)
     */
    protected $level;

    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media",cascade={"persist"})
     */
    protected $logo;


    /**
     * @ORM\OneToMany(targetEntity="SeasonStatValue", mappedBy="userTeamSeason")
     */
    protected $seasonStats;

    /**
     *
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $teamClass;


    /**
     * @Assert\NotBlank
     * @ORM\Column(type="string", length=255, nullable=false)
     */
    protected $teamName;
    
    
    public function __construct(User $user = null, Team $team = null, Season $season = null)
    {
        $this->user = $user;
        $this->team = $team;
        $this->season = $season;
    }

    public function __toString()
    {

        if(isset($this->user) && isset($this->team) && isset($this->season))
        {
            return /*$this->user . ' ' .*/ $this->team . ' ' . $this->season . ' ' . $this->getYear();
        }

        return '';
    }

    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return UserTeamSeason
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user)
    {
        $this->user = $user;
    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set team
     *
     * @param \MSP\MSPBundle\Entity\Team $team
     * @return UserTeamSeason
     */
    public function setTeam(\MSP\MSPBundle\Entity\Team $team)
    {
        $this->team = $team;
    
        return $this;
    }

    /**
     * Get team
     *
     * @return \MSP\MSPBundle\Entity\Team 
     */
    public function getTeam()
    {
        return $this->team;
    }

    /**
     * Set season
     *
     * @param \MSP\MSPBundle\Entity\Season $season
     * @return UserTeamSeason
     */
    public function setSeason(\MSP\MSPBundle\Entity\Season $season)
    {
        $this->season = $season;
    
        return $this;
    }

    /**
     * Get season
     *
     * @return \MSP\MSPBundle\Entity\Season 
     */
    public function getSeason()
    {
        return $this->season;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Add sportpositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportpositions
     * @return UserTeamSeason
     */
    public function addSportposition(\MSP\MSPBundle\Entity\SportPosition $sportpositions)
    {
        $this->sportpositions[] = $sportpositions;
    
        return $this;
    }

    /**
     * Remove sportpositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportpositions
     */
    public function removeSportposition(\MSP\MSPBundle\Entity\SportPosition $sportpositions)
    {
        $this->sportpositions->removeElement($sportpositions);
    }

    /**
     * Get sportpositions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportpositions()
    {
        return $this->sportpositions;
    }

    /**
     * Get sport
     *
     * @return \MSP\MSPBundle\Entity\Sport
     */
    public function getSport()
    {
        //return $this->getTeam()->getSport();
        return $this->sport;
    }


    /**
     * Set sport
     *
     * @param \MSP\MSPBundle\Entity\Sport $sport
     * @return UserTeamSeason
     */
    public function setSport(\MSP\MSPBundle\Entity\Sport $sport = null)
    {
        $this->sport = $sport;
    
        return $this;
    }
/*
    public function getGames()
    {
        $homeGames = $this->getTeam()->getHomeGames();
        $allGames = array();
        foreach($homeGames as $game)
        {
            if($game->getSeason() == $this->getSeason() && $this->getYear() == $game->getYear())
            {
                $allGames[] = $game;
            }
        }
        $awayGames = $this->getTeam()->getAwayGames();
        foreach($awayGames as $game)
        {
            if($game->getSeason() == $this->getSeason() && $this->getYear() == $game->getYear())
            {
                $allGames[] = $game;
            }
        }
        return $allGames;
    } */

    public function getMeets()
    {
        $meets = $this->getTeam()->getMeets();
        $seasonMeets = array();
        foreach($meets as $meet)
        {

            if(($meet->getSeason() == $this->getSeason()) && ($this->getYear() ==  $meet->getYear()))
            {

                $seasonMeets[] = $meet;
            }
        }

        return $seasonMeets;
    }

    /**
     * Set year
     *
     * @param integer $year
     * @return UserTeamSeason
     */
    public function setYear($year)
    {
        $this->year = $year;
    
        return $this;
    }

    /**
     * Get year
     *
     * @return integer 
     */
    public function getYear()
    {
        return $this->year;
    }


    /**
     * Set level
     *
     * @param string $level
     * @return UserTeamSeason
     */
    public function setLevel($level)
    {
        $this->level = $level;
    
        return $this;
    }

    /**
     * Get level
     *
     * @return string 
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Set logo
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $logo
     * @return Team
     */
    public function setLogo(\Application\Sonata\MediaBundle\Entity\Media $logo = null)
    {
        $this->team->setLogo($logo);
        $this->logo = $logo;

        return $this;
    }

    /**
     * Get logo
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media
     */
    public function getLogo()
    {
        return $this->logo;
    }

    /**
     * Add seasonStats
     *
     * @param \MSP\MSPBundle\Entity\SeasonStatValue $seasonStats
     * @return UserTeamSeason
     */
    public function addSeasonStat(\MSP\MSPBundle\Entity\SeasonStatValue $seasonStats)
    {
        $this->seasonStats[] = $seasonStats;
    
        return $this;
    }

    /**
     * Remove seasonStats
     *
     * @param \MSP\MSPBundle\Entity\SeasonStatValue $seasonStats
     */
    public function removeSeasonStat(\MSP\MSPBundle\Entity\SeasonStatValue $seasonStats)
    {
        $this->seasonStats->removeElement($seasonStats);
    }

    /**
     * Get seasonStats
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSeasonStats()
    {
        return $this->seasonStats;
    }

    /**
     * Set jerseyNumber
     *
     * @param string $jerseyNumber
     * @return UserTeamSeason
     */
    public function setJerseyNumber($jerseyNumber)
    {
        $this->jerseyNumber = $jerseyNumber;
    
        return $this;
    }

    /**
     * Get jerseyNumber
     *
     * @return string 
     */
    public function getJerseyNumber()
    {
        return $this->jerseyNumber;
    }

    /**
     * Add seasonStatValues
     *
     * @param \MSP\MSPBundle\Entity\SeasonStatValue $seasonStatValues
     * @return UserTeamSeason
     */
    public function addSeasonStatValue(\MSP\MSPBundle\Entity\SeasonStatValue $seasonStatValues)
    {
        $this->seasonStatValues[] = $seasonStatValues;
    
        return $this;
    }

    /**
     * Remove seasonStatValues
     *
     * @param \MSP\MSPBundle\Entity\SeasonStatValue $seasonStatValues
     */
    public function removeSeasonStatValue(\MSP\MSPBundle\Entity\SeasonStatValue $seasonStatValues)
    {
        $this->seasonStatValues->removeElement($seasonStatValues);
    }

    /**
     * Get seasonStatValues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSeasonStatValues()
    {
        return $this->seasonStatValues;
    }

    /**
     * Add games
     *
     * @param \MSP\MSPBundle\Entity\Game $games
     * @return UserTeamSeason
     */
    public function addGame(\MSP\MSPBundle\Entity\Game $games)
    {
        $this->games[] = $games;
    
        return $this;
    }

    /**
     * Remove games
     *
     * @param \MSP\MSPBundle\Entity\Game $games
     */
    public function removeGame(\MSP\MSPBundle\Entity\Game $games)
    {
        $this->games->removeElement($games);
    }

    /**
     * Set school
     *
     * @param \MSP\MSPBundle\Entity\School $school
     * @return UserTeamSeason
     */
    public function setSchool(\MSP\MSPBundle\Entity\School $school = null)
    {
        $this->school = $school;
    
        return $this;
    }

    /**
     * Get school
     *
     * @return \MSP\MSPBundle\Entity\School 
     */
    public function getSchool()
    {
        if($this->getTeam() && $this->getTeam()->getSchool()){
            return $this->getTeam()->getSchool();
        }
        return $this->school;
    }

    /**
     * Set teamClass
     *
     * @param string $teamClass
     * @return UserTeamSeason
     */
    public function setTeamClass($teamClass)
    {
        $this->teamClass = $teamClass;
    
        return $this;
    }

    /**
     * Get teamClass
     *
     * @return string 
     */
    public function getTeamClass()
    {
        return $this->teamClass;
    }

    /*
     * @description returns all applicable stats for this user in this season (checks for position played)
     *
     */
    private function getAllMyApplicableStats()
    {
        $sportPositions = $this->getSportpositions();
        return $this->getSport()->getSportStats()->filter(
            function($entry) use ($sportPositions) {
                if($entry->getIsGlobal() || $entry->getIsCalculation()){
                    return true;
                }else{
                    foreach($entry->getSportPositions() as $position)
                    {
                        if($sportPositions->contains($position))
                            return true;
                    }
                    return false;
                }
            }
        );
    }

    public function getApplicableSeasonStats()
    {
        $seasonStats = array();
        $stats = $this->getAllMyApplicableStats();

        if($stats){
            $seasonStats = $stats->filter(
                function($entry) {
                    if($entry->getStatCategory() == SportStat::MEET_STAT || $entry->getStatCategory() == SportStat::ALL_STAT){
                        return true;
                    }
                    return false;
                }
            );
        }

        return $seasonStats;
    }

    public function getApplicableGameStats()
    {
        $gameStats = null;
        $stats = $this->getAllMyApplicableStats();

        if($stats){
            $gameStats = $stats->filter(
                function($entry) {
                    if($entry->getStatCategory() == SportStat::GAME_STAT || $entry->getStatCategory() == SportStat::ALL_STAT){
                        return true;
                    }
                    return false;
                }
            );
        }

        return $gameStats;
    }

    public function getApplicableMeetStats()
    {
        $meetStats = array();
        $stats = $this->getAllMyApplicableStats();

        if($stats){
            $meetStats = $stats->filter(
                function($entry) {
                    if($entry->getStatCategory() == SportStat::MEET_STAT || $entry->getStatCategory() == SportStat::ALL_STAT){
                        return true;
                    }
                    return false;
                }
            );
        }

        return $meetStats;
    }


    /**
     * Get games
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getGames()
    {
        return $this->games;
    }

    /**
     * Set teamName
     *
     * @param string $teamName
     * @return UserTeamSeason
     */
    public function setTeamName($teamName)
    {
        $this->teamName = $teamName;
    
        return $this;
    }

    /**
     * Get teamName
     *
     * @return string 
     */
    public function getTeamName()
    {
        return $this->teamName;
    }
}