<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/9/13
 * Time: 9:33 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_meet")
 */
class Meet
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $name;

    /**
     * @ORM\Column(type="datetime")
     */
    protected $datetimeStart;

    /**
     * @ORM\Column(type="datetime")
     */
    protected $datetimeEnd;

    /**
     * @ORM\ManyToOne(targetEntity="Sport")
     * @ORM\JoinColumn(name="sport_id", referencedColumnName="id")
     */
    protected $sport;

    /**
     * @ORM\ManyToOne(targetEntity="Season")
     * @ORM\JoinColumn(name="season_id", referencedColumnName="id")
     */
    protected $season;

    /**
     * @ORM\Column(type="string", length=100)
     */
    protected $location;

    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="meets")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $creator;

    /**
     * @ORM\ManyToMany(targetEntity="Team", inversedBy="meets")
     * @ORM\JoinColumn(name="teams")
     */
    protected $teams;

    /**
     * @ORM\ManyToMany(targetEntity="User", inversedBy="races")
     * @ORM\JoinColumn(name="competitors")
     */
    protected $competitors;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isMeet = true;

    /**
     * @ORM\OneToMany(targetEntity="GameStatValue", mappedBy="meet")
     */
    protected $meetStatValues;


    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Game
     */
    public function setName($name)
    {
        if($name != null || $name != "")
        {
            $this->name = $name;
        }
        else
        {
            $this->name = $this::getHomeTeam() . 'VS.' . Game::getAwayTeam() . Game::getSport();
        }

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set datetimeStart
     *
     * @param \DateTime $datetimeStart
     * @return Game
     */
    public function setDatetimeStart($datetimeStart)
    {
        $this->datetimeStart = $datetimeStart;
    
        return $this;
    }

    /**
     * Get datetimeStart
     *
     * @return \DateTime 
     */
    public function getDatetimeStart()
    {
        return $this->datetimeStart;
    }

    /**
     * Set datetimeEnd
     *
     * @param \DateTime $datetimeEnd
     * @return Game
     */
    public function setDatetimeEnd($datetimeEnd)
    {
        $this->datetimeEnd = $datetimeEnd;
    
        return $this;
    }

    /**
     * Get datetimeEnd
     *
     * @return \DateTime 
     */
    public function getDatetimeEnd()
    {
        return $this->datetimeEnd;
    }

    /**
     * Set location
     *
     * @param string $location
     * @return Game
     */
    public function setLocation($location)
    {
        $this->location = $location;
    
        return $this;
    }

    /**
     * Get location
     *
     * @return string 
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set season
     *
     * @param \MSP\MSPBundle\Entity\Season $season
     * @return Game
     */
    public function setSeason(\MSP\MSPBundle\Entity\Season $season = null)
    {
        $this->season = $season;
        return $this;
    }

    /**
     * Get season
     *
     * @return \MSP\MSPBundle\Entity\Season 
     */
    public function getSeason()
    {
        return $this->season;
    }

    public function setCreator(\MSP\MSPBundle\Entity\User $creator = null)
    {
        $this->creator = $creator;
        return $this;
    }

    public function getCreator()
    {
        return $this->creator;
    }

    

    /**
     * Set sport
     *
     * @param \MSP\MSPBundle\Entity\Sport $sport
     * @return Game
     */
    public function setSport(\MSP\MSPBundle\Entity\Sport $sport = null)
    {
        $this->sport = $sport;
    
        return $this;
    }

    /**
     * Get sport
     *
     * @return \MSP\MSPBundle\Entity\Sport 
     */
    public function getSport()
    {
        return $this->sport;
    }


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->teams = new \Doctrine\Common\Collections\ArrayCollection();
    }
    



    public function getIsMeet()
    {
        return $this->isMeet;
    }
    public function setIsMeet()
    {
        if ($this->getSport()->getIsTeamSport())
        {
            $this->isMeet = false;
        }
        else
        {
            $this->isMeet = true;
        }
        return $this;
    }

    /**
     * Set homeTeam
     *
     * @param \MSP\MSPBundle\Entity\Team $homeTeam
     * @return Game
     */
    public function setHomeTeam(\MSP\MSPBundle\Entity\Team $homeTeam = null)
    {
        $this->homeTeam = $homeTeam;
    
        return $this;
    }

    /**
     * Get homeTeam
     *
     * @return \MSP\MSPBundle\Entity\Team 
     */
    public function getHomeTeam()
    {
        return $this->homeTeam;
    }

    /**
     * Set awayTeam
     *
     * @param \MSP\MSPBundle\Entity\Team $awayTeam
     * @return Game
     */
    public function setAwayTeam(\MSP\MSPBundle\Entity\Team $awayTeam = null)
    {
        $this->awayTeam = $awayTeam;
    
        return $this;
    }

    /**
     * Get awayTeam
     *
     * @return \MSP\MSPBundle\Entity\Team 
     */
    public function getAwayTeam()
    {
        return $this->awayTeam;
    }

    /**
     * Add teams
     *
     * @param \MSP\MSPBundle\Entity\Team $teams
     * @return Meet
     */
    public function addTeam(\MSP\MSPBundle\Entity\Team $teams)
    {
        $this->teams[] = $teams;
    
        return $this;
    }

    /**
     * Remove teams
     *
     * @param \MSP\MSPBundle\Entity\Team $teams
     */
    public function removeTeam(\MSP\MSPBundle\Entity\Team $teams)
    {
        $this->teams->removeElement($teams);
    }

    /**
     * Get teams
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getTeams()
    {
        return $this->teams;
    }

    /**
     * Add competitors
     *
     * @param \MSP\MSPBundle\Entity\User $competitors
     * @return Meet
     */
    public function addCompetitor(\MSP\MSPBundle\Entity\User $competitors)
    {
        $this->competitors[] = $competitors;
    
        return $this;
    }

    /**
     * Remove competitors
     *
     * @param \MSP\MSPBundle\Entity\User $competitors
     */
    public function removeCompetitor(\MSP\MSPBundle\Entity\User $competitors)
    {
        $this->competitors->removeElement($competitors);
    }

    /**
     * Get competitors
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getCompetitors()
    {
        return $this->competitors;
    }

    public function getYear()
    {
        return date_format($this->getDatetimeStart(), 'Y');
    }

    /**
     * Add meetStatValues
     *
     * @param \MSP\MSPBundle\Entity\GameStatValue $meetStatValues
     * @return Meet
     */
    public function addMeetStatValue(\MSP\MSPBundle\Entity\GameStatValue $meetStatValues)
    {
        $this->meetStatValues[] = $meetStatValues;
    
        return $this;
    }

    /**
     * Remove meetStatValues
     *
     * @param \MSP\MSPBundle\Entity\GameStatValue $meetStatValues
     */
    public function removeMeetStatValue(\MSP\MSPBundle\Entity\GameStatValue $meetStatValues)
    {
        $this->meetStatValues->removeElement($meetStatValues);
    }

    /**
     * Get meetStatValues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMeetStatValues()
    {
        return $this->meetStatValues;
    }
}