<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/10/13
 * Time: 3:57 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;
use Gedmo\Mapping\Annotation as Gedmo;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_key_measurable_value")
 */
class KeyMeasurableValue
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=300)
     */
    protected $value;

    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="keyMeasurableValues")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * @ORM\ManyToOne(targetEntity="KeyMeasurable")
     * @ORM\JoinColumn(name="key_measurable_id", referencedColumnName="id")
     */
    protected $keyMeasurable;

    /**
     * @ORM\ManyToOne(targetEntity="TrainingSession", inversedBy="keyMeasurableValues")
     * @ORM\JoinColumn(name="key_training_session_id", referencedColumnName="id")
     */
    protected $keyTrainingSession;

    /**
     * @Gedmo\Timestampable(on="update")
     * @ORM\Column(type="datetime")
     */
    private $updated;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

   
    /**
     * Set value
     *
     * @param string $value
     * @return KeyMeasurableValue
     */
    public function setValue($value)
    {
        $this->value = $value;
    
        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        $value = $this->value;

        if (isset($this->keyMeasurable))
        {
            if ($this->getKeyMeasurable()->getWidgetType() == 'checkbox')
            {
                $value = (bool) $value;
            }
            elseif ($this->getKeyMeasurable()->getWidgetType() == 'date')
            {
                $value = strtotime($value);
                $value = date('m/d/y',$value);
            }
        }

        return $value;
    }

    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return KeyMeasurableValue
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user = null)
    {
        $this->user = $user;
    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set keyMeasurable
     *
     * @param \MSP\MSPBundle\Entity\KeyMeasurable $keyMeasurable
     * @return KeyMeasurableValue
     */
    public function setKeyMeasurable(\MSP\MSPBundle\Entity\KeyMeasurable $keyMeasurable = null)
    {
        $this->keyMeasurable = $keyMeasurable;
    
        return $this;
    }


    /**
     * Get keyMeasurable
     *
     * @return \MSP\MSPBundle\Entity\KeyMeasurable 
     */
    public function getKeyMeasurable()
    {
        return $this->keyMeasurable;
    }


    public function __toString()
    {
        if(isset($this->value))
        {
            return $this->value;
        }

        return '';
    }


    public function getUpdated()
    {
        return $this->updated;
    }

    /**
     * Set updated
     *
     * @param \DateTime $updated
     * @return KeyMeasurableValue
     */
    public function setUpdated($updated)
    {
        $this->updated = $updated;
    
        return $this;
    }

    /**
     * Get keyTrainingSession
     *
     * @return \MSP\MSPBundle\Entity\TrainingSession 
     */
    public function getTrainingSession()
    {
        return $this->keyTrainingSession;
    }


    /**
     * Set keyTrainingSession
     *
     * @param \MSP\MSPBundle\Entity\TrainingSession $keyTrainingSession
     * @return keyTrainingSession
     */
    public function setTrainingSession(\MSP\MSPBundle\Entity\TrainingSession $keyTrainingSession = null)
    {
        $this->keyTrainingSession = $keyTrainingSession;
    
        return $this;
    }


    /**
     * Set keyTrainingSession
     *
     * @param \MSP\MSPBundle\Entity\TrainingSession $keyTrainingSession
     * @return KeyMeasurableValue
     */
    public function setKeyTrainingSession(\MSP\MSPBundle\Entity\TrainingSession $keyTrainingSession = null)
    {
        $this->keyTrainingSession = $keyTrainingSession;
    
        return $this;
    }

    /**
     * Get keyTrainingSession
     *
     * @return \MSP\MSPBundle\Entity\TrainingSession 
     */
    public function getKeyTrainingSession()
    {
        return $this->keyTrainingSession;
    }
}