<?php
/**
 * Created by Alok Kumar
 * User: alok
 * Date: 6/26/14
 * Time: 12:05 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_user_key_measurable_session")
 * @ORM\Entity(repositoryClass="UserKeyMeasurableSessionRepository")
 */
class UserKeyMeasurableSession
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\ManyToOne(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * @ORM\ManyToOne(targetEntity="KeyMeasurable")
     * @ORM\JoinColumn(name="key_measurable_id", referencedColumnName="id")
     */
    protected $keyMeasurable;

    /**
     * @ORM\Column(type="boolean", nullable=false)
     */
    protected $isStatus;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set isStatus
     *
     * @param boolean $isStatus
     * @return UserKeyMeasurableSession
     */
    public function setIsStatus($isStatus)
    {
        $this->isStatus = $isStatus;    
        return $this;
    }

    /**
     * Get isStatus
     *
     * @return boolean 
     */
    public function getIsStatus()
    {
        return $this->isStatus;
    }

    /**
     * Set keyMeasurable
     *
     * @param \MSP\MSPBundle\Entity\KeyMeasurable $keyMeasurable
     * @return UserKeyMeasurableSession
     */
    public function setKeyMeasurable(\MSP\MSPBundle\Entity\KeyMeasurable $keyMeasurable = null)
    {
        $this->keyMeasurable = $keyMeasurable;    
        return $this;
    }


    /**
     * Get keyMeasurable
     *
     * @return \MSP\MSPBundle\Entity\KeyMeasurable 
     */
    public function getKeyMeasurable()
    {
        return $this->keyMeasurable;
    }


    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return UserKeyMeasurableSession
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user)
    {
        $this->user = $user;    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }
}