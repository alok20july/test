<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/11/13
 * Time: 1:06 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_user_academic_information")
 */
class UserAcademicInformation
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="float", nullable=true)
     */
    protected $gpa;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $satTotalScore;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $actTotalScore;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $classRank;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $classRankOutOf;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $inHonorClasses;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $inAPClasses;

     /**
     * @ORM\Column(type="text")
     */
    protected $academicAccomplishments;

    /**
     * @ORM\ManyToOne(targetEntity="School")
     * @ORM\JoinColumn(name="school_id", referencedColumnName="id")
     */
    protected $school;

    /**
     * @ORM\OneToOne(targetEntity="User", inversedBy="userAcademicInformation")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;


    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    

    /**
     * Set classRank
     *
     * @param integer $classRank
     * @return UserAcademicInformation
     */
    public function setClassRank($classRank)
    {
        $this->classRank = $classRank;
    
        return $this;
    }

    /**
     * Get classRank
     *
     * @return integer 
     */
    public function getClassRank()
    {
        return $this->classRank;
    }

    /**
     * Set classRankOutOf
     *
     * @param integer $classRankOutOf
     * @return UserAcademicInformation
     */
    public function setClassRankOutOf($classRankOutOf)
    {
        $this->classRankOutOf = $classRankOutOf;
    
        return $this;
    }

    /**
     * Get classRankOutOf
     *
     * @return integer 
     */
    public function getClassRankOutOf()
    {
        return $this->classRankOutOf;
    }

    /**
     * Set inHonorClasses
     *
     * @param boolean $inHonorClasses
     * @return UserAcademicInformation
     */
    public function setInHonorClasses($inHonorClasses)
    {
        $this->inHonorClasses = $inHonorClasses;
    
        return $this;
    }

    /**
     * Get inHonorClasses
     *
     * @return boolean 
     */
    public function getInHonorClasses()
    {
        return $this->inHonorClasses;
    }

    /**
     * Set inAPClasses
     *
     * @param boolean $inAPClasses
     * @return UserAcademicInformation
     */
    public function setInAPClasses($inAPClasses)
    {
        $this->inAPClasses = $inAPClasses;
    
        return $this;
    }

    /**
     * Get inAPClasses
     *
     * @return boolean 
     */
    public function getInAPClasses()
    {
        return $this->inAPClasses;
    }

    /**
     * Set academicAccomplishments
     *
     * @param string $academicAccomplishments
     * @return UserAcademicInformation
     */
    public function setAcademicAccomplishments($academicAccomplishments)
    {
        $this->academicAccomplishments = $academicAccomplishments;
    
        return $this;
    }

    /**
     * Get academicAccomplishments
     *
     * @return string 
     */
    public function getAcademicAccomplishments()
    {
        return $this->academicAccomplishments;
    }

    /**
     * Set school
     *
     * @param \MSP\MSPBundle\Entity\School $school
     * @return UserAcademicInformation
     */
    public function setSchool(\MSP\MSPBundle\Entity\School $school = null)
    {
        $this->school = $school;
    
        return $this;
    }

    /**
     * Get school
     *
     * @return \MSP\MSPBundle\Entity\School 
     */
    public function getSchool()
    {
        return $this->school;
    }

    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return UserAcademicInformation
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user = null)
    {
        $this->user = $user;
    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set satTotalScore
     *
     * @param integer $satTotalScore
     * @return UserAcademicInformation
     */
    public function setSatTotalScore($satTotalScore)
    {
        $this->satTotalScore = $satTotalScore;
    
        return $this;
    }

    /**
     * Get satTotalScore
     *
     * @return integer 
     */
    public function getSatTotalScore()
    {
        return $this->satTotalScore;
    }

    /**
     * Set actTotalScore
     *
     * @param integer $actTotalScore
     * @return UserAcademicInformation
     */
    public function setActTotalScore($actTotalScore)
    {
        $this->actTotalScore = $actTotalScore;
    
        return $this;
    }

    /**
     * Get actTotalScore
     *
     * @return integer 
     */
    public function getActTotalScore()
    {
        return $this->actTotalScore;
    }

    /**
     * Set gpa
     *
     * @param float $gpa
     * @return UserAcademicInformation
     */
    public function setGpa($gpa)
    {
        $this->gpa = $gpa;
    
        return $this;
    }

    /**
     * Get gpa
     *
     * @return float 
     */
    public function getGpa()
    {
        return $this->gpa;
    }
}