<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/10/13
 * Time: 4:41 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_sport_stat")
 */
class SportStat
{
    const SEASON_STAT = 'season_stat';
    const GAME_STAT = 'game_stat';
    const ALL_STAT ='all_stat';
    const MEET_STAT = 'meet_stat';
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=100)
     */
    protected $name;

    /**
     * @ORM\Column(type="string", length=10)
     */
    protected $abbrev;

    /**
     * @ORM\Column(type="string", length=50)
     */
    protected $defaultValue;

    /**
     * @ORM\Column(type="string", length=50, nullable=false)
     */
    protected $widgetType;

    /**
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $tooltip;

    /**
     * @ORM\Column(type="string")
     */
    protected $statType;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    protected $options;

    /**
     * @ORM\ManyToOne(targetEntity="Sport", inversedBy="sportStats")
     * @ORM\JoinColumn(name="sport_id", referencedColumnName="id")
     */
    protected $sport;

    /**
     * @ORM\ManyToMany(targetEntity="SportPosition", inversedBy="sportStats", cascade={"all"}, orphanRemoval=true)
     * @ORM\JoinTable(name="msp_sport_stat_sport_position")
     */
    protected $sportPositions;

    /**
     * @ORM\ManyToOne(targetEntity="SportStatGroup")
     * @ORM\JoinColumn(name="sport_stat_group_id", referencedColumnName="id")
     */
    protected $sportStatGroup;

    /**
     *
     * @ORM\Column(type="string", nullable=true)
     */
    protected $statCategory;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="MSP\MSPBundle\Entity\GameStatValue", mappedBy="sportStat", cascade={"all"}, orphanRemoval=true)
     */
    protected $gameStatValues;


    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="MSP\MSPBundle\Entity\SeasonStatValue", mappedBy="sportStat", cascade={"all"}, orphanRemoval=true)
     */
    protected $seasonStatValues;


    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="MSP\MSPBundle\Entity\CareerStatValue", mappedBy="sportStat", cascade={"all"}, orphanRemoval=true)
     */
    protected $careerStatValues;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isGlobal;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $sortOrder;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isHidden;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isCalculation;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $parameters;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    protected $methodName;



    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return SportStat
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set abbrev
     *
     * @param string $abbrev
     * @return SportStat
     */
    public function setAbbrev($abbrev)
    {
        $this->abbrev = $abbrev;
    
        return $this;
    }

    /**
     * Get abbrev
     *
     * @return string 
     */
    public function getAbbrev()
    {
        return $this->abbrev;
    }

    /**
     * Set defaultValue
     *
     * @param string $defaultValue
     * @return SportStat
     */
    public function setDefaultValue($defaultValue)
    {
        $this->defaultValue = $defaultValue;
    
        return $this;
    }

    /**
     * Get defaultValue
     *
     * @return string 
     */
    public function getDefaultValue()
    {
        return $this->defaultValue;
    }

    /**
     * Set widgetType
     *
     * @param string $widgetType
     * @return SportStat
     */
    public function setWidgetType($widgetType)
    {
        $this->widgetType = $widgetType;
    
        return $this;
    }

    /**
     * Get widgetType
     *
     * @return string 
     */
    public function getWidgetType()
    {
        return $this->widgetType;
    }

    /**
     * Set tooltip
     *
     * @param string $tooltip
     * @return SportStat
     */
    public function setTooltip($tooltip)
    {
        $this->tooltip = $tooltip;
    
        return $this;
    }

    /**
     * Get tooltip
     *
     * @return string 
     */
    public function getTooltip()
    {
        return $this->tooltip;
    }

    /**
     * Set statType
     *
     * @param string $statType
     * @return SportStat
     */
    public function setStatType($statType)
    {
        $this->statType = $statType;
    
        return $this;
    }

    /**
     * Get statType
     *
     * @return string 
     */
    public function getStatType()
    {
        return $this->statType;
    }

    /**
     * Set options
     *
     * @param string $options
     * @return SportStat
     */
    public function setOptions($options)
    {
        $this->options = $options;
    
        return $this;
    }

    /**
     * Get options
     *
     * @return string 
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * Set sport
     *
     * @param \MSP\MSPBundle\Entity\Sport $sport
     * @return SportStat
     */
    public function setSport(\MSP\MSPBundle\Entity\Sport $sport = null)
    {
        $this->sport = $sport;
    
        return $this;
    }

    /**
     * Get sport
     *
     * @return \MSP\MSPBundle\Entity\Sport 
     */
    public function getSport()
    {
        return $this->sport;
    }

    /**
     * Set sportStatGroup
     *
     * @param \MSP\MSPBundle\Entity\SportStatGroup $sportStatGroup
     * @return SportStat
     */
    public function setSportStatGroup(\MSP\MSPBundle\Entity\SportStatGroup $sportStatGroup = null)
    {
        $this->sportStatGroup = $sportStatGroup;
    
        return $this;
    }

    /**
     * Get sportStatGroup
     *
     * @return \MSP\MSPBundle\Entity\SportStatGroup 
     */
    public function getSportStatGroup()
    {
        return $this->sportStatGroup;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->sportPositions = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Add sportPositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportPositions
     * @return SportStat
     */
    public function addSportPosition(\MSP\MSPBundle\Entity\SportPosition $sportPositions)
    {
        $this->sportPositions[] = $sportPositions;
    
        return $this;
    }

    /**
     * Remove sportPositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportPositions
     */
    public function removeSportPosition(\MSP\MSPBundle\Entity\SportPosition $sportPositions)
    {
        $this->sportPositions->removeElement($sportPositions);
    }

    /**
     * Get sportPositions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportPositions()
    {
        return $this->sportPositions;
    }

    /**
     * Set isGlobal
     *
     * @param boolean $isGlobal
     * @return SportStat
     */
    public function setIsGlobal($isGlobal)
    {
        $this->isGlobal = $isGlobal;
    
        return $this;
    }

    /**
     * Get isGlobal
     *
     * @return boolean 
     */
    public function getIsGlobal()
    {
        return $this->isGlobal;
    }

    /**
     * Set statCategory
     *
     * @param enumstat $statCategory
     * @return SportStat
     */
    public function setStatCategory($statCategory)
    {
        $this->statCategory = $statCategory;
    
        return $this;
    }

    /**
     * Get statCategory
     *
     * @return enumstat 
     */
    public function getStatCategory()
    {
        return $this->statCategory;
    }

    /**
     * Add gameStatValues
     *
     * @param \MSP\MSPBundle\Entity\GameStatValue $gameStatValues
     * @return SportStat
     */
    public function addGameStatValue(\MSP\MSPBundle\Entity\GameStatValue $gameStatValues)
    {
        $this->gameStatValues[] = $gameStatValues;
    
        return $this;
    }

    /**
     * Remove gameStatValues
     *
     * @param \MSP\MSPBundle\Entity\GameStatValue $gameStatValues
     */
    public function removeGameStatValue(\MSP\MSPBundle\Entity\GameStatValue $gameStatValues)
    {
        $this->gameStatValues->removeElement($gameStatValues);
    }

    /**
     * Get gameStatValues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getGameStatValues()
    {
        return $this->gameStatValues;
    }

    /**
     * Add seasonStatValues
     *
     * @param \MSP\MSPBundle\Entity\SeasonStatValue $seasonStatValues
     * @return SportStat
     */
    public function addSeasonStatValue(\MSP\MSPBundle\Entity\SeasonStatValue $seasonStatValues)
    {
        $this->seasonStatValues[] = $seasonStatValues;
    
        return $this;
    }

    /**
     * Remove seasonStatValues
     *
     * @param \MSP\MSPBundle\Entity\SeasonStatValue $seasonStatValues
     */
    public function removeSeasonStatValue(\MSP\MSPBundle\Entity\SeasonStatValue $seasonStatValues)
    {
        $this->seasonStatValues->removeElement($seasonStatValues);
    }

    /**
     * Get seasonStatValues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSeasonStatValues()
    {
        return $this->seasonStatValues;
    }

    /**
     * Add careerStatValues
     *
     * @param \MSP\MSPBundle\Entity\CareerStatValue $careerStatValues
     * @return SportStat
     */
    public function addCareerStatValue(\MSP\MSPBundle\Entity\CareerStatValue $careerStatValues)
    {
        $this->careerStatValues[] = $careerStatValues;
    
        return $this;
    }

    /**
     * Remove careerStatValues
     *
     * @param \MSP\MSPBundle\Entity\CareerStatValue $careerStatValues
     */
    public function removeCareerStatValue(\MSP\MSPBundle\Entity\CareerStatValue $careerStatValues)
    {
        $this->careerStatValues->removeElement($careerStatValues);
    }

    /**
     * Get careerStatValues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getCareerStatValues()
    {
        return $this->careerStatValues;
    }


    /**
     * Set sortOrder
     *
     * @param boolean $sortOrder
     * @return SportStat
     */
    public function setSortOrder($sortOrder)
    {
        $this->sortOrder = $sortOrder;
    
        return $this;
    }

    /**
     * Get sortOrder
     *
     * @return boolean 
     */
    public function getSortOrder()
    {
        return $this->sortOrder;
    }


    /**
     * Set isHidden
     *
     * @param boolean $isHidden
     * @return SportStat
     */
    public function setIsHidden($isHidden)
    {
        $this->isHidden = $isHidden;    
        return $this;
    }

    /**
     * Get isHidden
     *
     * @return boolean 
     */
    public function getIsHidden()
    {
        return $this->isHidden;
    }

    /**
     * Set isCalculation
     *
     * @param boolean $isCalculation
     * @return SportStat
     */
    public function setIsCalculation($isCalculation)
    {
        $this->isCalculation = $isCalculation;    
        return $this;
    }

    /**
     * Get isCalculation
     *
     * @return boolean 
     */
    public function getIsCalculation()
    {
        return $this->isCalculation;
    }

    /**
     * Set parameters
     *
     * @param string $parameters
     * @return SportStat
     */
    public function setParameters($parameters)
    {
        $this->parameters = $parameters;    
        return $this;
    }

    /**
     * Get parameters
     *
     * @return string 
     */
    public function getParameters()
    {
        return $this->parameters;
    }

    /**
     * Set methodName
     *
     * @param string $methodName
     * @return SportStat
     */
    public function setMethodName($methodName)
    {
        $this->methodName = $methodName;    
        return $this;
    }

    /**
     * Get methodName
     *
     * @return string 
     */
    public function getMethodName()
    {
        return $this->methodName;
    }    
}