<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/11/13
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_resource_subject")
 */
class ResourceSubject
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=100)
     */
    protected $name;

    /**
     * @ORM\ManyToOne(targetEntity="ResourceTopic")
     * @ORM\JoinColumn(name="resource_topic_id", referencedColumnName="id")
     */
    protected $resourceTopic;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isActive;



    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return ResourceSubject
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set isActive
     *
     * @param boolean $isActive
     * @return ResourceSubject
     */
    public function setIsActive($isActive)
    {
        $this->isActive = $isActive;
    
        return $this;
    }

    /**
     * Get isActive
     *
     * @return boolean 
     */
    public function getIsActive()
    {
        return $this->isActive;
    }

    /**
     * Set resourceTopic
     *
     * @param \MSP\MSPBundle\Entity\ResourceTopic $resourceTopic
     * @return ResourceSubject
     */
    public function setResourceTopic(\MSP\MSPBundle\Entity\ResourceTopic $resourceTopic = null)
    {
        $this->resourceTopic = $resourceTopic;
    
        return $this;
    }

    /**
     * Get resourceTopic
     *
     * @return \MSP\MSPBundle\Entity\ResourceTopic 
     */
    public function getResourceTopic()
    {
        return $this->resourceTopic;
    }

    public function __toString()
    {
        if(isset($this->name))
        {
            return (string) $this->name;
        }

        return '';
    }
}