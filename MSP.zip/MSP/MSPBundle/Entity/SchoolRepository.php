<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 7/3/14
 * Time: 12:05 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;

class SchoolRepository extends EntityRepository{

    /*
     * Used for autocomplete finds scholl based on the term to finds all school.
     * @param string school Term to search for in the school
     *
     * @return DoctrineCollection $schools;
     */

    public function getSchools($term, $state = 0)
    {
        if($state){
            $schools =  $this->getEntityManager()
            ->createQuery(
                "SELECT s
                 FROM MSPBundle:School s
                 WHERE s.name like '%".$term."%'
                 AND s.state = '".$state."'
            "
            )
            ->getResult();
        }else{
            $schools =  $this->getEntityManager()
            ->createQuery(
                "SELECT s
                 FROM MSPBundle:School s
                 WHERE s.name like '%".$term."%'
            "            
            )
            ->setMaxResults(500)
            ->getResult();
        }
        return $schools;
    }

    /*
     * find all school list group by withn state name.
     * @param null
     *
     * @return DoctrineCollection $states;
     */

    public function getSchoolListByState()
    {
        return $this->getEntityManager()
            ->createQuery(
                "SELECT s
                 FROM MSPBundle:School s                 
                 GROUP BY s.state
                 ORDER BY s.state ASC
            "
        )->getResult();
    }
}