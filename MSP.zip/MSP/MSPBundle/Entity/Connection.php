<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 2/6/14
 * Time: 12:39 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_connection")
 */
class Connection {

    const STATUS_INACTIVE = 0;
    const STATUS_ACTIVE = 1;
    const STATUS_REFUSE = 2;
    const STATUS_PENDING = 3;

    const TEAMMATE_CONNECTION = 'teammate';

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;


    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="myRequestingConnections")
     * @ORM\JoinColumn(name="requester_user_id", referencedColumnName="id")
     */
    protected $requesterUser;


    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="myRequestedConnections")
     * @ORM\JoinColumn(name="requested_user_id", referencedColumnName="id")
     */
    protected $requestedUser;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50, nullable=false)
     */
    protected $status;


    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50, nullable=false)
     */
    protected $connectionType;




    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set status
     *
     * @param string $status
     * @return Connection
     */
    public function setStatus($status)
    {

        if (!in_array($status, array(self::STATUS_ACTIVE, self::STATUS_INACTIVE, self::STATUS_REFUSE, self::STATUS_PENDING))) {
            throw new \InvalidArgumentException("Invalid status");
        }

        $this->status = $status;
    
        return $this;
    }

    /**
     * Get status
     *
     * @return string 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set connectionType
     *
     * @param string $connectionType
     * @return Connection
     */
    public function setConnectionType($connectionType)
    {
        $this->connectionType = $connectionType;
    
        return $this;
    }

    /**
     * Get connectionType
     *
     * @return string 
     */
    public function getConnectionType()
    {
        return $this->connectionType;
    }

    /**
     * Set requesterUser
     *
     * @param \MSP\MSPBundle\Entity\User $requesterUser
     * @return Connection
     */
    public function setRequesterUser(\MSP\MSPBundle\Entity\User $requesterUser = null)
    {
        $this->requesterUser = $requesterUser;
    
        return $this;
    }

    /**
     * Get requesterUser
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getRequesterUser()
    {
        return $this->requesterUser;
    }

    /**
     * Set requestedUser
     *
     * @param \MSP\MSPBundle\Entity\User $requestedUser
     * @return Connection
     */
    public function setRequestedUser(\MSP\MSPBundle\Entity\User $requestedUser = null)
    {
        $this->requestedUser = $requestedUser;
    
        return $this;
    }

    /**
     * Get requestedUser
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getRequestedUser()
    {
        return $this->requestedUser;
    }
}