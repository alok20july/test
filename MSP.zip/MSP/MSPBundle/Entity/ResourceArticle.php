<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/11/13
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_resource_article")
 */
class ResourceArticle
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=100)
     */
    protected $title;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    protected $content;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isActive;

    /**
     * @ORM\ManyToOne(targetEntity="ResourceSubject")
     * @ORM\JoinColumn(name="resource_subject_id", referencedColumnName="id")
     */
    protected $resourceSubject;


    public function __toString()
    {
        if(isset($this->title))
        {
            return (string) $this->title;
        }

        return '';
    }


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return ResourceArticle
     */
    public function setTitle($title)
    {
        $this->title = $title;
    
        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set content
     *
     * @param string $content
     * @return ResourceArticle
     */
    public function setContent($content)
    {
        $this->content = $content;
    
        return $this;
    }

    /**
     * Get content
     *
     * @return string 
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set isActive
     *
     * @param boolean $isActive
     * @return ResourceArticle
     */
    public function setIsActive($isActive)
    {
        $this->isActive = $isActive;
    
        return $this;
    }

    /**
     * Get isActive
     *
     * @return boolean 
     */
    public function getIsActive()
    {
        return $this->isActive;
    }

    /**
     * Set resourceSubject
     *
     * @param \MSP\MSPBundle\Entity\ResourceSubject $resourceSubject
     * @return ResourceArticle
     */
    public function setResourceSubject(\MSP\MSPBundle\Entity\ResourceSubject $resourceSubject = null)
    {
        $this->resourceSubject = $resourceSubject;
    
        return $this;
    }

    /**
     * Get resourceSubject
     *
     * @return \MSP\MSPBundle\Entity\ResourceSubject 
     */
    public function getResourceSubject()
    {
        return $this->resourceSubject;
    }
}