<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/10/13
 * Time: 2:45 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Entity(repositoryClass="KeyMeasurableRespository")
 * @ORM\Table(name="msp_key_measurable")
 */
class KeyMeasurable
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=100, nullable=false)
     */
    protected $name;

    /**
     * @ORM\Column(type="string", length=50, nullable=false)
     */
    protected $widgetType;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    protected $options;

    /**
     * @ORM\Column(type="string", length=150, nullable=true)
     */
    protected $tooltip;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isPhysical;

    /**
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isGlobal;

    /**
     * @ORM\ManyToMany(targetEntity="Sport")
     * @ORM\JoinTable(name="msp_key_measurable_sport",
     *      joinColumns={@ORM\JoinColumn(name="key_measurable_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="sport_id", referencedColumnName="id")}
     *      )
     */
    protected $sports;

    /**
     * @ORM\ManyToMany(targetEntity="SportPosition")
     * @ORM\JoinTable(name="msp_key_measurable_sport_position",
     *      joinColumns={@ORM\JoinColumn(name="key_measurable_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="sport_position_id", referencedColumnName="id")}
     *      )
     */
    protected $sportPositions;

    public function __construct() {
        $this->sports = new \Doctrine\Common\Collections\ArrayCollection();
        $this->sportPositions = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return KeyMeasurable
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set widgetType
     *
     * @param string $widgetType
     * @return KeyMeasurable
     */
    public function setWidgetType($widgetType)
    {
        $this->widgetType = $widgetType;
    
        return $this;
    }

    /**
     * Get widgetType
     *
     * @return string 
     */
    public function getWidgetType()
    {
        return $this->widgetType;
    }

    /**
     * Set options
     *
     * @param string $options
     * @return KeyMeasurable
     */
    public function setOptions($options)
    {
        $this->options = $options;
    
        return $this;
    }

    /**
     * Get options
     *
     * @return string 
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * Set tooltip
     *
     * @param string $tooltip
     * @return KeyMeasurable
     */
    public function setTooltip($tooltip)
    {
        $this->tooltip = $tooltip;
    
        return $this;
    }

    /**
     * Get tooltip
     *
     * @return string 
     */
    public function getTooltip()
    {
        return $this->tooltip;
    }

    /**
     * Set isGlobal
     *
     * @param boolean $isGlobal
     * @return KeyMeasurable
     */
    public function setIsGlobal($isGlobal)
    {
        $this->isGlobal = $isGlobal;
    
        return $this;
    }

    /**
     * Get isGlobal
     *
     * @return boolean 
     */
    public function getIsGlobal()
    {
        return $this->isGlobal;
    }


    /**
     * Add sports
     *
     * @param \MSP\MSPBundle\Entity\Sport $sports
     * @return KeyMeasurable
     */
    public function addSport(\MSP\MSPBundle\Entity\Sport $sports)
    {
        $this->sports[] = $sports;
    
        return $this;
    }

    /**
     * Remove sports
     *
     * @param \MSP\MSPBundle\Entity\Sport $sports
     */
    public function removeSport(\MSP\MSPBundle\Entity\Sport $sports)
    {
        $this->sports->removeElement($sports);
    }

    /**
     * Get sports
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSports()
    {
        return $this->sports;
    }

    /**
     * Add sportPositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportPositions
     * @return KeyMeasurable
     */
    public function addSportPosition(\MSP\MSPBundle\Entity\SportPosition $sportPositions)
    {
        $this->sportPositions[] = $sportPositions;
    
        return $this;
    }

    /**
     * Remove sportPositions
     *
     * @param \MSP\MSPBundle\Entity\SportPosition $sportPositions
     */
    public function removeSportPosition(\MSP\MSPBundle\Entity\SportPosition $sportPositions)
    {
        $this->sportPositions->removeElement($sportPositions);
    }

    /**
     * Get sportPositions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSportPositions()
    {
        return $this->sportPositions;
    }

    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }

    /**
     * Set isPhysical
     *
     * @param boolean $isPhysical
     * @return KeyMeasurable
     */
    public function setIsPhysical($isPhysical)
    {
        $this->isPhysical = $isPhysical;
    
        return $this;
    }

    /**
     * Get isPhysical
     *
     * @return boolean 
     */
    public function getIsPhysical()
    {
        return $this->isPhysical;
    }
}