<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 1/29/14
 * Time: 8:24 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;
use MSP\MSPBundle\Entity\Connection;

class WallPostRepository extends EntityRepository
{
    public function getWallPostsForUser(User $user)
    {


        return $this->getEntityManager()
            ->createQuery(
                "SELECT wp
                 FROM MSPBundle:WallPost wp
                 WHERE
                    (wp.user = :user)
                    OR
                    (EXISTS
                    (SELECT 1 FROM MSPBundle:Connection c
                    WHERE c.requestedUser = :user AND c.requesterUser = wp.user))
                    OR
                    (EXISTS
                    (SELECT 1 FROM MSPBundle:Connection c1
                    WHERE c1.requesterUser = :user AND c1.requestedUser = wp.user))
                 ORDER BY wp.created DESC
                 "
            )
            ->setParameters(array(
                'user' => $user->getId()
            ))

            ->getResult();
    }

}