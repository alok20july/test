<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/9/13
 * Time: 9:33 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;


/**
 * @ORM\Entity
 * @ORM\Table(name="msp_game")
 */
class Game
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50, nullable=true)
     */
    protected $name;

    /**
     * @ORM\Column(type="datetime")
     */
    protected $datetimeStart;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    protected $datetimeEnd;

    /**
     * @ORM\ManyToOne(targetEntity="Sport")
     * @ORM\JoinColumn(name="sport_id", referencedColumnName="id")
     */
    protected $sport;

    /**
     * @ORM\ManyToOne(targetEntity="Season")
     * @ORM\JoinColumn(name="season_id", referencedColumnName="id")
     */
    protected $season;

    /**
     * @ORM\Column(type="string", length=100, nullable=true)
     */
    protected $location;

    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="games")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $creator;

    /**
     * @ORM\ManyToOne(targetEntity="Team", inversedBy="homeGames")
     * @ORM\JoinColumn(name="home_team_id", referencedColumnName="id")
     */
    protected $homeTeam;

    /**
     * @ORM\ManyToOne(targetEntity="Team", inversedBy="awayGames")
     * @ORM\JoinColumn(name="away_team_id", referencedColumnName="id")
     */
    protected $awayTeam;

    /**
     * @ORM\ManyToOne(targetEntity="UserTeamSeason", inversedBy="games")
     * @ORM\JoinColumn(name="user_team_season_id", referencedColumnName="id", onDelete="CASCADE")
     */
    protected $userTeamSeason;

    /**
     * @var boolean
     *
     * @ORM\Column(type="boolean", nullable=true)
     */
    protected $isMeet = false;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $points1;

    /**
     * @var integer
     *
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $points2;

    /**
     * @ORM\OneToMany(targetEntity="GameStatValue", mappedBy="game", cascade={"persist"})
     */
    protected $gameStatValues;

    /**
     * @var \Doctrine\Common\Collections\ArrayCollection
     *
     * @ORM\OneToMany(targetEntity="MSP\MSPBundle\Entity\WallPost", mappedBy="game", cascade={"all"}, orphanRemoval=true)
     */
    protected $posts;


    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Game
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set datetimeStart
     *
     * @param \DateTime $datetimeStart
     * @return Game
     */
    public function setDatetimeStart($datetimeStart)
    {
        $this->datetimeStart = $datetimeStart;
    
        return $this;
    }

    /**
     * Get datetimeStart
     *
     * @return \DateTime 
     */
    public function getDatetimeStart()
    {
        return $this->datetimeStart;
    }

    /**
     * Set datetimeEnd
     *
     * @param \DateTime $datetimeEnd
     * @return Game
     */
    public function setDatetimeEnd($datetimeEnd)
    {
        $this->datetimeEnd = $datetimeEnd;
    
        return $this;
    }

    /**
     * Get datetimeEnd
     *
     * @return \DateTime 
     */
    public function getDatetimeEnd()
    {
        return $this->datetimeEnd;
    }

    /**
     * Set location
     *
     * @param string $location
     * @return Game
     */
    public function setLocation($location)
    {
        $this->location = $location;
    
        return $this;
    }

    /**
     * Get location
     *
     * @return string 
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set season
     *
     * @param \MSP\MSPBundle\Entity\Season $season
     * @return Game
     */
    public function setSeason(\MSP\MSPBundle\Entity\Season $season = null)
    {
        $this->season = $season;
        return $this;
    }

    /**
     * Get season
     *
     * @return \MSP\MSPBundle\Entity\Season 
     */
    public function getSeason()
    {
        return $this->season;
    }

    public function setCreator(\MSP\MSPBundle\Entity\User $creator = null)
    {
        $this->creator = $creator;
        return $this;
    }

    public function getCreator()
    {
        return $this->creator;
    }

    

    /**
     * Set sport
     *
     * @param \MSP\MSPBundle\Entity\Sport $sport
     * @return Game
     */
    public function setSport(\MSP\MSPBundle\Entity\Sport $sport = null)
    {
        $this->sport = $sport;
    
        return $this;
    }

    /**
     * Get sport
     *
     * @return \MSP\MSPBundle\Entity\Sport 
     */
    public function getSport()
    {
        return $this->sport;
    }

    /**
     * Set points1
     *
     * @param integer $points1
     * @return Game
     */
    public function setPoints1($points1)
    {
        $this->points1 = $points1;
    
        return $this;
    }

    /**
     * Get points1
     *
     * @return integer 
     */
    public function getPoints1()
    {
        return $this->points1;
    }

    /**
     * Set points2
     *
     * @param integer $points2
     * @return Game
     */
    public function setPoints2($points2)
    {
        $this->points2 = $points2;
    
        return $this;
    }

    /**
     * Get points2
     *
     * @return integer 
     */
    public function getPoints2()
    {
        return $this->points2;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->teams = new \Doctrine\Common\Collections\ArrayCollection();
    }
    



    public function getIsMeet()
    {
        return $this->isMeet;
    }
    public function setIsMeet()
    {
        if ($this->getSport()->getIsTeamSport())
        {
            $this->isMeet = false;
        }
        else
        {
            $this->isMeet = true;
        }
        return $this;
    }

    /**
     * Set homeTeam
     *
     * @param \MSP\MSPBundle\Entity\Team $homeTeam
     * @return Game
     */
    public function setHomeTeam(\MSP\MSPBundle\Entity\Team $homeTeam = null)
    {
        $this->homeTeam = $homeTeam;
    
        return $this;
    }

    /**
     * Get homeTeam
     *
     * @return \MSP\MSPBundle\Entity\Team 
     */
    public function getHomeTeam()
    {
        return $this->homeTeam;
    }

    /**
     * Set awayTeam
     *
     * @param \MSP\MSPBundle\Entity\Team $awayTeam
     * @return Game
     */
    public function setAwayTeam(\MSP\MSPBundle\Entity\Team $awayTeam = null)
    {
        $this->awayTeam = $awayTeam;
    
        return $this;
    }

    /**
     * Get awayTeam
     *
     * @return \MSP\MSPBundle\Entity\Team 
     */
    public function getAwayTeam()
    {
        return $this->awayTeam;
    }

    public function getYear()
    {
        return date_format($this->getDatetimeStart(), 'Y');
    }

    /**
     * Add gameStatValues
     *
     * @param \MSP\MSPBundle\Entity\GameStatValue $gameStatValues
     * @return Game
     */
    public function addGameStatValue(\MSP\MSPBundle\Entity\GameStatValue $gameStatValues)
    {
        $this->gameStatValues[] = $gameStatValues;
    
        return $this;
    }

    /**
     * Remove gameStatValues
     *
     * @param \MSP\MSPBundle\Entity\GameStatValue $gameStatValues
     */
    public function removeGameStatValue(\MSP\MSPBundle\Entity\GameStatValue $gameStatValues)
    {
        $this->gameStatValues->removeElement($gameStatValues);
    }

    /**
     * Get gameStatValues
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getGameStatValues()
    {
        return $this->gameStatValues;
    }



    /**
     * Set userTeamSeason
     *
     * @param \MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason
     * @return Game
     */
    public function setUserTeamSeason(\MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason = null)
    {
        $this->userTeamSeason = $userTeamSeason;
    
        return $this;
    }

    /**
     * Get userTeamSeason
     *
     * @return \MSP\MSPBundle\Entity\UserTeamSeason 
     */
    public function getUserTeamSeason()
    {
        return $this->userTeamSeason;
    }

    public function getGameStatValuesForUser(User $user){
        return $this->getGameStatValues()->filter(
            function($entry) use ($user) {
                if($entry->getUser() == $user){
                    return true;
                }
                return false;
            }
        );
    }

    /**
     * Add posts
     *
     * @param \MSP\MSPBundle\Entity\WallPost $posts
     * @return Game
     */
    public function addPost(\MSP\MSPBundle\Entity\WallPost $posts)
    {
        $this->posts[] = $posts;
    
        return $this;
    }

    /**
     * Remove posts
     *
     * @param \MSP\MSPBundle\Entity\WallPost $posts
     */
    public function removePost(\MSP\MSPBundle\Entity\WallPost $posts)
    {
        $this->posts->removeElement($posts);
    }

    /**
     * Get posts
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPosts()
    {
        return $this->posts;
    }
}