<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 2/18/14
 * Time: 2:14 PM
 * Event listener
 */

namespace MSP\MSPBundle\Entity\Listeners;

use Doctrine\ORM\Event\LifecycleEventArgs;
use MSP\MSPBundle\Entity\UserTeamSeason;

class UserConnectionsUpdater {

    /*
     * Establishes a connection between a user and teamates.
     */
    public function postPersist(LifecycleEventArgs $args)
    {
        $entity = $args->getEntity();
        $em = $args->getEntityManager();

        if($entity instanceof UserTeamSeason){
            /*$users = $em->getRepository('MSPBundle:UserTeamSeason')->getUsersForTeamSeason($entity->getTeam(), $entity->getSeason(), $entity->getYear());
            foreach($users as $user){
                // if the user is a teammate not the current user.
                if($user !== $entity->getUser()){
                    $em->getRepository('MSPBundle:User')->forceTeamConnect($entity->getUser(), $user);
                }
            }*/

            $users = $em->getRepository('MSPBundle:UserTeamSeason')->getUsersForTeamSeason($entity->getSchool(), $entity->getSport());
            foreach($users as $user){
                // if the user is a teammate not the current user.
                if($user !== $entity->getUser()){
                    $em->getRepository('MSPBundle:User')->forceTeamConnect($entity->getUser(), $user);
                }
            }
        }
    }
}