<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 2/17/14
 * Time: 3:53 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;

class TeamRepository extends EntityRepository{

    /*
     * Used for autocomplete finds teams based on the term. If no teamId is supplied finds all teams.
     * @param string term   Term to search for in the team
     * @param integer $teamId The team to which we're trying to find possible oppenents.
     *
     * @return DoctrineCollection $teams;
     */

    public function getPossibleOponentTeams($term, $teamId=null)
    {
        if($teamId){
            $teams =  $this->getEntityManager()
                ->createQuery(
                    "SELECT t
                     FROM MSPBundle:Team t
                     JOIN MSPBundle:Team mt
                     Where t.sport = mt.sport
                     AND mt.id = :myTeamId
                     AND t.id != :myTeamId
                     AND t.name like '%".$term. "%'

                "
                )->setParameter('myTeamId', $teamId)
                ->getResult();
        }else{
            $teams =  $this->getEntityManager()
                ->createQuery(
                    "SELECT t
                     FROM MSPBundle:Team t
                     WHERE t.name like '%".$term. "%'
                "
                )
                ->getResult();
        }

        return $teams;
    }
}