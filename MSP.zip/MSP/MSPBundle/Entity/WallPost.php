<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/11/13
 * Time: 2:26 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_wall_post")
 * @ORM\Entity(repositoryClass="WallPostRepository")
 */
class WallPost
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    protected $content;


    /**
     * @Gedmo\Timestampable(on="create")
     * @ORM\Column(type="datetime")
     */
    private $created;

    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="posts")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * @ORM\ManyToOne(targetEntity="Game", inversedBy="posts", cascade={"persist"})
     * @ORM\JoinColumn(name="game_id", referencedColumnName="id", onDelete="CASCADE")
     */
    protected $game;


    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    protected $image;

    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media", cascade={"persist"})
     */
    protected $video;

    /**
     * @ORM\ManyToOne(targetEntity="TrainingSession")
     */
    protected $stats;

    /**
     * @ORM\ManyToOne(targetEntity="UserTeamSeason")
     */
    protected $userTeamSeason;

    /**
     * @ORM\OneToMany(targetEntity="WallComment", mappedBy="wallPost")
     */
    protected $comments;

    /**
     * @ORM\Column(type="integer", nullable=true)
     */
    protected $cheerCount;

    /**
     * @ORM\ManyToMany(targetEntity="User")
     * @ORM\JoinTable(name="msp_cheer_user")
     */
    protected $cheerUsers;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set content
     *
     * @param string $content
     * @return WallPost
     */
    public function setContent($content)
    {
        $this->content = $content;
    
        return $this;
    }

    /**
     * Get content
     *
     * @return string 
     */
    public function getContent()
    {
        return $this->content;
    }

    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return WallPost
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user = null)
    {
        $this->user = $user;
    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set userTeamSeason
     *
     * @param \MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason
     * @return WallPost
     */
    public function setUserTeamSeason(\MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason = null)
    {
        if ($this->user == $userTeamSeason->getUser())
        {
            $this->userTeamSeason = $userTeamSeason;
        }
        return $this;
    }

    /**
     * Get userTeamSeason
     *
     * @return \MSP\MSPBundle\Entity\UserTeamSeason 
     */
    public function getUserTeamSeason()
    {
        return $this->userTeamSeason;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->comments = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Add comments
     *
     * @param \MSP\MSPBundle\Entity\WallComment $comments
     * @return WallPost
     */
    public function addComment(\MSP\MSPBundle\Entity\WallComment $comments)
    {
        $this->comments[] = $comments;
    
        return $this;
    }

    /**
     * Remove comments
     *
     * @param \MSP\MSPBundle\Entity\WallComment $comments
     */
    public function removeComment(\MSP\MSPBundle\Entity\WallComment $comments)
    {
        $this->comments->removeElement($comments);
    }

    /**
     * Get comments
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getComments()
    {
        return $this->comments;
    }

    /**
     * Set image
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $image
     * @return WallPost
     */
    public function setImage(\Application\Sonata\MediaBundle\Entity\Media $image = null)
    {
        $this->image = $image;
    
        return $this;
    }

    /**
     * Get image
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set video
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $video
     * @return WallPost
     */
    public function setVideo(\Application\Sonata\MediaBundle\Entity\Media $video = null)
    {
        $this->video = $video;
    
        return $this;
    }

    /**
     * Get video
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getVideo()
    {
        return $this->video;
    }

    public function getCreated()
    {
        return $this->created;
    }

    public function setCreated($created)
    {
        return $this->created = $created;
    }

    public function __toString()
    {
        if(isset($this->id))
        {
            return (string) $this->id;
        }

        return '';
    }

    /**
     * Set image
     *
     * @param Game $game
     * @return WallPost
     */
    public function setGame(Game $game = null)
    {
        $this->game = $game;

        return $this;
    }

    /**
     * Get image
     *
     * @return Game
     */
    public function getGame()
    {
        return $this->game;
    }

    /**
     * Add cheerUsers
     *
     * @param \MSP\MSPBundle\Entity\User $cheerUsers
     * @return WallPost
     */
    public function addCheerUser(\MSP\MSPBundle\Entity\User $cheerUsers)
    {
        $this->cheerUsers[] = $cheerUsers;
    
        return $this;
    }

    /**
     * Remove cheerUsers
     *
     * @param \MSP\MSPBundle\Entity\User $cheerUsers
     */
    public function removeCheerUser(\MSP\MSPBundle\Entity\User $cheerUsers)
    {
        $this->cheerUsers->removeElement($cheerUsers);
    }

    /**
     * Get cheerUsers
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getCheerUsers()
    {
        return $this->cheerUsers;
    }

    /**
     * Set cheerCount
     *
     * @param integer $cheerCount
     * @return WallPost
     */
    public function setCheerCount($cheerCount)
    {
        $this->cheerCount = $cheerCount;
    
        return $this;
    }

    /**
     * Get cheerCount
     *
     * @return integer 
     */
    public function getCheerCount()
    {
        return $this->cheerCount;
    }

    /**
     * Set stats
     *
     * @param \MSP\MSPBundle\Entity\TrainingSession $stats
     * @return WallPost
     */
    public function setStats(\MSP\MSPBundle\Entity\TrainingSession $stats = null)
    {
        $this->stats = $stats;
    
        return $this;
    }

    /**
     * Get stats
     *
     * @return \MSP\MSPBundle\Entity\TrainingSession 
     */
    public function getStats()
    {
        return $this->stats;
    }
}