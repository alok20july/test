<?php
/**
 * Created by Alok Kumar
 * User: alok
 * Date: 7/10/14
 * Time: 12:05 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_user_game_stat_value") 
 * @ORM\Entity(repositoryClass="UserSeasonGameStatValueRepository")
 */
class UserSeasonGameStatValue
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\ManyToOne(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * @ORM\ManyToOne(targetEntity="UserTeamSeason")
     * @ORM\JoinColumn(name="user_team_season_id", referencedColumnName="id", onDelete="CASCADE")
     */
    protected $userTeamSeason;

    /**
     * @ORM\ManyToOne(targetEntity="SportStatGroup")
     * @ORM\JoinColumn(name="sport_stat_group_id", referencedColumnName="id")
     */
    protected $sportStatGroup;

    /**
     * @ORM\ManyToOne(targetEntity="SportStat")
     * @ORM\JoinColumn(name="sport_stat_id", referencedColumnName="id")
     * @ORM\OrderBy({"sortOrder" = "ASC"})
     */
    protected $sportStat;

    /**
     * @ORM\Column(type="boolean", nullable=false)
     */
    protected $isStatus;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set isStatus
     *
     * @param boolean $isStatus
     * @return UserSeasonGameStatValue
     */
    public function setIsStatus($isStatus)
    {
        $this->isStatus = $isStatus;    
        return $this;
    }

    /**
     * Get isStatus
     *
     * @return boolean 
     */
    public function getIsStatus()
    {
        return $this->isStatus;
    }

    /**
     * Set userTeamSeason
     *
     * @param \MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason
     * @return UserSeasonGameStatValue
     */
    public function setUserTeamSeason(\MSP\MSPBundle\Entity\UserTeamSeason $userTeamSeason = null)
    {
        $this->userTeamSeason = $userTeamSeason;    
        return $this;
    }


    /**
     * Get userTeamSeason
     *
     * @return \MSP\MSPBundle\Entity\UserTeamSeason 
     */
    public function getUserTeamSeason()
    {
        return $this->userTeamSeason;
    }


    /**
     * Set user
     *
     * @param \MSP\MSPBundle\Entity\User $user
     * @return UserSeasonGameStatValue
     */
    public function setUser(\MSP\MSPBundle\Entity\User $user)
    {
        $this->user = $user;    
        return $this;
    }

    /**
     * Get user
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set sportStatGroup
     *
     * @param \MSP\MSPBundle\Entity\SportStatGroup $sportStatGroup
     * @return UserSeasonGameStatValue
     */
    public function setSportStatGroup(\MSP\MSPBundle\Entity\SportStatGroup $sportStatGroup = null)
    {
        $this->sportStatGroup = $sportStatGroup;    
        return $this;
    }


    /**
     * Get sportStatGroup
     *
     * @return \MSP\MSPBundle\Entity\SportStatGroup 
     */
    public function getSportStatGroup()
    {
        return $this->sportStatGroup;
    }

        /**
     * Set sportStat
     *
     * @param \MSP\MSPBundle\Entity\SportStat $sportStat
     * @return UserSeasonGameStatValue
     */
    public function setSportStat(\MSP\MSPBundle\Entity\SportStat $sportStat = null)
    {
        $this->sportStat = $sportStat;    
        return $this;
    }


    /**
     * Get sportStat
     *
     * @return \MSP\MSPBundle\Entity\SportStat 
     */
    public function getSportStat()
    {
        return $this->sportStat;
    }

}
