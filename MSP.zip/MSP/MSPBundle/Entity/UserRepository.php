<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 1/29/14
 * Time: 8:24 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;


use Doctrine\ORM\EntityRepository;
use MSP\MSPBundle\Entity\Connection;
use Application\Sonata\MediaBundle\Entity\Gallery;
use Application\Sonata\MediaBundle\Entity\Media;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\Query\ResultSetMappingBuilder;

class UserRepository extends EntityRepository
{

    public function getMainTeamForUser(User $user)
    {
        $team = null;

        if($teamSeason = $this->getMainTeamSeasonForUser($user)){
            $team = $teamSeason->getTeam();
        }

        return $team;
    }

    // creates teammates connection
    public function forceTeamConnect(User $athlete1, User $athlete2)
    {
        $connection = new Connection();
        $connection->setRequesterUser($athlete1);
        $connection->setRequestedUser($athlete2);
        $connection->setStatus(Connection::STATUS_ACTIVE);
        $connection->setConnectionType(Connection::TEAMMATE_CONNECTION);

        $this->getEntityManager()->persist($connection);
        $this->getEntityManager()->flush($connection);

    }

    public function getTeammatesForUser(User $user)
    {
        return $this->getEntityManager()
            ->createQuery(
                "SELECT u
                 FROM MSPBundle:User u
                 JOIN MSPBundle:Connection c
                 WHERE
                    (c.requesterUser = u.id AND c.requestedUser = :user AND c.status = :status AND c.connectionType = :connectionType)
                    OR
                    (c.requestedUser = u.id AND c.requesterUser = :user AND c.status = :status AND c.connectionType = :connectionType)
                 "
            )
            ->setParameters(array(
                'user' => $user->getId(),
                'status' => Connection::STATUS_ACTIVE,
                'connectionType' => Connection::TEAMMATE_CONNECTION
            ))
            ->getResult();
    }


    public function getConnectToUser($requestedUser, $requesterUser)
    {
        return $this->getEntityManager()
            ->createQuery(
                "SELECT count(c)
                 FROM MSPBundle:Connection c
                 WHERE
                    (c.requestedUser = :firstRequestedUser AND c.requesterUser = :firstRequesterUser)
                    OR
                    (c.requestedUser = :secondRequestedUser AND c.requesterUser = :secondRequesterUser)
                 "
            )
            ->setParameters(array(
                'firstRequestedUser' => $requestedUser,
                'firstRequesterUser' => $requesterUser,
                'secondRequestedUser' => $requesterUser,
                'secondRequesterUser' => $requestedUser,
            ))
            ->getSingleScalarResult();
    }

    public function getConnectionsForUser(User $user)
    {
        return $this->getEntityManager()
            ->createQuery(
                "SELECT u
                 FROM MSPBundle:User u
                 JOIN MSPBundle:Connection c
                 WHERE
                    (c.requesterUser = u.id AND c.requestedUser = :user AND c.status = :status )
                    OR
                    (c.requestedUser = u.id AND c.requesterUser = :user AND c.status = :status )
                 "
            )
            ->setParameters(array(
                'user' => $user->getId(),
                'status' => Connection::STATUS_ACTIVE
            ))
            ->getResult();
    }

    public function getMainTeamSeasonForUser(User $user)
    {
        return $this->getEntityManager()
            ->createQuery(
                "SELECT uts
                 FROM MSPBundle:UserTeamSeason uts
                 WHERE uts.user = :user
                 ORDER BY uts.year DESC
                 "
            )
            ->setMaxResults(1)
            ->setParameter('user', $user)
            ->getOneOrNullResult();
    }

    public function getJerseyNumberForUser(User $user)
    {

        $jerseyNum = null;

        if($teamSeason = $this->getMainTeamSeasonForUser($user)){
            $jerseyNum = $teamSeason->getJerseyNumber();
        }

        return $jerseyNum;
    }

    public function getTeamLogoForUser(User $user)
    {

        $teamLogo = null;
        $teamSeason = $this->getMainTeamSeasonForUser($user);

        if($teamSeason){
            if($teamSeason->getLogo()){
                $teamLogo = $teamSeason->getLogo();
            }else{
                $teamLogo = $teamSeason->getTeam()->getLogo();
            }
        }

        return $teamLogo;
    }

    public function getLastWallPostsForUser(User $user,  $count = 3)
    {
        return $this->getEntityManager()
            ->createQuery("
                SELECT wp
                FROM MSPBundle:WallPost wp
                WHERE wp.user = :user
                ORDER BY wp.created DESC
            ")
            ->setMaxResults($count)
            ->setParameter('user', $user)
            ->getResult();
    }

    public function getSeasonStatsForUser(User $user){
        return $this->getEntityManager()
            ->createQuery("
                SELECT
                  uts.id as uts_id,
                  uts.year as season_year,
                  season.name as season_name,
                  sport.name as season_sport_name,
                  ss.statCategory as stat_category,
                  ss.name as stat_name,
                  team.name as team_name,
                  ssv.value as stat_value
                FROM MSPBundle:UserTeamSeason uts
                    LEFT JOIN uts.seasonStats ssv
                    LEFT JOIN ssv.sportStat ss
                    JOIN uts.season season
                    JOIN uts.sport sport
                    JOIN uts.team team

                WHERE
                uts.user = :user

                ORDER BY uts.year, uts.id, ss.statCategory DESC
            ")
            ->setParameter('user', $user)
            ->getArrayResult();
    }

    public function getGameStatForSeasonUser(UserTeamSeason $userTeamSeason){
        return $this->getEntityManager()
            ->createQuery("
                SELECT g.*,  gsv.*, ss.*
                FROM MSPBundle:Game g
                LEFT JOIN MSPBundle:GameStatValue gsv
                LEFT JOIN MSPBundle:SportStat ss
                WHERE g.id = gsv.game
                  AND g.userTeamSeason = :userTeamSeason
                  AND gsv.sportStat = ss.id
                ORDER BY g.date
            ")
            ->setParameter('userTeamSeason', $userTeamSeason)
            ->getArrayResult();
    }

    public function searchUserByName($user, $userId=null){

        $rsm = new ResultSetMapping();

        $rsm->addScalarResult('userid', 'userid');
        $rsm->addScalarResult('firstname', 'firstname');
        $rsm->addScalarResult('lastname', 'lastname');
        $rsm->addScalarResult('slug', 'slug');
        $rsm->addScalarResult('gpa', 'gpa');
        $rsm->addScalarResult('sat', 'sat');
        $rsm->addScalarResult('height', 'height');
        $rsm->addScalarResult('weight', 'weight');
        $rsm->addScalarResult('sportname', 'sportname');
        $rsm->addScalarResult('schoolname', 'schoolname');
        $rsm->addScalarResult('year', 'year');
        $rsm->addScalarResult('position', 'position');
        $rsm->addScalarResult('image', 'image');
        $rsm->addScalarResult('context', 'context');
        $rsm->addScalarResult('imageid', 'imageid');
        $rsm->addScalarResult('slug', 'slug');
        $rsm->addScalarResult('physical', 'physical');

        $sql = "SELECT u.id as userid, u.firstname as firstname, u.lastname as lastname, u.slug as slug, u.gpa as gpa, u.sat_total_score as sat, u.height as height, u.weight as weight, sp.name as sportname, s.name as schoolname, muts.year as year, m.id as imageid, msp.name as position, m.provider_reference as image, m.context as context, GROUP_CONCAT(DISTINCT result.keyname) as physical";
        $sql .= " FROM fos_user u";
        $sql .= " LEFT JOIN msp_user_team_season muts ON u.id = muts.user_id";
        $sql .= " LEFT JOIN msp_user_team_season_position mutsp ON mutsp.user_team_season_id = muts.id";
        $sql .= " LEFT JOIN msp_sport_position msp ON msp.id = mutsp.sport_position_id";
        $sql .= " LEFT JOIN media__media m ON u.image_id = m.id";
        $sql .= " LEFT JOIN msp_school s ON s.id = muts.school_id";
        $sql .= " LEFT JOIN msp_sport sp ON sp.id = muts.sport_id";  
        $sql .= " LEFT JOIN (SELECT CONCAT_WS(':', mkm.name, mkmv.value) as keyname, mkmv.user_id from msp_key_measurable_value mkmv JOIN msp_key_measurable mkm ON mkm.id = mkmv.key_measurable_id WHERE mkm.is_physical = 1) result ON result.user_id = u.id";
        $sql .= " WHERE muts.user_id IS NOT NULL";
        if($userId != ''){
            $sql .= " AND u.id != '".$userId."'"; 
        } 
        $sql .= " AND ( u.firstname like '%".$user."%' OR u.lastname like '%".$user."%') ";             
        $sql .= " GROUP BY muts.user_id";        
        $sql .= " ORDER BY u.lastname DESC";

        $query  = $this->getEntityManager()->createNativeQuery($sql, $rsm);
        $result = $query->getResult();

        /*echo '<pre/>';
        print_r($result);
        die();*/
        return $result;

    }


    public function searchUserByList($userId = null, $class=null, $sport=null, $position=null, $sex=null, $min_age=null, $max_age=null, $min_height=null, $max_height=null, $min_weight=null, $max_weight=null, $hand=null, $school=null, $state = null){


        $rsm = new ResultSetMapping();

        $rsm->addScalarResult('userid', 'userid');
        $rsm->addScalarResult('firstname', 'firstname');
        $rsm->addScalarResult('lastname', 'lastname');
        $rsm->addScalarResult('slug', 'slug');
        $rsm->addScalarResult('gpa', 'gpa');
        $rsm->addScalarResult('sat', 'sat');
        $rsm->addScalarResult('height', 'height');
        $rsm->addScalarResult('weight', 'weight');
        $rsm->addScalarResult('sportname', 'sportname');
        $rsm->addScalarResult('schoolname', 'schoolname');
        $rsm->addScalarResult('year', 'year');
        $rsm->addScalarResult('position', 'position');
        $rsm->addScalarResult('image', 'image');
        $rsm->addScalarResult('context', 'context');
        $rsm->addScalarResult('imageid', 'imageid');
        $rsm->addScalarResult('slug', 'slug');
        $rsm->addScalarResult('physical', 'physical');

        $sql = " SELECT u.id as userid, u.firstname as firstname, u.lastname as lastname, u.slug as slug, u.gpa as gpa, u.sat_total_score as sat, u.height as height, u.weight as weight, sp.name as sportname, s.name as schoolname, muts.year as year, m.id as imageid, msp.name as position, m.provider_reference as image, m.context as context, GROUP_CONCAT(DISTINCT result.keyname) as physical, DATE_FORMAT( FROM_DAYS( TO_DAYS( NOW( ) ) - TO_DAYS( u.date_of_birth) ) , '%Y' ) + 0 AS age";

        $sql .= " FROM fos_user u";
        $sql .= " LEFT JOIN msp_user_team_season muts ON u.id = muts.user_id";
        $sql .= " LEFT JOIN media__media m ON u.image_id = m.id";
        $sql .= " LEFT JOIN msp_school s ON s.id = muts.school_id";
        $sql .= " LEFT JOIN msp_sport sp ON sp.id = muts.sport_id";  
        $sql .= " LEFT JOIN msp_user_team_season_position mutsp ON mutsp.user_team_season_id = muts.id";
        $sql .= " LEFT JOIN msp_sport_position msp ON msp.id = mutsp.sport_position_id";
        $sql .= " LEFT JOIN (SELECT CONCAT_WS(':', mkm.name, mkmv.value) as keyname, mkmv.user_id from msp_key_measurable_value mkmv JOIN msp_key_measurable mkm ON mkm.id = mkmv.key_measurable_id WHERE mkm.is_physical = 1) result ON result.user_id = u.id";
        

        if($position != ''){
            $sql .= " LEFT JOIN msp_sport_position_fos_user mspfos ON mspfos.user_id = u.id";  
        }

        if($hand != ''){
            $sql .= " LEFT JOIN msp_key_measurable_value kmv ON kmv.user_id = muts.id";  
        }

        $sql .= " WHERE muts.user_id IS NOT NULL";

        if($userId != ''){
            $sql .= " AND u.id != '".$userId."'"; 
        }

        if($sex != ''){
            $sql .= " AND u.gender = '".$sex."'";
        }

        if($position != ''){
            $sql .= " AND mspfos.sport_position_id = '".$position."'";
        }

        if($hand != ''){
            $sql .= " AND kmv.value = '".$hand."'";
        }

        if($class != ''){
            $sql .= " AND muts.year = '".$class."'";
        }

        if($sport != ''){
            $sql .= " AND muts.sport_id = '".$sport."'";
        }

        if($min_height != ''){
            $sql .= " AND u.height >= '".$min_height."'";
        }

        if($max_height != ''){
            $sql .= " AND u.height <= '".$max_height."'";
        }

        if($min_weight != ''){
            $sql .= " AND u.weight >= '".$min_weight."'";
        }
        
        if($max_weight != ''){
            $sql .= " AND u.weight <= '".$max_weight."'";
        }

        if($school != ''){
            $sql .= " AND muts.school_id = '".$school."'";
        }

        if($state != ''){
            $sql .= " AND u.state_region = '".$state."'";
        }

        $sql .= " GROUP BY muts.user_id ";
        $sql .= " having age >= ".$min_age ;
        if($max_age != ''){
            $sql .= " AND age <= ".$max_age ;
        }

        $sql .= " ORDER BY u.lastname DESC";

        // echo $sql;

        $query  = $this->getEntityManager()->createNativeQuery($sql, $rsm);
        $result = $query->getResult();

        //echo '<pre/>';
        //print_r($result);
        //die();

        return $result;
    }
}