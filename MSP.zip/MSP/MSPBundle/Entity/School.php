<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/11/13
 * Time: 1:06 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="msp_school")
 * @ORM\Entity(repositoryClass="SchoolRepository")
 */
class School
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=80)
     */
    protected $name;

    /**
     * @ORM\Column(type="string", length=15)
     */
    protected $state;

    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $district;


    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $county;

    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $address;


    /**
     * @ORM\Column(type="string", length=15)
     */
    protected $phone;

    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $city;

    /**
     * @ORM\Column(type="string", length=15)
     */
    protected $zip;


    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $schoolType;

    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $operationalStatus;

    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $stateSchoolId;


    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $stateDistrictId;


    /**
     * @ORM\Column(type="string", length=255)
     */
    protected $totalStudents;

    /**
     * @ORM\Column(type="integer")
     */
    protected $grade9Students;

    /**
     * @ORM\Column(type="integer")
     */
    protected $grade10Students;

    /**
     * @ORM\Column(type="integer")
     */
    protected $grade11Students;

    /**
     * @ORM\Column(type="integer")
     */
    protected $grade12Students;

    /**
     * @ORM\Column(type="integer")
     */
    protected $totalMale;

    /**
     * @ORM\Column(type="integer")
     */
    protected $totalFemale;

    /**
     * @ORM\Column(type="integer")
     */
    protected $totalAmericanIndianAlaskan;

    /**
     * @ORM\Column(type="integer")
     */
    protected $totalAsians;

    /**
     * @ORM\Column(type="integer")
     */
    protected $totalBlack;

    /**
     * @ORM\Column(type="integer")
     */
    protected $totalHispanic;

    /**
     * @ORM\Column(type="integer")
     */
    protected $totalWhite;

    /**
     * @ORM\Column(type="integer")
     */
    protected $freeLunchEligible;


    /**
     * @ORM\Column(type="integer")
     */
    protected $studentTeacherRatio;

    /**
     * @ORM\Column(type="integer")
     */
    protected $fteTeachers;

    /**
     * @ORM\Column(type="integer")
     */
    protected $schoolLevel;

    /**
     * @ORM\Column(type="integer")
     */
    protected $highGrade;


    /**
     * @ORM\Column(type="integer")
     */
    protected $lowGrade;


    /**
     * @ORM\Column(type="decimal", scale=5, precision=15 )
     */
    protected $latitude;


    /**
     * @ORM\Column(type="decimal", scale=5, precision=15 )
     */
    protected $longitude;

    

    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return School
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set state
     *
     * @param string $state
     * @return School
     */
    public function setState($state)
    {
        $this->state = $state;
    
        return $this;
    }

    /**
     * Get state
     *
     * @return string 
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set city
     *
     * @param string $city
     * @return School
     */
    public function setCity($city)
    {
        $this->city = $city;
    
        return $this;
    }

    /**
     * Get city
     *
     * @return string 
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set district
     *
     * @param string $district
     * @return School
     */
    public function setDistrict($district)
    {
        $this->district = $district;
    
        return $this;
    }

    /**
     * Get district
     *
     * @return string 
     */
    public function getDistrict()
    {
        return $this->district;
    }

    /**
     * Set county
     *
     * @param string $county
     * @return School
     */
    public function setCounty($county)
    {
        $this->county = $county;
    
        return $this;
    }

    /**
     * Get county
     *
     * @return string 
     */
    public function getCounty()
    {
        return $this->county;
    }

    /**
     * Set address
     *
     * @param string $address
     * @return School
     */
    public function setAddress($address)
    {
        $this->address = $address;
    
        return $this;
    }

    /**
     * Get address
     *
     * @return string 
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * Set phone
     *
     * @param string $phone
     * @return School
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    
        return $this;
    }

    /**
     * Get phone
     *
     * @return string 
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set zip
     *
     * @param string $zip
     * @return School
     */
    public function setZip($zip)
    {
        $this->zip = $zip;
    
        return $this;
    }

    /**
     * Get zip
     *
     * @return string 
     */
    public function getZip()
    {
        return $this->zip;
    }

    /**
     * Set schoolType
     *
     * @param string $schoolType
     * @return School
     */
    public function setSchoolType($schoolType)
    {
        $this->schoolType = $schoolType;
    
        return $this;
    }

    /**
     * Get schoolType
     *
     * @return string 
     */
    public function getSchoolType()
    {
        return $this->schoolType;
    }

    /**
     * Set operationalStatus
     *
     * @param string $operationalStatus
     * @return School
     */
    public function setOperationalStatus($operationalStatus)
    {
        $this->operationalStatus = $operationalStatus;
    
        return $this;
    }

    /**
     * Get operationalStatus
     *
     * @return string 
     */
    public function getOperationalStatus()
    {
        return $this->operationalStatus;
    }

    /**
     * Set stateSchoolId
     *
     * @param string $stateSchoolId
     * @return School
     */
    public function setStateSchoolId($stateSchoolId)
    {
        $this->stateSchoolId = $stateSchoolId;
    
        return $this;
    }

    /**
     * Get stateSchoolId
     *
     * @return string 
     */
    public function getStateSchoolId()
    {
        return $this->stateSchoolId;
    }

    /**
     * Set stateDistrictId
     *
     * @param string $stateDistrictId
     * @return School
     */
    public function setStateDistrictId($stateDistrictId)
    {
        $this->stateDistrictId = $stateDistrictId;
    
        return $this;
    }

    /**
     * Get stateDistrictId
     *
     * @return string 
     */
    public function getStateDistrictId()
    {
        return $this->stateDistrictId;
    }

    /**
     * Set totalStudents
     *
     * @param string $totalStudents
     * @return School
     */
    public function setTotalStudents($totalStudents)
    {
        $this->totalStudents = $totalStudents;
    
        return $this;
    }

    /**
     * Get totalStudents
     *
     * @return string 
     */
    public function getTotalStudents()
    {
        return $this->totalStudents;
    }

    /**
     * Set grade9Students
     *
     * @param integer $grade9Students
     * @return School
     */
    public function setGrade9Students($grade9Students)
    {
        $this->grade9Students = $grade9Students;
    
        return $this;
    }

    /**
     * Get grade9Students
     *
     * @return integer 
     */
    public function getGrade9Students()
    {
        return $this->grade9Students;
    }

    /**
     * Set grade10Students
     *
     * @param integer $grade10Students
     * @return School
     */
    public function setGrade10Students($grade10Students)
    {
        $this->grade10Students = $grade10Students;
    
        return $this;
    }

    /**
     * Get grade10Students
     *
     * @return integer 
     */
    public function getGrade10Students()
    {
        return $this->grade10Students;
    }

    /**
     * Set grade11Students
     *
     * @param integer $grade11Students
     * @return School
     */
    public function setGrade11Students($grade11Students)
    {
        $this->grade11Students = $grade11Students;
    
        return $this;
    }

    /**
     * Get grade11Students
     *
     * @return integer 
     */
    public function getGrade11Students()
    {
        return $this->grade11Students;
    }

    /**
     * Set grade12Students
     *
     * @param integer $grade12Students
     * @return School
     */
    public function setGrade12Students($grade12Students)
    {
        $this->grade12Students = $grade12Students;
    
        return $this;
    }

    /**
     * Get grade12Students
     *
     * @return integer 
     */
    public function getGrade12Students()
    {
        return $this->grade12Students;
    }

    /**
     * Set totalMale
     *
     * @param integer $totalMale
     * @return School
     */
    public function setTotalMale($totalMale)
    {
        $this->totalMale = $totalMale;
    
        return $this;
    }

    /**
     * Get totalMale
     *
     * @return integer 
     */
    public function getTotalMale()
    {
        return $this->totalMale;
    }

    /**
     * Set totalFemale
     *
     * @param integer $totalFemale
     * @return School
     */
    public function setTotalFemale($totalFemale)
    {
        $this->totalFemale = $totalFemale;
    
        return $this;
    }

    /**
     * Get totalFemale
     *
     * @return integer 
     */
    public function getTotalFemale()
    {
        return $this->totalFemale;
    }

    /**
     * Set totalAmericanIndianAlaskan
     *
     * @param integer $totalAmericanIndianAlaskan
     * @return School
     */
    public function setTotalAmericanIndianAlaskan($totalAmericanIndianAlaskan)
    {
        $this->totalAmericanIndianAlaskan = $totalAmericanIndianAlaskan;
    
        return $this;
    }

    /**
     * Get totalAmericanIndianAlaskan
     *
     * @return integer 
     */
    public function getTotalAmericanIndianAlaskan()
    {
        return $this->totalAmericanIndianAlaskan;
    }

    /**
     * Set totalAsians
     *
     * @param integer $totalAsians
     * @return School
     */
    public function setTotalAsians($totalAsians)
    {
        $this->totalAsians = $totalAsians;
    
        return $this;
    }

    /**
     * Get totalAsians
     *
     * @return integer 
     */
    public function getTotalAsians()
    {
        return $this->totalAsians;
    }

    /**
     * Set totalBlack
     *
     * @param integer $totalBlack
     * @return School
     */
    public function setTotalBlack($totalBlack)
    {
        $this->totalBlack = $totalBlack;
    
        return $this;
    }

    /**
     * Get totalBlack
     *
     * @return integer 
     */
    public function getTotalBlack()
    {
        return $this->totalBlack;
    }

    /**
     * Set totalHispanic
     *
     * @param integer $totalHispanic
     * @return School
     */
    public function setTotalHispanic($totalHispanic)
    {
        $this->totalHispanic = $totalHispanic;
    
        return $this;
    }

    /**
     * Get totalHispanic
     *
     * @return integer 
     */
    public function getTotalHispanic()
    {
        return $this->totalHispanic;
    }

    /**
     * Set totalWhite
     *
     * @param integer $totalWhite
     * @return School
     */
    public function setTotalWhite($totalWhite)
    {
        $this->totalWhite = $totalWhite;
    
        return $this;
    }

    /**
     * Get totalWhite
     *
     * @return integer 
     */
    public function getTotalWhite()
    {
        return $this->totalWhite;
    }

    /**
     * Set freeLunchEligible
     *
     * @param integer $freeLunchEligible
     * @return School
     */
    public function setFreeLunchEligible($freeLunchEligible)
    {
        $this->freeLunchEligible = $freeLunchEligible;
    
        return $this;
    }

    /**
     * Get freeLunchEligible
     *
     * @return integer 
     */
    public function getFreeLunchEligible()
    {
        return $this->freeLunchEligible;
    }

    /**
     * Set studentTeacherRatio
     *
     * @param integer $studentTeacherRatio
     * @return School
     */
    public function setStudentTeacherRatio($studentTeacherRatio)
    {
        $this->studentTeacherRatio = $studentTeacherRatio;
    
        return $this;
    }

    /**
     * Get studentTeacherRatio
     *
     * @return integer 
     */
    public function getStudentTeacherRatio()
    {
        return $this->studentTeacherRatio;
    }

    /**
     * Set fteTeachers
     *
     * @param integer $fteTeachers
     * @return School
     */
    public function setFteTeachers($fteTeachers)
    {
        $this->fteTeachers = $fteTeachers;
    
        return $this;
    }

    /**
     * Get fteTeachers
     *
     * @return integer 
     */
    public function getFteTeachers()
    {
        return $this->fteTeachers;
    }

    /**
     * Set schoolLevel
     *
     * @param integer $schoolLevel
     * @return School
     */
    public function setSchoolLevel($schoolLevel)
    {
        $this->schoolLevel = $schoolLevel;
    
        return $this;
    }

    /**
     * Get schoolLevel
     *
     * @return integer 
     */
    public function getSchoolLevel()
    {
        return $this->schoolLevel;
    }

    /**
     * Set highGrade
     *
     * @param integer $highGrade
     * @return School
     */
    public function setHighGrade($highGrade)
    {
        $this->highGrade = $highGrade;
    
        return $this;
    }

    /**
     * Get highGrade
     *
     * @return integer 
     */
    public function getHighGrade()
    {
        return $this->highGrade;
    }

    /**
     * Set lowGrade
     *
     * @param integer $lowGrade
     * @return School
     */
    public function setLowGrade($lowGrade)
    {
        $this->lowGrade = $lowGrade;
    
        return $this;
    }

    /**
     * Get lowGrade
     *
     * @return integer 
     */
    public function getLowGrade()
    {
        return $this->lowGrade;
    }

    /**
     * Set latitude
     *
     * @param string $latitude
     * @return School
     */
    public function setLatitude($latitude)
    {
        $this->latitude = $latitude;
    
        return $this;
    }

    /**
     * Get latitude
     *
     * @return string 
     */
    public function getLatitude()
    {
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param string $longitude
     * @return School
     */
    public function setLongitude($longitude)
    {
        $this->longitude = $longitude;
    
        return $this;
    }

    /**
     * Get longitude
     *
     * @return string 
     */
    public function getLongitude()
    {
        return $this->longitude;
    }
}