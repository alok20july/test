<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/8/13
 * Time: 2:46 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Tools\SchemaValidator;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;


/**
 * @UniqueEntity({"sport", "id"})
 * @ORM\Entity(repositoryClass="TeamRepository")
 * @ORM\Table(name="msp_team",uniqueConstraints={
 * @ORM\UniqueConstraint(columns={"sport_id", "id"})})
 */
class Team
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=120, nullable=false)
     */
    protected $name;

    /**
     * @ORM\Column(type="string", length=250, nullable=true)
     */
    protected $homeLocation;

    /**
     * @ORM\ManyToOne(targetEntity="Sport")
     * @ORM\JoinColumn(name="sport_id", referencedColumnName="id", nullable=false)
     */
    protected $sport;

    /**
     * @ORM\ManyToOne(targetEntity="User")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id", nullable=false)
     */
    protected $createdBy;

    /**
     * @ORM\ManyToOne(targetEntity="Application\Sonata\MediaBundle\Entity\Media",cascade={"persist"})
     */
    protected $logo;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    protected $description;

    /**
     * @ORM\OneToMany(targetEntity="Game", mappedBy="homeTeam")
     */
    protected $homeGames;

    /**
     * @ORM\OneToMany(targetEntity="Game", mappedBy="awayTeam")
     */
    protected $awayGames;

    /**
     * @ORM\ManyToMany(targetEntity="Meet", mappedBy="teams")
     */
    protected $meets;

    /**
     * @ORM\ManyToOne(targetEntity="School")
     * @ORM\JoinColumn(name="school_id", referencedColumnName="id")
     */
    protected $school;

    public function __toString()
    {
        if(isset($this->name))
        {
            return $this->name;
        }

        return '';
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Team
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set homeLocation
     *
     * @param string $homeLocation
     * @return Team
     */
    public function setHomeLocation($homeLocation)
    {
        $this->homeLocation = $homeLocation;
    
        return $this;
    }

    /**
     * Get homeLocation
     *
     * @return string 
     */
    public function getHomeLocation()
    {
        return $this->homeLocation;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Team
     */
    public function setDescription($description)
    {
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set sport
     *
     * @param \MSP\MSPBundle\Entity\Sport $sport
     * @return Team
     */
    public function setSport(\MSP\MSPBundle\Entity\Sport $sport = null)
    {
        $this->sport = $sport;
    
        return $this;
    }

    /**
     * Get sport
     *
     * @return \MSP\MSPBundle\Entity\Sport 
     */
    public function getSport()
    {
        return $this->sport;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->homeGames = new \Doctrine\Common\Collections\ArrayCollection();
        $this->awayGames = new \Doctrine\Common\Collections\ArrayCollection();
    }
    
    /**
     * Add homeGames
     *
     * @param \MSP\MSPBundle\Entity\Game $homeGames
     * @return Team
     */
    public function addHomeGame(\MSP\MSPBundle\Entity\Game $homeGames)
    {
        $this->homeGames[] = $homeGames;
    
        return $this;
    }

    /**
     * Remove homeGames
     *
     * @param \MSP\MSPBundle\Entity\Game $homeGames
     */
    public function removeHomeGame(\MSP\MSPBundle\Entity\Game $homeGames)
    {
        $this->homeGames->removeElement($homeGames);
    }

    /**
     * Get homeGames
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getHomeGames()
    {
        return $this->homeGames;
    }

    /**
     * Add awayGames
     *
     * @param \MSP\MSPBundle\Entity\Game $awayGames
     * @return Team
     */
    public function addAwayGame(\MSP\MSPBundle\Entity\Game $awayGames)
    {
        $this->awayGames[] = $awayGames;
    
        return $this;
    }

    /**
     * Remove awayGames
     *
     * @param \MSP\MSPBundle\Entity\Game $awayGames
     */
    public function removeAwayGame(\MSP\MSPBundle\Entity\Game $awayGames)
    {
        $this->awayGames->removeElement($awayGames);
    }

    /**
     * Get awayGames
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getAwayGames()
    {
        return $this->awayGames;
    }

    /**
     * Add meets
     *
     * @param \MSP\MSPBundle\Entity\Meet $meets
     * @return Team
     */
    public function addMeet(\MSP\MSPBundle\Entity\Meet $meets)
    {
        $this->meets[] = $meets;
    
        return $this;
    }

    /**
     * Remove meets
     *
     * @param \MSP\MSPBundle\Entity\Meet $meets
     */
    public function removeMeet(\MSP\MSPBundle\Entity\Meet $meets)
    {
        $this->meets->removeElement($meets);
    }

    /**
     * Get meets
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMeets()
    {
        return $this->meets;
    }

    /**
     * Get games
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getGames()
    {
        $games = array('homeGames' => $this->getHomeGames(), 'awayGames'=>$this->getAwayGames());

        return $games;
    }


    /**
     * Set logo
     *
     * @param \Application\Sonata\MediaBundle\Entity\Media $logo
     * @return Team
     */
    public function setLogo(\Application\Sonata\MediaBundle\Entity\Media $logo = null)
    {
        $this->logo = $logo;
    
        return $this;
    }

    /**
     * Get logo
     *
     * @return \Application\Sonata\MediaBundle\Entity\Media 
     */
    public function getLogo()
    {
        return $this->logo;
    }

    /**
     * Set createdBy
     *
     * @param \MSP\MSPBundle\Entity\User $createdBy
     * @return Team
     */
    public function setCreatedBy(\MSP\MSPBundle\Entity\User $createdBy)
    {
        $this->createdBy = $createdBy;
    
        return $this;
    }

    /**
     * Get createdBy
     *
     * @return \MSP\MSPBundle\Entity\User 
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set school
     *
     * @param \MSP\MSPBundle\Entity\School $school
     * @return Team
     */
    public function setSchool(\MSP\MSPBundle\Entity\School $school = null)
    {
        $this->school = $school;
    
        return $this;
    }

    /**
     * Get school
     *
     * @return \MSP\MSPBundle\Entity\School 
     */
    public function getSchool()
    {
        return $this->school;
    }
}