<?php
/**
 * Created by Alok Kumar
 * User: alok
 * Date: 6/23/14
 * Time: 12:31 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\DataFixtures\ORM;

use MSP\MSPBundle\Entity\Sport;
use MSP\MSPBundle\Entity\SportStat;
use MSP\MSPBundle\Entity\SportStatGroup;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\FixtureInterface;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;


class LoadSportStatGroupData implements FixtureInterface, ContainerAwareInterface
{
    /**
     * {@inheritDoc}
     */

    private $container;

    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }

    public function load(ObjectManager $manager)
    {
        $em        = $this->container->get('doctrine')->getEntityManager();
        $sports     = $em->getRepository('MSPBundle:Sport')->findAll();
        foreach($sports as $sport){
            $sportStatGroup = new SportStatGroup();
            $sportStatGroup->setSport($sport);
            $sportStatGroup->setName('Overall');
            $sportStatGroup->setTooltip('');
            $manager->persist($sportStatGroup);
            $manager->flush();
            $sportStat = new SportStat();
            $sportStat->setSport($sport);
            $sportStat->setSportStatGroup($sportStatGroup);
            $sportStat->setName('Overall Data');
            $sportStat->setAbbrev('OD');
            $sportStat->setDefaultValue(0);
            $sportStat->setWidgetType('input');
            $sportStat->setTooltip('');
            $sportStat->setStatType('sum');
            $sportStat->setOptions('');
            $sportStat->setIsGlobal(1);
            $sportStat->setStatCategory('all_stat');
            $manager->persist($sportStat);
            $manager->flush();
        }
    }
}