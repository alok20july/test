<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 4/1/14
 * Time: 10:31 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\DataFixtures\ORM;

use Application\Sonata\MediaBundle\Entity\Gallery;
use Doctrine\Common\DataFixtures\FixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;


class LoadMediaData implements FixtureInterface
{
    /**
     * {@inheritDoc}
     */
    public function load(ObjectManager $manager)
    {
        $gallery = new Gallery();
        $gallery->setContext('default');
        $gallery->setName('msp');
        $gallery->setEnabled(true);
        $gallery->setDefaultFormat('big');
        $manager->persist($gallery);
        $manager->flush();
    }
}