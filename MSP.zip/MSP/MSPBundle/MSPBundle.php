<?php

namespace MSP\MSPBundle;

use Doctrine\DBAL\Types\Type;
use MSP\MSPBundle\DBAL\EnumStatType;
use MSP\MSPBundle\DependencyInjection\Compiler\OverrideServiceCompilerPass;
use Symfony\Component\DependencyInjection\Compiler\PassConfig;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class MSPBundle extends Bundle
{
    public function build(ContainerBuilder $container)
    {
        parent::build($container);

        $container->addCompilerPass(new OverrideServiceCompilerPass(), PassConfig::TYPE_BEFORE_OPTIMIZATION);

        // load new doctrine type

    }

}
