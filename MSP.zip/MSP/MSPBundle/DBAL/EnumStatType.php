<?php
namespace MSP\MSPBundle\DBAL;

use Doctrine\DBAL\Types\Type;
use Doctrine\DBAL\Platforms\AbstractPlatform;

class EnumStatType extends Type
{
    const NAME = 'enumstat';

    const SEASON_STAT = 'season_stat';
    const GAME_STAT = 'game_stat';
    const ALL_STAT ='all_stat';
    const MEET_STAT = 'meet_stat';



    public function getSqlDeclaration(array $fieldDeclaration, AbstractPlatform $platform)
    {
        return "ENUM('all_stat', 'game_stat', 'season_stat', 'meet_stat') COMMENT '(DC2Type:enumstat)'";
    }

    public function convertToPHPValue($value, AbstractPlatform $platform)
    {
        return $value;
    }

    public function convertToDatabaseValue($value, AbstractPlatform $platform)
    {
        if (!in_array($value, array(self::SEASON_STAT, self::GAME_STAT, self::MEET_STAT, self::ALL_STAT))) {
            throw new \InvalidArgumentException("Invalid status");
        }
        return $value;
    }

    public function getName()
    {
        return self::NAME;
    }
}