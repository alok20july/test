<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

namespace MSP\MSPBundle\Form\EventListener;

use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use MSP\MSPBundle\Entity\Team;
use MSP\MSPBundle\Entity\Game;
use MSP\MSPBundle\Form\DataTransformer\IdToTeamTransformer;

class GameNameSubscriber implements EventSubscriberInterface
{
    private $em;
    private $user;
    private $sportid;
    public function __construct($em, $securityContext=null) {
        $this->em = $em;
        $this->user = $securityContext->getToken()->getUser();
    }
    public static function getSubscribedEvents()
    {
        // Tells the dispatcher that you want to listen on the form.pre_set_data
        // event and that the preSetData method should be called.
        return array(FormEvents::PRE_SET_DATA => 'preSetData');
    }

    public function preSetData(FormEvent $event)
    {
        $data = $event->getData();

        if(((isset($data['name']) && $data['name'] == ' ') || (!isset($data['name']))) && (isset($data['homeTeam']) && isset($data['awayTeam'])))
        {
            $data['name']->setName($data['homeTeam'] . "VS" . $data['awayTeam']);

            $event->setData($data);
        }



        return true;
    }
}