<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

namespace MSP\MSPBundle\Form\EventListener;

use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use MSP\MSPBundle\Entity\Team;


class AddOpponentTeamSubscriber implements EventSubscriberInterface
{
    private $em;
    private $securityContext;

    public function __construct($em, $securityContext) {
        $this->em = $em;
        $this->securityContext = $securityContext;
    }

    public static function getSubscribedEvents()
    {
        // Tells the dispatcher that you want to listen on the form.pre_set_data
        // event and that the preSetData method should be called.
        return array(FormEvents::PRE_SUBMIT => 'preSubmit');
    }

    public function preSubmit(FormEvent $event)
    {
        $data = $event->getData();

        if(isset($data['awayTeamName']) && strlen($data['awayTeamName']) > 3){

            $awayTeamName = trim(ucwords($data['awayTeamName']));

            $awayTeam = $this->em
                ->getRepository('MSPBundle:Team')
                ->findOneBy(array('name' => $awayTeamName))
            ;

            $myTeam = $this->em
                ->getRepository('MSPBundle:Team')
                ->findOneBy(array('id' => $data['homeTeam']))
            ;

            if(!$awayTeam || $awayTeam->getSport() !== $myTeam->getSport()){

                $user = $this->securityContext->getToken()->getUser();
                $team = new Team();
                $team->setSport($myTeam->getSport());
                $team->setName($awayTeamName);
                $team->setCreatedBy($user);
                $this->em->persist($team);
                $this->em->flush();
                $id = $team->getId();

                $data['awayTeam'] = $id;

                $event->setData($data);
            }
        }
        return true;
    }
}