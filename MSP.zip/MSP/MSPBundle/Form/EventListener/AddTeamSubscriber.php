<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

namespace MSP\MSPBundle\Form\EventListener;

use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use MSP\MSPBundle\Entity\Team;
use MSP\MSPBundle\Form\DataTransformer\IdToTeamTransformer;

class AddTeamSubscriber implements EventSubscriberInterface
{
    private $em;
    private $user;
    private $sportid;
    public function __construct($em, $securityContext) {
        $this->em = $em;
        $this->user = $securityContext->getToken()->getUser();
    }
    public static function getSubscribedEvents()
    {
        // Tells the dispatcher that you want to listen on the form.pre_set_data
        // event and that the preSetData method should be called.
        return array(FormEvents::PRE_SUBMIT => 'preSubmit');
    }

    public function preSubmit(FormEvent $event)
    {
        $data = $event->getData();
        $newTeamAdded = false;

        if(isset($data['team']) && $data['team'] > 0 && isset( $data['teamName']))
        {
            $team = $this->em
                ->getRepository('MSPBundle:Team')
                ->findOneBy(array('id' => $data['team']))
            ;

            if($team->getName() != $data['teamName'])
            {
                $newTeamAdded = true;
            }
        }

        // adds new team
        // first check if team doesn't already exist
        if(isset($data['teamName']) && isset($data['sport'])){
            $team = $this->em
                ->getRepository('MSPBundle:Team')
                ->findOneBy(array('name' => $data['teamName'], 'sport' => $data['sport']))
            ;

            if($team){
                $id = $team->getId();
                $data['team'] = $id;
                $event->setData($data);
            }

        }

        if(!isset($data['team']) || $data['team'] < 1 || $newTeamAdded)
        {
            $team = new Team();
            $sport = $this->em
                          ->getRepository('MSPBundle:Sport')
                          ->findOneBy(array('id' => $data['sport']))
            ;



            $team->setName($data['teamName']);
            $team->setSport($sport);
            $team->setCreatedBy($this->user);
            $this->em->persist($team);
            $this->em->flush();

            $id = $team->getId();
            $data['team'] = $id;

            $event->setData($data);
        }

        if(isset($data['sport']) && !empty($data['sport']))
        {

            $sport = $this->em
                ->getRepository('MSPBundle:Sport')
                ->findOneBy(array('id' => $data['sport']))
            ;

            if(!$this->user->hasSport($sport))
            {
                $this->user->addSport($sport);
                $this->em->persist($this->user);
                $this->em->flush();
            }
        }

        //  if sport position is submitted, add the sport position to the userSportSportPosition.
        if(isset($data['sportpositions']) && !empty($data['sportpositions']))
        {

            foreach($data['sportpositions'] as $posId)
            {
                $sportPosition = $this->em
                    ->getRepository('MSPBundle:sportPosition')
                    ->findOneBy(array('id' => $posId));



                if(!$this->user->hasSportPosition($sportPosition))
                {
                    $this->user->addSportPosition($sportPosition);
                    $this->em->persist($this->user);
                    $this->em->flush();
                }
            }
        }

        // @todo do not create duplicates for userTeamSeason

        return true;
    }
}