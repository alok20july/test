<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 1/29/14
 * Time: 6:27 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Form\EventListener;


use MSP\MSPBundle\Entity\GameStatValue;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;

class AddGameStatValueSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents()
    {
        // Tells the dispatcher that you want to listen on the form.pre_set_data
        // event and that the preSetData method should be called.
        return array(FormEvents::PRE_SET_DATA => 'preSetData');
    }

    public function preSetData(FormEvent $event)
    {
        $gameStatValue = $event->getData();
        $form = $event->getForm();

        if($gameStatValue instanceof GameStatValue){
            if($stat = $gameStatValue->getSportStat()){
                $widgetTypeName = $stat->getWidgetType();

                switch($widgetTypeName)
                {
                    case 'choice':
                        $choices = explode(',', $stat->getOptions());
                        $choices = array_combine($choices, $choices);
                        $form->add("value", 'choice', array('choices'=> $choices, 'required' => false, 'label' => $stat->getAbbrev(),
                            'data_class' => 'MSP\MSPBundle\Entity\GameStatValue',
                            'attr' => array('class' => 'stat_input'),
                            'label_attr' => array('data-toggle'=>'tooltip', 'data-placement'=>"top", 'title' => $stat->getTooltip()))
                        );
                        break;

                    case 'checkbox':
                        $form->add("value", 'checkbox', array('required' => false,
                            'label' => $stat->getAbbrev(),
                            'data_class' => 'MSP\MSPBundle\Entity\GameStatValue',
                            'attr' => array('class' => 'stat_input'),
                            'label_attr' => array('data-toggle'=>'tooltip', 'data-placement'=>"top", 'title' => $stat->getTooltip())
                        ));
                        break;

                    case 'date':
                        $form->add("value", null, array('label' => $stat->getAbbrev(), 'required' => false,
                            'data_class' => 'MSP\MSPBundle\Entity\GameStatValue',
                            'attr' => array('class' => 'date_input stat_input'),
                            'label_attr' => array('data-toggle'=>'tooltip', 'data-placement'=>"top", 'title' => $stat->getTooltip())
                        ));
                        break;

                    default:
                        $form->add("value", null, array('label' => $stat->getAbbrev(), 'required' => false,
                            'data_class' => 'MSP\MSPBundle\Entity\GameStatValue',
                            'attr' => array('class' => 'stat_input'),
                            'label_attr' => array('data-toggle'=>'tooltip', 'data-placement'=>"top", 'title' => $stat->getTooltip())
                        ));
                }
            }
        }
    }

}