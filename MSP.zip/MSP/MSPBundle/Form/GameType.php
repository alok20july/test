<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use MSP\MSPBundle\Form\Type;

class GameType extends AbstractType
{

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', null, array('label' => 'Name: '))
            ->add('sport', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\Sport'))
            ->add('season', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\Season'))
            ->add('location', null, array('label' => 'Location: '))

            ->add('datetimeStart', null, array('label' => 'DateTime Start: ','attr' => array('class' => 'date_input'), 'years' => range(1980, date('Y'))))//, 'widget' => 'single_text')) // 'years' => range(date($options['teamSeason']->getSeason()->getYear()), date('Y'))))//, 'attr' => array('class' => 'date_input')))
            ->add('datetimeEnd', null, array('label' => 'DateTime End: ','attr' => array('class' => 'date_input'), 'years' => range(1980, date('Y'))))  //

            ->add('homeTeam', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\Team'))
            ->add('awayTeam', null, array(
                'label' => ' ',
                'required' => true
            ))
            ->add('points1', null, array('label' => 'Points: '))
            ->add('points2', null, array('label' => 'Points: '))
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\Game'
        ));

        $resolver->setRequired(array(
            'em',
        ));

        $resolver->setAllowedTypes(array(
            'em' => 'Doctrine\Common\Persistence\ObjectManager'
        ));
    }

    /**
     * Returns the default options/class for this form.
     * @param array $options
     * @return array The default options
     */
    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\Game'

        );
    }


    public function getName()
    {
        return 'msp_game_type';
    }
}
