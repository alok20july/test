<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

use MSP\MSPBundle\Form\DataTransformer\IdToMediaTransformer;

class MediaType extends AbstractType
{
    private $em;
    private $securityContext;
    public function __construct($em, $securityContext){
        $this->em = $em;
        $this->securityContext = $securityContext;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('content', null, array('label' => ' ', 'required' => false))
            ->add('video', 'sonata_media_type', array('context' => 'gallery', 'label'=> 'Paste your YouTube url here.', 'provider' => 'sonata.media.provider.youtube', 'required' => false))
            ->add('image', 'sonata_media_type', array('context' => 'gallery', 'provider' => 'sonata.media.provider.image', 'required' => false));
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\UserMedia'
        ));
    }

    /**
     * Returns the default options/class for this form.
     * @param array $options
     * @return array The default options
     */
    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\UserMedia'
        );
    }

    public function getName()
    {
        return 'msp_media_type';
    }
}
