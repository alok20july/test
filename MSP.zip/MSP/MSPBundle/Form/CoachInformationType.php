<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProfileInformationType
 *
 * @author hdorfman
 */
namespace MSP\MSPBundle\Form;
use Symfony\Component\Form\FormBuilderInterface;
class CoachInformationType extends UserType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('email')
            ->add('firstName')
            ->add('middleName')
            ->add('lastName')
            ->add('nickName')
            ->add('dob', null, array('years' => range(1920, date('Y'))))
            ->add('gender', 'choice', array(
                'choices'   => array('Male' => 'Male', 'Female' => 'Female'),
                'required'  => true,))
            ->add('bio')
            ->add('image')
            ->add('phone')
            ->add('address')
            ->add('city')
            ->add('stateRegion')
            ->add('country')
            ->add('postalCode')
            ->add('sports', null, array('required' => false, 'expanded' => true))
        ;
    }
    
    public function getName()
    {
        return 'msp_mspbundle_coachinformationtype';
    }
}

