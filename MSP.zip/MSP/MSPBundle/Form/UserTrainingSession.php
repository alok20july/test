<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use MSP\MSPBundle\Entity;

class UserTrainingSession extends AbstractType
{
    private $em;
    private $securityContext;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {        
        $builder
        ->add('sessionCreated', 'date', array(
            'widget' => 'single_text',
            'format' => 'MM/dd/yyyy',
            'data'  => new \DateTime()
        ));
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\TrainingSession'
        ));
    }

    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\TrainingSession'
        );
    }

    public function getName()
    {
        return 'msp_user_session_keymeasurables';
    }
}
