<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use MSP\MSPBundle\Entity;

class KeyMeasurablesType extends AbstractType
{
    protected $em;

    protected $securityContext;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if (isset($options['keyMeasurable']))
        {
            $keyMeasurable = $options['keyMeasurable'];

            $widgetTypeName = $keyMeasurable->getWidgetType();

            switch($widgetTypeName)
            {
                case 'choice':
                    $choices = explode(',', $keyMeasurable->getOptions());
                    $choices = array_combine($choices, $choices);
                    $builder->add('value', 'choice', array(
                            'choices'=> $choices,
                            'label' => $keyMeasurable->getName(),
                            'attr' => array('class' => 'input-block-level'),
                            'label_attr' => array('data-toggle'=>'tooltip',
                                'data-placement'=>"top",
                                'title' => $keyMeasurable->getTooltip()
                            )));
                    break;

                case 'checkbox':
                    $builder->add('value', 'checkbox', array(
                        'required' => false,
                        'label' => $keyMeasurable->getName(),
                        'label_attr' => array('data-toggle'=>'tooltip',
                            'data-placement'=>"top",
                            'title' => $keyMeasurable->getTooltip()
                        )));
                    break;

                case 'date':
                    $builder->add('value', null, array(
                        'label' => $keyMeasurable->getName(), 
                        'attr' => array('class' => 'date_input input-block-level'),
                        'label_attr' => array(
                            'data-toggle'=>'tooltip',
                            'data-placement'=>"top",
                            'title' => $keyMeasurable->getTooltip()
                        )));
                    break;

                default:
                    $builder->add('value', null, array(
                        'label' => $keyMeasurable->getName(),
                        'attr' => array('class' => 'input-block-level'),
                        'label_attr' => array(
                            'data-toggle'=>'tooltip',
                            'data-placement'=>"top",
                            'title' => $keyMeasurable->getTooltip()
                        )));
            }

            $builder
                ->add('keyMeasurable', null, array('data' => $keyMeasurable, 'attr' => array('class' => 'hidden'),
                    'label' => $keyMeasurable->getName()))
            ;

        }
        else
        {
            $builder
                ->add('keyMeasurable', null, array('attr' => array('class' => 'hidden'),
                    'label' => ' '))
                ->add('value')
            ;
        }

    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\KeyMeasurableValue',
        ));

        $resolver->setOptional(array(
            'keyMeasurable',
        ));

        $resolver->setAllowedTypes(array(
            'keyMeasurable' => 'MSP\MSPBundle\Entity\KeyMeasurable',
        ));


        $resolver->setRequired(array(
            'em',
        ));

        $resolver->setOptional(array('value'));

        $resolver->setAllowedTypes(array(
            'em' => 'Doctrine\Common\Persistence\ObjectManager'
        ));
    }

    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\KeyMeasurableValue'

        );
    }

    public function getName()
    {
        return 'msp_mspbundle_mykeymeasurables';
    }
}
