<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 1/29/14
 * Time: 1:41 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Form;


use Doctrine\ORM\EntityManager;
use Entities\User;
use MSP\MSPBundle\Entity\GameStatValue;
use MSP\MSPBundle\Entity\Sport;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class GameStatValuesContainerType extends AbstractType{


    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('gameStatValues', 'collection', array('type' => new GameStatValueType()));
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\Game',
        ));
    }

    public function getName()
    {
        return 'game_stat_values_container';
    }
}