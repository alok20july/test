<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use MSP\MSPBundle\Form\Type;

class MeetType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', null, array('label' => 'Name: '))
            ->add('sport', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\Sport'))
            ->add('season', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\Season'))
            ->add('location', null, array('label' => 'Location: '))

            ->add('datetimeStart', null, array('label' => 'DateTime Start: ', 'years' => range(1980, date('Y'))))
            ->add('datetimeEnd', null, array('label' => 'DateTime End: ', 'years' => range(1980, date('Y'))))

            ->add('teams', null, array(
                'label' => 'Teams: ',
                'required' => true
            ))
            ->add('competitors', null, array(
                'label' => 'Competitors: ',
                'required' => false
            ))
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\Meet'
        ));

        $resolver->setRequired(array(
            'em',
        ));

        $resolver->setOptional(array('season_id'));

        $resolver->setAllowedTypes(array(
            'em' => 'Doctrine\Common\Persistence\ObjectManager'
        ));
    }

    /**
     * Returns the default options/class for this form.
     * @param array $options
     * @return array The default options
     */
    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\Meet'
        );
    }


    public function getName()
    {
        return 'msp_meet_type';
    }
}
