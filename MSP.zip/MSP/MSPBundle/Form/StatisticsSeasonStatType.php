<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use MSP\MSPBundle\Entity;

class StatisticsSeasonStatType extends AbstractType
{
    protected $em;

    protected $securityContext;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('userTeamSeason', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\UserTeamSeason'))
            ->add('sportStat')
            ->add('value', null, array('label' => ' ', 'required' => false))
            ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\SeasonStatValue'
        ));
        $resolver->setRequired(array(
            'em',
        ));
        $resolver->setAllowedTypes(array(
            'em' => 'Doctrine\Common\Persistence\ObjectManager'));
    }

    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\SeasonStatValue'
        );
    }

    public function getName()
    {
        return 'msp_statistics_season_stat_type';
    }
}