<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 2/11/14
 * Time: 2:05 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use MSP\MSPBundle\Form\DataTransformer\IdToTeamTransformer;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class TeamSeasonType extends AbstractType
{

    private $teamListener;


    public function __construct(\MSP\MSPBundle\Form\EventListener\AddTeamSubscriber $teamListener)
    {
        $this->teamListener = $teamListener;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $entityManager = $options['em'];

        $qb = $entityManager->createQueryBuilder();
        $qb->select('sp')
            ->from('\MSP\MSPBundle\Entity\SportPosition', 'sp')
            ->orderBy('sp.name', 'ASC');

        $listener = $this->teamListener;
        $transformer = new IdToTeamTransformer($entityManager);
        $builder->addEventSubscriber($listener);
        $builder
            ->add('sport',  null, array(
                'label' => ' ',
                'property' => 'name',
                'required' => true
            ))
            ->add($builder->create('team', 'hidden')
            ->addModelTransformer($transformer))
            ->add('teamName', null, array('label' => ' ', 'mapped' => true, 'required' => false, 'attr' => array('placeholder' => 'Team')
            ))
            ->add('season', null, array('label' => ' ', 'required' => true, 'attr' => array('length' => '2')))
            ->add('year', null, array('label' => ' ', 'required' => false, 'attr' => array('placeholder' => '2013', 'width' => 4)))
            ->add('logo', 'sonata_media_type', array(
                'provider' => 'sonata.media.provider.image',
                'context'  => 'profile',
                'required' => false
            ))
            ->add('level', 'choice', array('choices' => array('Freshman' => 'Freshman', 'Junior Varsity' => 'Junior Varsity', 'Varsity' => 'Varsity')))

            ->add('sportpositions', null, array('query_builder' => $qb, 'required' => false, 'expanded' => false, 'label' => ' ', 'attr' => array('inline' => true)))
        ;
    }

    /**
     * Returns the default options/class for this form.
     * @param array $options
     * @return array The default options
     */
    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\UserTeamSeason'
        );
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setRequired(array(
            'em',
        ));
        $resolver->setAllowedTypes(array(
            'em' => 'Doctrine\Common\Persistence\ObjectManager'
        ));
    }

    public function getName()
    {
        return 'msp_team_season_type';
    }
}