<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProfileImage
 *
 * @author hdorfman
 */
namespace MSP\MSPBundle\Form;
use Symfony\Component\Form\FormBuilderInterface;
class ProfileImage extends UserType
{
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('image', 'sonata_media_type', array(
                'provider' => 'sonata.media.provider.image',
                'context'  => 'profile',
                'required' => false
           ))
        ;
        
    }
    
    public function getName()
    {
        return 'msp_mspbundle_profileimage';
    }
}

