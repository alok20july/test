<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 1/29/14
 * Time: 11:39 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Form;

use MSP\MSPBundle\Entity\GameStatValue;
use MSP\MSPBundle\Entity\SportStat;
use MSP\MSPBundle\Form\EventListener\AddGameStatValueSubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class GameStatValueType extends AbstractType
{

    private $stat = null;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->addEventSubscriber(new AddGameStatValueSubscriber());
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\GameStatValue',
        ));
    }

    public function setStat($stat){
        $this->stat = $stat;
    }

    public function getName()
    {
        return 'game_stat_value_type';
    }


}