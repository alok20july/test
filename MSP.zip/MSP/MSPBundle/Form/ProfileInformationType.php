<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ProfileInformationType
 *
 * @author hdorfman
 */
namespace MSP\MSPBundle\Form;
use Symfony\Component\Form\FormBuilderInterface;
use Doctrine\ORM\EntityRepository;
use MSP\MSPBundle\Form\DataTransformer\FeetToInchTransformer;

class ProfileInformationType extends UserType
{
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        $builder
            ->add('email', null, array('label' => '', 'required'  => true))
            ->add('firstName', null, array('label' => '', 'required'  => true))
            ->add('middleName')
            ->add('lastName', null, array('label' => '', 'required'  => true))
            ->add('nickName', null, array('label' => 'Nick Name: '))
            ->add('twitterHandle', null, array('label' => 'Twitter Handle '))
            ->add('ncaaClearinghouseId', null, array('label' => 'NCAA Clearinghouse ID '))
            ->add('dateOfBirth', null, array('years' => range(1920, date('Y')), 'widget'=>'single_text', 'format' => 'MM/dd/yyyy', 'required'  => true))
            ->add('gender', 'choice', array(
                'choices'   => array('Male' => 'Male', 'Female' => 'Female'),
                'required'  => true,))
            // ->add('height', null, array('label' => 'Height: ', 'required'  => true))
            ->add(
                    $builder->create('height', null, array('label' => 'Height: '))
                            ->addViewTransformer(new FeetToInchTransformer())
                )
            ->add('weight', null , array('label' => 'Weight: ','invalid_message'=>'Valus should be greater than 0'))
            ->add('bio', null, array('label' => 'Bio: '))
            ->add('phone')
            ->add('address', null, array('label' => 'Address: '))
            ->add('address2', null, array('label' => 'Address: '))
            ->add('city', null, array('label' => 'City: '))
            ->add('stateRegion', null, array('label' => 'State/Region: '))
            ->add('country', null, array('label' => 'Country: '))
            ->add('postalCode', null, array('label' => 'Postal Code: '))
            ->add('sports', null, array('required' => false, 'expanded' => true))
            ->add('image', 'sonata_media_type', array(
                'provider' => 'sonata.media.provider.image',
                'context'  => 'profile',
                'required' => false
           ))
        ;
        
    }
    
    public function getName()
    {
        return 'msp_mspbundle_profileinformationtype';
    }
}

