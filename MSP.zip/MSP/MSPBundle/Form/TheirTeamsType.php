<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 6/20/14
 * Time: 04:06 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use MSP\MSPBundle\Form\DataTransformer\IdToTeamTransformer;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class TheirTeamsType extends AbstractType
{

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('sport',  null, array(
                'label' => ' ',
                'property' => 'name',
                'required' => true,
            ))
            ->add('name', null, array('label' => ' ', 'mapped' => true, 'required' => true, 'attr' => array('placeholder' => 'Team')
            ))            
        ;
    }

    /**
     * Returns the default options/class for this form.
     * @param array $options
     * @return array The default options
     */
    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\Team'
        );
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setRequired(array(
            'em',
        ));
        $resolver->setAllowedTypes(array(
            'em' => 'Doctrine\Common\Persistence\ObjectManager'
        ));
    }

    public function getName()
    {
        return 'msp_their_team';
    }
}