<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

use MSP\MSPBundle\Form\DataTransformer\IdToMediaTransformer;

class WallType extends AbstractType
{
    private $em;
    private $securityContext;
    public function __construct($em, $securityContext){
        $this->em = $em;
        $this->securityContext = $securityContext;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $myTeams = $options['data']->getUser()->getMyTeamOptions();
        $gameStatFormType = new GameStatFormType($myTeams, $this->em, $this->securityContext);

        $builder
            ->add('content', null, array('label' => ' ', 'required' => false))
            ->add('video', 'sonata_media_type', array('label'=>'Paste your YouTube url here.', 'context' => 'wall', 'provider' => 'sonata.media.provider.youtube', 'required' => false))
            ->add('image', 'sonata_media_type', array('context' => 'wall', 'provider' => 'sonata.media.provider.image', 'required' => false))
            ->add('game', $gameStatFormType, array('required' => false))
         ;

    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\WallPost'
        ));
    }

    /**
     * Returns the default options/class for this form.
     * @param array $options
     * @return array The default options
     */
    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\WallPost'
        );
    }

    public function getName()
    {
        return 'msp_wall_type';
    }
}
