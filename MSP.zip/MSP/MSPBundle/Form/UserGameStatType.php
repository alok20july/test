<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use MSP\MSPBundle\Entity;

class UserGameStatType extends AbstractType
{
    protected $em;

    protected $securityContext;

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if (isset($options['sportStat']))
        {
            $stat = $options['sportStat'];

            $type = $stat->getSport()->getIsTeamSport();

            switch($type)
            {
                case 'true':
                    $builder->add('game');
                    break;

                case 'false':
                    $builder->add('meet');
                    break;
            }


            $builder
                ->add('sportStat');
            ;

        }
        else
        {
            $builder
                ->add('sportStat');
        }

        $builder
            ->add('game', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\Game'))
            ->add('sportStat')
            ->add('value', null, array('label' => ' '))
            ;

    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\GameStatValue'
        ));

        $resolver->setOptional(array(
            'sportStat',
        ));

        $resolver->setRequired(array(
            'em',
        ));

        $resolver->setAllowedTypes(array(
            'em' => 'Doctrine\Common\Persistence\ObjectManager',
            'sportStat' => 'MSP\MSPBundle\Entity\SportStat',
        ));
    }

    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\GameStatValue'

        );
    }

    public function getName()
    {
        return 'msp_user_game_stat_type';
    }
}
