<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 1/28/14
 * Time: 5:16 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Form;

use MSP\MSPBundle\Form\EventListener\AddGameStatValueSubscriber;
use MSP\MSPBundle\Form\EventListener\AddOpponentTeamSubscriber;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class GameStatFormType extends AbstractType
{

    private $myTeams = array();
    private $em;
    private $securityContext;

    public function __construct($myTeams, $em, $securityContext){
        $this->myTeams = $myTeams;
        $this->em = $em;
        $this->securityContext = $securityContext;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        $builder->addEventSubscriber(new AddGameStatValueSubscriber());

        $builder->addEventSubscriber(new AddOpponentTeamSubscriber($this->em, $this->securityContext));

        $builder
            //->add('homeTeamName', null, array("mapped" => false))
            ->add('awayTeamName', null, array("mapped" => false))
            ->add('season', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\Season'))
            ->add('datetimeStart', 'date', array('label' => 'Date: ', 'widget'=>'single_text', 'format' => 'MM/dd/yyyy', 'attr' => array('type' => 'date', 'class' => 'date_input input-block-level required')))
            ->add('homeTeam', 'entity', array('class' =>'MSPBundle:Team', 'choices' => $this->myTeams))
            ->add('awayTeam', 'entity_hidden', array('data_class' =>'\MSP\MSPBundle\Entity\Team'))
            ->add('points1', null, array('label' => 'Score: ', 'attr' =>array('class' => 'game_point')))
            ->add('points2', null, array('label' => 'To: ', 'attr' =>array('class' => 'game_point')))
            ->add('gameStatValues', 'collection', array('type' => new GameStatValueType(), 'required' => false))
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\Game'
        ));
    }


    public function getName()
    {
        return 'msp_game_stat_form_type';
    }
}