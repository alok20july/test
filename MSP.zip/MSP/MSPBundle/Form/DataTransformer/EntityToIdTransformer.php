<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of IdToTeamTransformer
 *
 * @author hdorfman
 */

namespace MSP\MSPBundle\Form\DataTransformer;

use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;
use Doctrine\Common\Persistence\ObjectManager;

class EntityToIdTransformer implements DataTransformerInterface
{
    /**
     * @var ObjectManager
     */
    private $om;
    private $entityClass;


    /**
     * @param ObjectManager $om
     * @param null $entityClass
     */
    public function __construct(ObjectManager $om, $entityClass = null)
    {
        $this->om = $om;
        $this->entityClass = $entityClass;
    }

    /**
     * Transforms an object an id.
     *
     * @param  Object|null $object
     * @return mixed
     */
    public function transform($object)
    {

        if (null === $object || !is_object($object)) {
            return '';
        }

        return $object->getId();
    }

    /**
     * Transforms a id to an object.
     *
     * @param  mixed $id
     *
     * @return Object|null
     *
     * @throws TransformationFailedException if object is not found.
     */
    public function reverseTransform($id)
    {

        if (!$id) {
            return null;
        }

        $entity = $this->om
            ->getRepository($this->entityClass)
            ->findOneById($id)
        ;

        if (null === $entity) {
            throw new TransformationFailedException(sprintf(
                'An issue with number "%s" does not exist!',
                $id
            ));
        }

        return $entity;
    }

    public function getObjectClass()
    {
        return $this->entityClass;
    }

    public function setObjectClass($class)
    {
        $this->entityClass = $class;
    }
}
