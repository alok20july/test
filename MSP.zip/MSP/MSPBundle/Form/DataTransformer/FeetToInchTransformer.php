<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FeetToInchTransformer
 *
 * @author hdorfman
 */

namespace MSP\MSPBundle\Form\DataTransformer;

use Symfony\Component\Form\DataTransformerInterface;

class FeetToInchTransformer implements DataTransformerInterface
{
    /**
     * Transforms from DB value to form value
     * @param mixed $value
     * @return string
     */
    public function transform($value)
    {  
        if($value){
            $feet = floor($value/12);
            $inch = $value%12;
            if($inch==0)
                return $feet."'";
            else 
                return $feet."'".$inch.'"';
        }else{
            return false;
        }            
    }
 
    /**
     * Reverse transforms form value to db value
     * @param mixed $value
     * @return float
     */
    public function reverseTransform($value)
    {
        $value = str_replace('-', '', $value);
        $data = str_replace('"', '', $value);
        $dataParts = explode("'", $data);
        $result = $dataParts[0]*12+$dataParts[1];
        return $result;
    }
}