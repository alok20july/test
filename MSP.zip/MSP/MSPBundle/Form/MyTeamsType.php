<?php

namespace MSP\MSPBundle\Form;

use MSP\MSPBundle\Entity\Sport;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use MSP\MSPBundle\Admin;
use Symfony\Component\HttpFoundation\Request;
use MSP\MSPBundle\Form\DataTransformer\IdToTeamTransformer;
use Symfony\Component\Security\Core\SecurityContext;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Doctrine\ORM\EntityRepository;

class MyTeamsType extends AbstractType
{
    
    private $teamListener;

    
    public function __construct(\MSP\MSPBundle\Form\EventListener\AddTeamSubscriber $teamListener)
    {
        $this->teamListener = $teamListener;
    }
    
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $entityManager = $options['em'];

        $listener = $this->teamListener;
        $transformer = new IdToTeamTransformer($entityManager);
        $builder->addEventSubscriber($listener);

        $em = $options['em'];
        $qb = $em->createQueryBuilder();
        $qb->select('sp')
            ->from('\MSP\MSPBundle\Entity\SportPosition', 'sp')
            ->orderBy('sp.name', 'ASC');
        $year = (int) date("Y");
        $years = range($year - 10, $year);
        $choicesYears = array_combine($years, $years);

        $builder

            ->add('sport',  null, array(
                'label' => ' ',
                'required' => true,
                'property' => 'name',

            ))
            // ->add('school')
            ->add('school', 'entity', 
                array(
                    'class' => 'MSPBundle:School',
                    'query_builder' => function(EntityRepository $er) {
                        return $er->createQueryBuilder('s')->setMaxResults(100);
                    },
                ))
            ->add('teamClass', 'choice', array('choices' => array('Freshman' => 'Freshman', 'Sophomore' => 'Sophomore', 'Junior' => 'Junior', 'Senior' => 'Senior')))
            ->add('jerseyNumber')
            ->add($builder->create('teamName'))
            ->add($builder->create('team', 'hidden', array('required' => false))
                ->addModelTransformer($transformer))
            ->add('team_input', null, array(
                'required' => false,
                'label' => ' ',
                "mapped" => false,
                'attr' => array('placeholder' => 'Team'), 
            ))

            ->add('level', 'choice', array('choices' => array('Freshman' => 'Freshman', 'Junior Varsity' => 'Junior Varsity', 'Varsity' => 'Varsity')))
            ->add('season', null, array('label' => ' ','required' => true, 'attr' => array('length' => '2')))
            ->add('year', 'choice', array('choices'=> $choicesYears,'label' => ' ', 'required' => true, 'attr' => array('width' => 2)))

            ->add('logo', 'sonata_media_type', array(
                'provider' => 'sonata.media.provider.image',
                'context'  => 'default',
                'required' => false
            ))

            ->add('sportpositions', null, array('query_builder' => $qb, 'required' => false, 'expanded' => false, 'label' => ' ', 'attr' => array('inline' => true)))
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\UserTeamSeason',
            'sportpostions' => function(FormBuilderInterface $form) {
                return array(Sport::getSportpositions());
            }
        ));
        
        $resolver->setRequired(array(
            'em',
        ));

        $resolver->setOptional(array('sport_id'));

        $resolver->setAllowedTypes(array(
            'em' => 'Doctrine\Common\Persistence\ObjectManager'
        ));

    }

    /**
     * Returns the default options/class for this form.
     * @param array $options
     * @return array The default options
     */
    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => 'MSP\MSPBundle\Entity\UserTeamSeason'

        );
    }

    public function getName()
    {
        return 'msp_my_teams';
    }
}