<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Doctrine\ORM\EntityRepository;

class AcademicInfoType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('gpa', null, array('label' => 'Grade Point Average'))
            ->add('satTotalScore', null, array('label' => 'SAT Total Score'))
            ->add('actTotalScore', null, array('label' => 'ACT Total Score'))
            ->add('classRank', null, array('label' => 'Class Rank'))
            ->add('classRankOutOf', null, array('label' => 'Class Size'))
            ->add('inHonorClasses', null, array('label' => 'In Honor Classes'))
            ->add('inAPClasses', null, array('label' => 'In AP Classes'))
            ->add('academicAccomplishments', 'textarea', array('label' => '', 'required' => false))
/*
            ->add('school', 'entity',
                array(
                    'class' => 'MSPBundle:School',
                    'query_builder' => function(EntityRepository $er) {
                        return $er->createQueryBuilder('s')->setMaxResults(100);
                    },
                ))*/
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\User'
        ));
    }

    public function getName()
    {
        return 'msp_mspbundle_academicinfotype';
    }
}
