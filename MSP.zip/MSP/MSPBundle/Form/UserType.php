<?php

namespace MSP\MSPBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class UserType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('username')
            ->add('usernameCanonical')
            ->add('email')
            ->add('emailCanonical')
            ->add('enabled')
            ->add('salt')
            ->add('password')
            ->add('lastLogin')
            ->add('locked')
            ->add('expired')
            ->add('expiresAt')
            ->add('confirmationToken')
            ->add('passwordRequestedAt')
            ->add('roles')
            ->add('credentialsExpired')
            ->add('credentialsExpireAt')
            ->add('firstName')
            ->add('middleName')
            ->add('lastName')
            ->add('nickName')
            ->add('dob')
            ->add('gender')
            ->add('height')
            ->add('weight')
            ->add('bio')
            ->add('image')
            ->add('phone')
            ->add('address')
            ->add('city')
            ->add('stateRegion')
            ->add('country')
            ->add('postalCode')
            ->add('sports')
            ->add('standing')
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'MSP\MSPBundle\Entity\User'
        ));
    }

    public function getName()
    {
        return 'msp_mspbundle_usertype';
    }
}
