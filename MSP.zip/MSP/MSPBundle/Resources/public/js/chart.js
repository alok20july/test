$(document).ready(function(){     

    var line1 = [11, 9, 5, 12, 14];
	plot1b = $.jqplot('chart1',[line1],{
		stackSeries: true,
		showMarker: false,
		seriesDefaults: {
			fill: true
		}
	});
});