/**
 * Created with JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/29/13
 * Time: 3:23 PM
 * To change this template use File | Settings | File Templates.
 */


jQuery(document).ready(function($) {

    showExpand(); // call show expand functionality

    var date_input = $.fn.datepicker.noConflict(); // return $.fn.datepicker to previously assigned value
    $.fn.bootstrapDP = date_input;                 // give $().bootstrapDP the bootstrap-datepicker functionality
    $('select').selectBox();
    // resolve conflict with jquery tooltip
    $.widget.bridge('uitooltip', $.ui.tooltip);
    $('[data-toggle=tooltip]').tooltip();
    
    $('.ajax_delete').click(function(e){
        e.preventDefault();
        var url = $(this).attr('href');
        var container = $(this).attr('rel');

        $.get(url, function(data) {
            $(container).hide('fast');
            $('body').removeClass('hero-unit');
        });
    });

    $('.cheer_link').click(function(e){
        e.preventDefault();
        var url = $(this).attr('href');
        if('#' == url) return false;
        $.ajax({
            context: this,
            type: "post",
            url: url,
            success: function(data) {
                $('#' + $(this).attr('data-target')).html(data);
            }
        });
    });

    $('.comments').on('click', '.thumbs_link', function(e){
        e.preventDefault();
        var url = $(this).attr('href');
        $.ajax({
            context: this,
            type: "post",
            url: url,
            success: function(data) {
                $('#' + $(this).attr('data-target')).html(data);
            }
        });
    });

    $('.hide_show_more').click(function(e){
        var target = $(this).attr('target');
        if ($(target).hasClass('hidden')) {
            $(target).show();
            $(target).removeClass('hidden');
            $(target).addClass('shown');
            $(this).html('Show Less');
        }else{
            $(target).hide();
            $(target).addClass('hidden');
            $(target).removeClass('shown');
            $(this).html('Show More');
        }
    });
  

    $('.date_input').datepicker({ 
        maxDate: new Date()
    });

    $('.birth_date_input').datepicker({ 
        changeYear: true,
        yearRange: '1900:' + (new Date().getFullYear()-6),
        dateFormat : 'mm/dd/yy',
        beforeShow : function(){
            $('select').selectBox();
        }
    });
    

    $('.wall-date').datepicker().datepicker('setDate', 'today');

    $('.wall-media-post-ajax').submit(function(e){
        e.preventDefault();
        var target = $(this).attr('target');
        var completeHandler = function(data){
            alert(data.data.link);
            $('#'+$(this).attr('target')).val(parseInt(data.data.id));
            $('#wallImageHolder').html('<img src="'+data.data.url+'" />');
            $('#wallVideoHolder').html('<video src="http://www.youtube.com/watch?v='+data.data.link+'" />');
            $(this).parent('.modal').hide();
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
        }
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),  //Server script to process data
            type: 'POST',
            xhr: function() {  // Custom XMLHttpRequest
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){ // Check if upload property exists
                    //myXhr.upload.addEventListener('progress',progressHandlingFunction, false); // For handling the progress of the upload
                }
                return myXhr;
            },
            context: this,
            //Ajax events
            success: completeHandler,
            // Form data
            data: formData,
            //Options to tell jQuery not to process data or worry about content-type.
            cache: false,
            contentType: false,
            processData: false
        });
    })

    $('.ajax_update').change(function(e){
        e.preventDefault();
        var target = $(this).attr('target');
        var completeHandler = function(data){
            $('#'+$(this).attr('target')).val(parseInt(data.data.id));
        }
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                }
                return myXhr;
            },
            context: this,
            success: completeHandler,
            data: formData,
            cache: false,
            contentType: false,
            processData: false
        });
    })

    $('.ajax_update_click').click(function(e){
        var target = $(this).attr('target');
        var completeHandler = function(data){
            $('#'+$(this).attr('target')).val(parseInt(data.data.id));
        }
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                }
                return myXhr;
            },
            context: this,
            success: completeHandler,
            data: formData,
            cache: false,
            contentType: false,
            processData: false
        });
    });


    $('.ajax_post').submit(function(e){
        e.preventDefault();
        var target = $(this).attr('target');
        var completeHandler = function(data){
            $('#'+$(this).attr('target')).val(parseInt(data.data.id));
            $(target).show('slow');
        }

        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                }
                return myXhr;
            },
            context: this,
            success: completeHandler,
            data: formData,
            cache: false,
            contentType: false,
            processData: false
        });
    });

    $('#add_team_season').submit(function(e){
        e.preventDefault();
        var completeHandler = function(data){
            $('#teamInfoHistoryContainer').append(data);
        }

        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                }
                return myXhr;
            },
            context: this,
            success: completeHandler,
            data: formData,
            cache: false,
            contentType: false,
            processData: false
        });
    });

    $('.ajax_wall_comment').submit(function(e){
        e.preventDefault();
        //var target = $(this).find('.wall_post_content').find('.comments');
        var completeHandler = function(data){
            var target = $(this).parents('.wall_post_content').children('.comments');
            $(target).append(data);
        }
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                }
                return myXhr;
            },
            context: this,
            success: completeHandler,
            data: formData,
            cache: false,
            contentType: false,
            processData: false
        });
    });


    $('#MyProfileWizard').wizard();

    $('.btnWizardPrev').on('click', function() {
        $('#MyProfileWizard').wizard('previous');
    });

    $('.btnWizardNext').on('click', function() {
        $('#MyProfileWizard').wizard('next','foo');
    });

    $('#generateMSP').click(function () {
        var btn = $(this)
        btn.button('loading')
    });

    // used to simulate clicking on browse for image upload.
    $('#profileImage').click(function(){
        $('#msp_mspbundle_profileinformationtype_image_binaryContent').click();     
    });

    $('#msp_mspbundle_profileinformationtype_image_binaryContent').change(function(e){ 
        /*$('#filelist').html('');       
        // console.log(this.files[0])
        if(!((this.files[0].type)=="image/jpeg" || (this.files[0].type)=="image/png" || (this.files[0].type)=="image/gif")){
            alert('Selected file type not valid');
            return false;
        }
        if(this.files[0].size > 2000000){
            alert('File size sholdn\'t be greated than 2MB');
            return false;
        }*/
        $('#filelist').html($(this).val())
    });

    // used to simulate clicking on browse for image upload.
    $('#brws_files').click(function(){
        $('#msp_wall_type_image_binaryContent').click();
    });

    $('#msp_wall_type_image_binaryContent, #msp_my_teams_logo_binaryContent').change(function(e){
        $('#filelist').html($(this).val())
    });

    // used to simulate clicking on browse for profile image upload.
    $('#uploadProfileImage').click(function(){
        $('#msp_mspbundle_profileimage_image_binaryContent').click();     
    });

    $('#msp_mspbundle_profileimage_image_binaryContent').change(function(){
        $('#profileImage').submit();
    });

    // used to simulate clicking on browse for header image upload.
    $('#uploadHeaderImage').click(function(){
        $('#msp_mspbundle_headerimage_mspHeaderImage_binaryContent').click();     
    });

    $('#msp_mspbundle_headerimage_mspHeaderImage_binaryContent').change(function(){
        $('#headerImage').submit();
    })

    $('.dropdown-toggle').dropdown();

    // $('.popoverDown').popover({'placement': 'bottom'})

    // submit comments when hitting Enter
    $('.wallComment').keypress(function(e){
        if(e.which == 13){
            // submit via ajax or
            $(this).parent('form').submit();
            $(this).hide();
            $(this).val('');
        }
    });

    $('.showCommentForm').click(function(){
        var commentForm = $(this).attr('rel');
        if($(commentForm).is(":visible")){
            $(commentForm).hide();
        }else{
            $(commentForm).show();
        }
    })

    /* Added by Alok Kumar */
    $('.ajax_team_delete').click(function(e){
        e.preventDefault();
        var url = $(this).attr('href');
        var container = $(this).attr('rel');
        //console.log(container)
        $.get(url, function(data) {
            // console.log(data);
            if(data.responseCode == 400){
                $('#'+container).hide('slow', function(){
                    $('#'+container).remove();
                    // console.log(data.message)
                    // console.log($('#userTeamList div.row-fluid').length)
                    if($('#userTeamList div.row-fluid').length == 0){
                        
                        $('#save_team_btn').text('Save');
                        $("#save_team_btn").removeClass("btnlink nextbtn").addClass('btn btn-primary');
                        
                        $('#userTeamListDetails').hide('slow', function(){
                            $('#userTeamListDetails').remove();
                        });                    
                    }
                });                  
            }else{
                // console.log(data.message)
            }            
        });
    });   
    
    /* Show tootltip to upload header image and profile image */
    $('img.showToolTip').tooltip();


    /* Close tab toggle popup */
    var active = $('a[data-toggle="tab"]').parents('.active').length;
    var tabClicked = false;

    // Closes current active tab (toggle and pane):
    var close = function() {
        $('a[data-toggle="tab"]').parent().removeClass('active');
        $('.tab-pane.active').removeClass('active');
        $('#arrowimg').removeClass().addClass('arrowimg');    
        $('#myWallPostContent').hide();
        active = null;
    }

    // Closing active tab when clicking on toggle:
    $('#myWallPost li a[data-toggle=tab]').click(function(){
        var href =  $(this).attr('href').replace("#", "");
        var classes = $('#arrowimg').attr('class');
        $('#arrowimg').removeClass(classes);    
        $('#myWallPostContent').show();            
        $('#arrowimg').addClass('arrowimg tab-'+href);
        if($(this).parent().hasClass('active')){
            $('#myWallPostContent').show();
            $($(this).attr("href")).toggleClass('active');
            active = this;
            tabClicked = false;
        } else {
            tabClicked = true;
            active = this;
        }
    });

    // Do not close tab when selecting images 
    $(document).on('click', '#ui-datepicker-div, .ui-corner-all', function(){
        return false;
    })

    // Closing active tab when clicking outside tab context (toggle and pane):
    $(document).on('click.bs.tab.data-api', function(event) {
        // console.log($(event.target).closest('.tab-content'))
        if(active && !tabClicked && !$(event.target).closest('.tab-content').length) {
            if(!$(event.target).parent().parent().hasClass('selectBox-dropdown-menu') && !$(event.target).parent().parent().hasClass('ui-autocomplete')){
                close();
            }
        }        
        tabClicked = false;
    });

    // Closing active tab on ESC key release:
    $(document).keyup(function(e){
        if(active && e.keyCode === 27) { // ESC
            close();
        }
    });
});


function showExpand(){
    $('.expand_collapse').click(function(e){
        var target = $(this).attr('target');
        if ($(target).hasClass('hidden')){
            $(target).show();
            $(target).removeClass('hidden');
            $(target).addClass('shown');
            $(this).removeClass('expand');
            $(this).addClass('collapse');
        }else{
            $(target).hide();
            $(target).addClass('hidden');
            $(target).removeClass('shown');
            $(this).removeClass('collapse');
            $(this).addClass('expand');
        }
    });
}

/* Added by Alok Kumar */

// open registration form in model box
$('#btn-register, #btn-register-bottom').click(function(e) {
    e.preventDefault();
    $.get($(this).attr('href'), function(data) {
        if($("#register-model").length > 0) {
            $("#register-model").html(data).modal('show');
        }else{
            $('<div class="modal hide fade" id="register-model">'+data+'</div>').modal('show');
        }   
        var body = $("html, body");
        body.animate({scrollTop:0}, '5000', 'swing');     
    }).complete(function() {
        $("body").popover({
            selector: '.previewimage' ,
            html: true,
            trigger: 'hover',
            placement: 'right',
            content: function(){
                return '<img src="'+$(this).data('img')+'" height="'+$(this).data('height')+'" width="'+$(this).data('width')+'" style="max-width:none;"/>';                
            }
        });
    });
});

// sumbit registration form
$('body').on('click', '#_submitForm', function(e){
    e.preventDefault();
    submitRegistrationForm(); // function to sumbit registratior form
});

// function to sumbit registratior form
function submitRegistrationForm(){
    $.ajax({
        type        : 'POST',
        url         : $('#registrationForm').attr('data-target'),
        data        : $('#registrationForm').serialize(),
        async       : false,
        beforeSend  : function(){
            $('#_submitForm').attr({'value':'Loading...', 'disabled':'disabled'});
        } ,
        success     : function(data, status) {
            var parts = data.split('###');
            if('success' == parts[0]) {
                window.location = parts[1];
            }else{
                $('#register-model').html('');
                $('#register-model').html(data);
            }            
        },
        error: function(data, status){
            // console.log(data.message);
        }
    });
}

// function to sumbit login form
$('body').on('keydown', '#registrationForm input', function(event) {
    if (event.keyCode == 13) {
        submitRegistrationForm();
    }
});

// open login popover form
$('#login_link').bind('click', function(obj){
    var obj = $(this);
    // obj.unbind('click');
    var url = obj.attr('data-poload');
    $.get(url, function(data) {
        obj.popover({
            content: data,
            html: true,
            template: '<div class="popover"><div class="arrow"></div><div class="popover-inner"><h3 class="popover-title"></h3><div class="popover-content"><p></p></div></div></div>'
        }).popover('show');
        $('.popover-title').append('<span id="close">close</span>');
    }); 
});

// close login popover form
$('#userNav').on('click', '#close', function(e){
    $('#login_link').popover('destroy');
});

// submit login form
$('body').on('click', '#_submit', function(e){
    e.preventDefault();
    submitLoginForm(); // call function to sumbit login form
});

// function to sumbit login form
function submitLoginForm(){
    $.ajax({
        type        : 'POST',
        url         : $('#loginForm').attr('data-target'),
        data        : $('#loginForm').serialize(),
        async       : false,
        beforeSend  : function(){
            $('#_submit').attr({'value':'Loading...', 'disabled':'disabled'});
        } ,
        success     : function(data, status) {
            var result = data.substring(0, 8);
            if('<!DOCTYP' == result) {
                window.location.reload(true);
            }else{
                $('.popover-content').html('');
                $('.popover-content').html(data);
            }            
        },
        error: function(data, status){
            // console.log(data.message);
        }
    });
}

// function to sumbit login form
$('body').on('keydown', '#loginForm input', function(event) {
    if (event.keyCode == 13) {
        submitLoginForm();
    }
});


$('#search_field').focus(function(){
    $('#search_field').css('text-align', 'left');
    $(this).attr('placeholder','');
});

$('#search_field').blur(function(){
    $('#search_field').css('text-align', 'right');
    $(this).attr('placeholder','Find Athletes');
});

window.onload=function(){
    $('.age-group a').css({'width':''});
    $('#btn-register').attr({'href':$('#btn-register').attr('data-href')});
    $('#btn-register-bottom').attr({'href':$('#btn-register').attr('data-href')});
}

$('#userBiography li').click(function(){        
    $('#biography').show();            
    $('#arrowimg').show();
});

$('#biography #close').on('click', function(){
    $('#biography').hide();
    $('#arrowimg').hide();
});

function create( template, vars, opts ){
    return $flashMessageContainer.notify("create", template, vars, opts);
}

$('.CreateConnection').on('click',function(){
    $flashMessageContainer = $("#flashMessageContainer").notify();
    var obj = $(this);    
    var data_target = obj.attr('data-target');
    if('#' == data_target){
        $('#login_link').trigger('click');        
        create("flashMessageStatus", { title:'', text:'Please logged-in to create connection'});
    }else{
        var completeHandler = function(data){
            // console.log(data);
            create("flashMessageStatus", { title:'', text:data.message});
        }
        $.ajax({
            url: data_target,
            type: 'POST',
            success: completeHandler
        });
    }
    var body = $("html, body");
    body.animate({scrollTop:0}, '5000', 'swing');        
})