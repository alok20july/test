// display popover 
$('[data-toggle="popover"]').on('click', function(e){

	$('[data-toggle="popover"]').each(function () {
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('destroy');
            // location.reload();
        }
    });
    
	var obj = $(this);
	// obj.unbind('click');
	var url = obj.attr('data-poload');
	$.get(url, function(data) {
	    obj.popover({
	        content: data,
	        html: true,
	        template: '<div class="popover session-popover-open"><div class="arrow"></div><div class="popover-inner"><h3 class="popover-title"></h3><div class="popover-content"><p></p></div></div></div>'
	    }).popover('show');
	    if(obj.hasClass('add-session')){
		    $('select').selectBox();
		    $('.session-popover-open').css({'left':'0px'});	  
		    $('.popover.bottom .arrow').css({'left':'62px'});	  
		    $('.selectBox-dropdown').css({'min-width':'50%', 'width': '130px'});  
		    $('.date_input').datepicker({  maxDate: new Date() });
	    }
	    $('.popover-title').append('<span id="close">close</span>');	    
	}); 
});

$('#myTraining').on('click', '#close', function(e){
    $('.add-session').popover('destroy');
})	

$('.delete-session').on('click', function(e){
	e.preventDefault();
	// alert($(this).attr('href'));
	if(confirm('Are you sure, you want to delete this session?')){
		$.ajax({
	        type        : 'POST',
	        url         : $(this).attr('href'),        
	        async       : false,        
	        success     : function(data, status) {
	        	window.location.reload();
	        },
	        error: function(data, status){
	           	console.log(data)
	        	console.log(status)
	        }
	    });
	}
})

$('#measurableList').on('click', '.update-status', function(){
	var obj = $(this);
	$.ajax({
        type        : 'POST',
        url         : $('#measurableUrl').val(),
        data        : { 'measurable_id' : $(this).attr('data-id'), 'value' : $(this).attr('data-value')},
        async       : false,        
        success     : function(data, status) {
        	// alert(data.value)
        	$(obj).attr('data-value', data.value)
        	if(data.value == 1){
        		$(obj).removeClass('normal').addClass('selected');
        	}else{
        		$(obj).removeClass('selected').addClass('normal');        	
        	}
        },
        error: function(data, status){
           // $(obj).attr('data-id', data.value)         
        }
    });
});

$('#measurableList').on('click', '#close', function(){
	$('.add-chart').popover('destroy');
	window.location.reload();
});