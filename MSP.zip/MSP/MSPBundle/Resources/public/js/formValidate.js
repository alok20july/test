$(document).ready(function(){
    $('#parsley-validate-form .btn').on('click', function () {
        $('#parsley-validate-form').parsley().validate();
        if(!validateFront()){
            return false;
        }
    });

    var validateFront = function () {
        if (true === $('#parsley-validate-form').parsley().isValid()) {
            $('.bs-callout-info').removeClass('hidden');
            $('.bs-callout-warning').addClass('hidden');
            return true;
        } else {
            $('.bs-callout-info').addClass('hidden');
            $('.bs-callout-warning').removeClass('hidden');
            return false;
        }
    };
})

function team_validate(){
    if($('#msp_wall_type_game_awayTeam').val()){
        return true;
    }else{
        if($('#msp_wall_type_game_awayTeamName').val()){
            $('#msp_wall_type_game_awayTeamName').css({'border':'1px solid red'});
            var body = $("html, body");
            body.animate({scrollTop:150}, '5000', 'swing');
            $('#msp_wall_type_game_awayTeamName ~ ul').remove();
            $('#msp_wall_type_game_awayTeamName').after('<ul class="parsley-error-list"><li class="required" style="display: list-item;">Team does not exist, Please click Add Team to add the team.</li></ul>')
            return false;
        }
    }
}

function school_validate(){
    if($('#msp_my_teams_school').val()){
        return true;
    }else{
        if($('#msp_my_teams_school_name').val()){
            $('#msp_my_teams_school_name').css({'border':'1px solid red'});
            var body = $("html, body");
            body.animate({scrollTop:150}, '5000', 'swing');
            $('#msp_my_teams_school_name ~ ul').remove();
            $('#msp_my_teams_school_name').after('<ul class="parsley-error-list"><li class="required" style="display: list-item;">School does not exist</li></ul>')
            return false;
        }
    }
}