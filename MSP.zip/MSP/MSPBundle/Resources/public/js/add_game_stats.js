/**
 * Created with JetBrains PhpStorm.
 * User: soumaouche
 * Date: 2/10/14
 * Time: 12:16 PM
 * To change this template use File | Settings | File Templates.
 */



jQuery(document).ready(function() {

    var wallAddTeamFunction = function(e){

        e.preventDefault();
        popover = e.data;

        var completeHandler = function(data, textStatus, oHTTP){
            // add team to my teams drop down.
            // close popover
            // diapearing message saying that team has been added.

            // data = JSON.parse(data);
            if(data.error){
                $(this).find('#errorContainer').html("<p class='alert alert-danger'>" + data.msg +" </p>");
            }else{
                var o = new Option(data.data.team_name, data.data.team_id);
                // jquerify the DOM object 'o' so we can use the html method
                $(o).html(data.data.team_name);
                $(o).attr({selected: 'selected'});
                $(o).attr({'data-id': data.data.sport_id});
                $("#msp_wall_type_game_homeTeam").append(o);
                $('select').selectBox('refresh');
                $('#msp_wall_type_game_homeTeam').trigger('change');              
                window.popover.popover('destroy');
            }
        };

        var errorHandler = function(xhr, ajaxOptions, thrownError){
            $(this).find('#errorContainer').html("<p class='alert alert-danger'>An error occured, please try again later. </p>");
        };

        var formData = $(this).serialize();
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                }
                return myXhr;
            },
            context: this,
            success: completeHandler,
            error: errorHandler,
            data: formData
        })
    };


    var wallAddTheirTeamFunction = function(e){

        e.preventDefault();
        popover = e.data;

        var completeHandler = function(data, textStatus, oHTTP){
            // add team to my teams drop down.
            // close popover
            // diapearing message saying that team has been added.

            // data = JSON.parse(data);
            if(data.error){
                $(this).find('#errorContainer').html("<p class='alert alert-danger'>" + data.msg +" </p>");
            }else{
                $("#msp_wall_type_game_awayTeam").val(data.data.team_id);
                $("#msp_wall_type_game_awayTeamName").val(data.data.team_name);             
                window.popover.popover('destroy');
            }
        };

        var errorHandler = function(xhr, ajaxOptions, thrownError){
            $(this).find('#errorContainer').html("<p class='alert alert-danger'>An error occured, please try again later. </p>");
        };

        var formData = $(this).serialize();
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                }
                return myXhr;
            },
            context: this,
            success: completeHandler,
            error: errorHandler,
            data: formData
        })
    };

    $('[data-toggle="popover"]').bind('click',function() {
        $('[data-toggle="popover"]').each(function (e) {
            if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
                $(this).popover('destroy');
            }
        });

        var e = $(this);
        var attr_id = e.attr('id');
        // e.unbind('click');
        $.get(e.data('poload'),function(d) {
            popover = e.popover({
                content: d,
                html: true,
                template: '<div class="popover add_team_popover"><div class="arrow"></div><div class="popover-inner"><h3 class="popover-title"></h3><div class="popover-content"><p></p></div></div></div>'
            }).popover('show');
            $('select').selectBox();
            $('.popover-title').append('<span id="close">close</span>');
            $('#wallAddTeamSeason').submit(popover, wallAddTeamFunction);
            $('#wallAddTheirTeam').submit(popover, wallAddTheirTeamFunction);
            if(attr_id == 'addTheirTeam'){
                var sport_id = $('#msp_wall_type_game_homeTeam').find(':selected').attr('data-id');
                $("#msp_their_team_sport").val(sport_id);
                $('#away-team-sport-id').val(sport_id);
                $("#msp_their_team_sport").selectBox('disable');  
                $("#msp_their_team_sport").selectBox('refresh');                      
            }

            // initialize sport on change function by sports and get postion of specific sports
            wallListPositionBySport();
        });
    });

    $('#game').on('click', '#close', function(e){
        window.popover.popover('destroy');
    })
});

// function to get sport position by sport
function wallListPositionBySport(){
    var tmp = $('#renderSportPositionsUrl').attr('value');
    var sportPositionsUrl = tmp.substring(0, tmp.length-1);
    $('#msp_team_season_type_sport').on('change', function() {
        var ajaxUrl = sportPositionsUrl + this.value;
        $.ajax({
            url: ajaxUrl,
            success: function(data){
                $('#msp_team_season_type_sportpositions').html(data);
                $('#msp_team_season_type_sportpositions').selectBox('refresh');
            }
        });
    });
}
