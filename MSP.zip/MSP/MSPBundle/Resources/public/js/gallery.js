var container, msnry, container2, msnry2;
window.onload = function(){

    container = document.querySelector('#gallerycontainer');
    msnry = new Masonry( container, {
        // options
        columnWidth: container.querySelector('.galleryitem'),
        itemSelector: '.galleryitem'
    });

    container2 = document.querySelector('#mspgallerycontainer');
    msnry2 = new Masonry( container2, {
        // options
        itemSelector: '.galleryitem'
    });
    // jQuery UI Draggable
    $("#gallerycontainer div.galleryitem").draggable({
        revert:true,
        drag:function () {
            $(this).addClass("active");
            $(this).closest("#mainGallery").addClass("active");
        },
        stop:function () {
            $(this).removeClass("active").closest("#mainGallery").removeClass("active");
        }
    });

    $(".msp_gallery").colorbox({ rel:'mspGallery', maxWidth:"75%", loop:false, speed:500 });
    $(".msp_galleryvideo").colorbox({ rel:'mspGallery', iframe:true, innerWidth:640, innerHeight:390});
    $(".main_gallery").colorbox({ rel:'mainGallery', maxWidth:"75%", loop:false, speed:500 });
    $(".main_galleryvideo").colorbox({ rel:'mainGallery', iframe:true, innerWidth:640, innerHeight:390});

    // used to simulate clicking on browse for image upload.
    $('#gallery_photo').click(function(){
        $('#msp_media_type_image_binaryContent').click();
    });

    $('#msp_media_type_image_binaryContent').change(function(e){
        $('#filelist').html($(this).val())
    });

    // jQuery UI Droppable
    $("#mspGallery").droppable({
        activeClass:"active",
        hoverClass:"hover",
        tolerance:"touch",
        drop:function (event, ui) {
            var obj = $(this),
            move    = ui.draggable,
            media   = obj.find(".galleryitem div.delete[data-id='"+move.find('div.delete').attr("data-id")+"']");
            media_id = move.find('div.delete').attr("data-id");
            if (media.html() != null) {
                // alert('its already exist in gallery');
                return false;
            }
            else{
                $(obj).find(".gallery #mspgallerycontainer").append('<div class="galleryitem">'+move.html()+'</div>');   
                $(obj).find(".gallery #mspgallerycontainer .galleryitem").hover(
                    function() {
                        $(this).find('div.delete span').show();
                    }, function() {
                        $(this).find('div.delete span').hide();
                    }
                );
                $(obj).find(".gallery #mspgallerycontainer .galleryitem a.main_gallery").addClass('msp_gallery');                
                $(obj).find(".gallery #mspgallerycontainer .galleryitem a").removeClass('main_gallery');                
                $(obj).find(".gallery #mspgallerycontainer .galleryitem a").attr('rel', 'mspGallery');
                $(obj).find(".gallery #mspgallerycontainer .galleryitem div.delete span").attr({'data-type':'mspgallery'});

                $(obj).find(".gallery #mspgallerycontainer .galleryitem div.delete a.main_galleryvideo").addClass('msp_galleryvideo');
                $(obj).find(".gallery #mspgallerycontainer .galleryitem div.delete a").removeClass('main_galleryvideo');

                var url = $('#ajax-url').attr('data-href');
                
                $.post(url, { media_id: media_id }, 
                    function(data){
                        msnry2.reloadItems();
                        msnry2.layout();
                        console.log(data.message);
                    }, "json" 
                );
            }        
        } 
    });

    // show delete button on mouse over and hide on mouse leave 
    $('.galleryitem').on('mouseover', function(){
        $(this).find('div.delete span').show();
    }).on('mouseout', function() {
        $(this).find('div.delete span').hide();
    });

    $('#mainGallery .photo-gallary object embed, #mspGallery .gallery object embed').each(function(){
        $(this).attr({'width':280});
    });
}

// function to delete gallery
function deleteGallery(media_id, obj){
    var url = obj.getAttribute('data-href');    
    var media_type = obj.getAttribute('data-type');
    $.post(url, { media_id: media_id, media_type : media_type }, 
        function(data){
            if(data.responseCode==400 ){    
                // console.log($(obj).parent().parent());
                $(obj).parents('.galleryitem').remove();
                msnry.reloadItems();
                msnry.layout();
                msnry2.reloadItems();
                msnry2.layout();
                if('mygallery' == media_type){
                    $('#mspGallery .gallery div p').each(function(){
                        if($(this).attr('data-id') == media_id)
                            $(this).parents('.galleryitem').remove();
                    })
                }
            }else{
                // code for error
                console.log(data.message);
            }
        }, "json" 
    );
}