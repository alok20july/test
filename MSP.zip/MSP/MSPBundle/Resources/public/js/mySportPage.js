window.onload = function() {
    var container, msnry;
    container = document.querySelector('#mspgallerycontainer');
    new Masonry( container, {
        itemSelector: '.galleryitem'
    });
    $(".msp_gallery").colorbox({ rel:'mspGallery', maxWidth:"75%", loop:false, speed:500 });
    $(".msp_galleryvideo").colorbox({ rel:'mspGallery', iframe:true, innerWidth:640, innerHeight:390 });
    $('#mspGallery .gallery object embed').each(function(){
        $(this).attr({'width':280});
    });
}
