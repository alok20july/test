/*
This is used to update personal stats choices when user selects a team or adds a team in the wall game stat posting.
 */

jQuery(document).ready(function() {
    var select_team = "#msp_wall_type_game_homeTeam";

    var updateStatsSuccessHandler = function(data){
        $("#gamePersonalStatsContainer").html(data);
        $('[data-toggle=tooltip]').tooltip();
        showExpand();
    };

    var errorHandler = function(data){

    };

    var updateStatsFunction = function() {
        var team = $(this).val();
        var get_team_stat_fields_action = $('#getTeamStatFieldsAction').val();

        // get the stats.
        $.ajax({
            url: get_team_stat_fields_action,
            type: 'POST',
            xhr: function() {
                var myXhr = $.ajaxSettings.xhr();
                if(myXhr.upload){
                }
                return myXhr;
            },
            context: this,
            success: updateStatsSuccessHandler,
            error: errorHandler,
            data: {team_id : team}
        });
    };

    $(select_team).change(updateStatsFunction);

    // display popover for add session value
    $('#test_training').bind('click', function(e){
        var obj = $(this);
        // obj.unbind('click');
        var url = obj.attr('data-poload');
        $.get(url, function(data) {
             $('#training').html('<div class="arrowimg tabtrg"></div>'+data);
             $('.date_input').datepicker({  maxDate: new Date() });
             $('select').selectBox();
        }); 
    });
});