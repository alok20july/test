// display popover for edit season stat and gamestat
$('[data-toggle="popover"]').bind('click', function(e){

	// hide popover 
    $('[data-toggle="popover"]').each(function () {
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('destroy');
            // location.reload();
        }
    });

	var obj = $(this);
	// obj.unbind('click');
	var url = obj.attr('data-poload');
	$.get(url, function(data) {
	    popover = obj.popover({
	        content: data,
	        html: true,
	        template: '<div class="popover stat-popover-open"><div class="arrow"></div><div class="popover-inner"><h3 class="popover-title"></h3><div class="popover-content"><p></p></div></div></div>'
	    }).popover('show');	

	    if(obj.attr('data-value') == 'game'){
	    	$('.popover').addClass('game-stat-add');	    	
	    	$('form').parsley();
	    	validateDate();	    	
	    	showAutocomplete();
	    }else if(obj.attr('data-value') == 'addgame'){            
            // initialize sport on change function by sports and get postion of specific sports
            statListPositionBySport();
            $('#statisticsAddTeam').submit(popover, statisticsAddTeam);
        }
        else if(obj.attr('data-value') == 'addTheirTeam'){
            $('#wallAddTheirTeam').submit(popover, wallAddTheirTeamFunction);
            var sport_id = $('#msp_season_game_homeTeam').find(':selected').attr('data-id');
            $("#msp_their_team_sport").val(sport_id);
            $('#away-team-sport-id').val(sport_id);
            $("#msp_their_team_sport").selectBox('disable');  
            $("#msp_their_team_sport").selectBox('refresh');                      
        }
        else{
	    	$('.popover').removeClass('game-stat-add');
	    }
        $('select').selectBox();
        $('.game_add_form_container .blueText').html(obj.attr('data-title'));
        $('.popover-title').append('<span id="close">close</span>');
        $('[data-toggle=tooltip]').tooltip();
	}); 
});

// function to get soprt position by sport
function statListPositionBySport(){
    var tmp = $('#renderSportPositionsUrl').attr('value');
    var sportPositionsUrl = tmp.substring(0, tmp.length-1);
    $('#msp_staistics_team_season_type_sport').on('change', function() {
        var ajaxUrl = sportPositionsUrl + this.value;
        $.ajax({
            url: ajaxUrl,
            success: function(data){
                $('#msp_staistics_team_season_type_sportpositions').html(data);
                $('#msp_staistics_team_season_type_sportpositions').selectBox('refresh');
            }
        });
    });
}

// submit add team data using ajax
var statisticsAddTeam = function(e){
    e.preventDefault();
    popover = e.data;
    var completeHandler = function(data, textStatus, oHTTP){
        if(data.error){
            $(this).find('#errorContainer').html("<p class='alert alert-danger'>" + data.msg +" </p>");
        }else{        
            window.popover.popover('destroy');
            window.location.reload();
        }
    };

    var errorHandler = function(xhr, ajaxOptions, thrownError){
        $(this).find('#errorContainer').html("<p class='alert alert-danger'>An error occured, please try again later. </p>");
    };

    var formData = $(this).serialize();
    $.ajax({
        url: $(this).attr('action'),
        type: 'POST',
        xhr: function() {
            var myXhr = $.ajaxSettings.xhr();
            if(myXhr.upload){
            }
            return myXhr;
        },
        context: this,
        success: completeHandler,
        error: errorHandler,
        data: formData
    })
};

$('.seasonStatGroup').on('click', '#myclose', function(e){
    $('.addTheirTeam').popover('destroy');
});

$('#myWallPost').on('click', '#close', function(e){
    $('.add-team').popover('destroy');
});

$('.seasonStatGroup').on('click', '#close', function(e){
    $('.seasonStatEdit').popover('destroy');
    window.location.reload();
});

$('.seasonStatSection').on('click', '#close', function(e){
	$('.seasonStatEdit').popover('destroy');
});

$('.gameHeader').on('click', '#close', function(e){
    $('.gameStatEdit').popover('destroy');
    window.location.reload();
});

/* delete season/game averages popup */
$('.seasonAverages').on('click', '#close', function(){
	$('.seasonGameAverage').popover('destroy');
});

// when click on label value, its shows in textbox and hide shows value
$('.seasonStatGroup, .gameStatGroup, .seasonAverages').on('click', '.displayStatValue label.statLabel', function(e){
	$(this).children('.statValue').hide();
	$(this).siblings('.msp_type_value').show();
	$(this).siblings('.msp_type_value').focus();
});

// insert/update user SeasonStat/GroupStat value using ajax
$('.seasonStatGroup, .gameStatGroup').on('blur', '.displayStatValue .msp_type_value', function(e){
	var obj = $(this);
	var season_stat_value 	= $(this).val();
	var url = $(this).parent().attr('data-href');
	if($.trim($(this).siblings('.statLabel').children('.statValue').html()) != $.trim($(this).val())){
		$.post(url, $(this).parent().serialize(), 
			function(data) {
				$(obj).siblings('.statLabel').children('.statValue').html(season_stat_value);
			}
		)	
	}		
	$(this).hide();	
	$(this).siblings('.statLabel').children('.statValue').show();
});

function validateDate(){
    var currentDate = new Date();
	$('.date_input').datepicker({  
		maxDate: new Date(),
		beforeShowDay : function(dates){
			// console.log(dates.getFullYear() + '' + $('#seasonYear').val())
			if(dates.getFullYear() != $('#seasonYear').val()){
				return false;
			}else{
				return [true, ''];
			}
		}
	}).datepicker("setDate", new Date($('#seasonYear').val(), currentDate.getMonth(), currentDate.getDate()));
	$('select').selectBox();
	var team_id = $('#teamId').val();
    $("#msp_season_game_homeTeam").val(team_id);
    $('#msp_wall_type_game_homeTeam').val(team_id);
    $("#msp_season_game_homeTeam").selectBox('disable');  
    $("#msp_season_game_homeTeam").selectBox('refresh');              
}

// close chart showing popup 
$('.open-chart-popup , .open-chart-popup-top').on('click', '#close', function(){
	$('.show-popup').popover('destroy');
	window.location.reload();
});

// open chart popup for games to select/deselect chart
$('.open-chart-popup').on('click', '.update-status', function(){
	var obj = $(this);
	$.ajax({
        type        : 'POST',
        url         : $('#seasonGameStatUrl').val(),
        data        : { 'season_game_id' : $(this).attr('data-id'), 'value' : $(this).attr('data-value')},
        async       : false,        
        success     : function(data, status) {
        	// alert(data.value)
        	$(obj).attr('data-value', data.value)
        	if(data.value == 1){
        		$(obj).removeClass('normal').addClass('selected');
        	}else{
        		$(obj).removeClass('selected').addClass('normal');        	
        	}
        },
        error: function(data, status){
           // $(obj).attr('data-id', data.value)         
        }
    });
});

// open chart popup for all seasons to select/deselect chart
$('.open-chart-popup-top').on('click', '.update-status', function(){
	var obj = $(this);
	$.ajax({
        type        : 'POST',
        url         : $('#seasonStatUrl').val(),
        data        : { 'season_id' : $(this).attr('data-id'), 'value' : $(this).attr('data-value')},
        async       : false,        
        success     : function(data, status) {
        	// alert(data.value)
        	$(obj).attr('data-value', data.value)
        	if(data.value == 1){
        		$(obj).removeClass('normal').addClass('selected');
        	}else{
        		$(obj).removeClass('selected').addClass('normal');        	
        	}
        },
        error: function(data, status){
           // $(obj).attr('data-id', data.value)         
        }
    });
});


// Add their team popup to add team if not exist
$('.statSection').on('click', '.addTheirTeam', function(e){
    var e = $(this);
    // e.unbind('click');
    $.get(e.data('poload'),function(d) {
        popover = e.popover({
            content: d,
            html: true,
            template: '<div class="popover add_team_popover"><div class="popover-inner"><h3 class="popover-title my-title"></h3><div class="popover-content"><p></p></div></div></div>'
        }).popover('show');
        $('select').selectBox();
        $('.my-title').append('<span id="myclose">close</span>');
        $('#wallAddTheirTeam').submit(popover, statAddTheirTeamFunction);
        var sport_id = $('#msp_season_game_homeTeam').find(':selected').attr('data-id');
        $("#msp_their_team_sport").val(sport_id);
        $('#away-team-sport-id').val(sport_id);
        $("#msp_their_team_sport").selectBox('disable');  
        $("#msp_their_team_sport").selectBox('refresh');                      
    });
});


// submit the their team value
var statAddTheirTeamFunction = function(e){

    e.preventDefault();
    popover = e.data;
    var completeHandler = function(data, textStatus, oHTTP){
        // data = JSON.parse(data);
        if(data.error){
            $(this).find('#errorContainer').html("<p class='alert alert-danger'>" + data.msg +" </p>");
        }else{
            $("#msp_wall_type_game_awayTeam").val(data.data.team_id);
            $("#msp_wall_type_game_awayTeamName").val(data.data.team_name);             
            window.popover.popover('destroy');
        }
    };

    var errorHandler = function(xhr, ajaxOptions, thrownError){
        $(this).find('#errorContainer').html("<p class='alert alert-danger'>An error occured, please try again later. </p>");
    };

    var formData = $(this).serialize();
    $.ajax({
        url: $(this).attr('action'),
        type: 'POST',
        xhr: function() {
            var myXhr = $.ajaxSettings.xhr();
            if(myXhr.upload){
            }
            return myXhr;
        },
        context: this,
        success: completeHandler,
        error: errorHandler,
        data: formData
    })
};