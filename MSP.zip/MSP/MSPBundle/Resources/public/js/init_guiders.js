jQuery(document).ready(function($) {
    guiders.createGuider({
        buttons: [{name: "Close", classString: "primary-button"}],
        description: "My Sports Page is a Do-It-Yourself recruiting tool designed to help you maximize your chances and help you realize your full potential, let's get started by setting up your profile information",
        id: "finally",
        overlay: true,
        title: "Welcome to MySportPage!"
    }).show();
});