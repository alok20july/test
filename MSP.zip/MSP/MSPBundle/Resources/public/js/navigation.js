jQuery( document ).ready( function( $ ) {
	var $menu = $('#menu'),
		$menulink = $('.menu-link'),
		$menuTrigger = $('.has-submenu > a');

	$menulink.click(function(e) {
		e.preventDefault();
		e.stopPropagation();
		$menulink.toggleClass('active');
		$menu.toggleClass('active');
	});

	$('body').click(function() {
    	$menulink.removeClass('active');
		$menu.removeClass('active');
	});

	$menuTrigger.click(function(e) {
		e.stopPropagation();
		e.preventDefault();
		$(this).toggleClass('active').next('ul').toggleClass('active');
	});

	$('#bookmark-profile a').on('click', function(e){
		
	    var bookmarkUrl = this.href;
	    var bookmarkTitle = this.title;

	    if (navigator.userAgent.search("MSIE") >= 0) {
	    	e.preventDefault();
            window.external.AddFavorite(url, title);
        }
        //Check if browser is Chrome or not
        else if (navigator.userAgent.search("Chrome") >= 0) {
        	e.preventDefault();
            alert('Unfortunately, this browser does not support the requested action, please bookmark this page manually using CTRL+D.');
        }
        //Check if browser is Safari or not
        else if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
        	e.preventDefault();
            alert('Unfortunately, this browser does not support the requested action, please bookmark this page manually using CTRL+D.');
        }
	})
});
