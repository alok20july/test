# 1.2.x versions

  - fix bugs
  - continuous improvement

# 2.x version

  - use AMD structure, more decoupled
  - use guillaumepotier/validator.js for validators

