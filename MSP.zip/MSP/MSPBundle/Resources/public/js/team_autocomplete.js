/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function showAutocomplete(){
    $(".team_autocomplete").autocomplete({
        minLength: 3,
        source: function (request, response) {
            $.ajax({
                url: $("#getTeams").val(),
                data: { term: request.term , team_id: $('#msp_wall_type_game_homeTeam').val() },
                dataType: "json",
                type: "POST",
                success: function (data) {                    
                    $('#msp_wall_type_game_awayTeam').val('');
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return {
                                label: item.label,
                                val: item.value
                            };
                        }))
                    } else {
                        response([{ label: 'No results found.', val: -1}]);
                    }
                }
            });
        },
        select: function(event, ui) {
            if (ui.item.val == -1) {
                return false;
            }
            $('#msp_wall_type_game_awayTeamName').css({'border':'1px solid #cccccc'});
            $('#msp_wall_type_game_awayTeamName ~ ul').remove();
            $('#'+$(this).attr('target')).val(ui.item.val);
            $(this).val(ui.item.label);
            return false;
        },
        search: function(){
            $('.parsley-error-list').remove();
            $(this).addClass('loading');
        },
        open: function(){
            $(this).removeClass('loading');
        }
    });
}
jQuery(document).ready(function($) {
    showAutocomplete();
    
    $(".school_autocomplete").autocomplete({
        minLength: 3,
        source: function (request, response) {
            var state = 0;
            if($('#state').val() && $('#state').val() != 0){
                state = $('#state').val();  
            }
            // console.log(state);
            $.ajax({
                url: $("#getSchoolListUrl").val(),
                data: { term: request.term , state : state },
                dataType: "json",
                type: "POST",
                success: function (data) {                    
                    $('#msp_my_teams_school').val('');
                    // console.log(data.length);
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return {
                                label: item.label,
                                val: item.value
                            };
                        }))
                    } else {
                        response([{ label: 'No results found.', val: -1}]);
                    }
                }
            });
        },
        select: function(event, ui) {
            if (ui.item.val == -1) {
                return false;
            }
            $('#msp_my_teams_school_name').css({'border':'1px solid #cccccc'});
            $('#msp_my_teams_school_name ~ ul').remove();
            $('#msp_my_teams_school').val(ui.item.val);
            $(this).val(ui.item.label);
            // var defaultTeamName = $("#msp_my_teams_school_name").val() + ' ' + $("#msp_my_teams_sport option:selected").html() + ' Team';
            var defaultTeamName = $("#msp_my_teams_school_name").val().substr(0, $("#msp_my_teams_school_name").val().indexOf(',')) + ' ' + $("#msp_my_teams_sport option:selected").html();
            $('#msp_my_teams_teamName').val(defaultTeamName);
            return false;
        },
        search: function(){
            $(this).addClass('loading');
        },
        open: function(){
            $(this).removeClass('loading');
        }
    });
    
    $('#basicSearch .adv_search').on('click', function(){
        $('#advanceSearch').show();
    })
    $('#state').on('change', function(){
        $('#msp_my_teams_school_name').val('');
        $('#msp_my_teams_school').val('');
    })

    $('#searchSport').on('change', function() {
        var ajaxUrl = $('#renderSportPositionsUrl').val();
        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {sport_id : $(this).val() },
            success: function(data){
                $('#searchSportPosition').html(data);
                $('#searchSportPosition').selectBox('refresh');
            }
        });
    });

    $('#sorting').change(function(){
        // alert($('#search_type').val());
        if($('#search_type').val() == 'advanced_search'){
            $('#advanced_sort_by').val($('#sorting').val());
            $('#AdvancedForm').submit();
        }   
        else{
            // alert(1)
            $('#simple_sort_by').val($('#sorting').val());
            $('#SimpleForm').submit();
        }
    });
});