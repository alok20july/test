/**
 * Created with JetBrains PhpStorm.
 * User: soumaouche
 * Date: 4/10/14
 * Time: 4:49 PM
 * To change this template use File | Settings | File Templates.
 */
/*
function ValidateFileUpload() {
    var fuData = document.getElementById('fileChooser');
    var FileUploadPath = fuData.value;

//To check if user upload any file
    if (FileUploadPath == '') {
    alert("Please upload an image");

    } else {
    var Extension = FileUploadPath.substring(
    FileUploadPath.lastIndexOf('.') + 1).toLowerCase();

//The file uploaded is an image

    if (Extension == "gif" || Extension == "png" || Extension == "bmp"
    || Extension == "jpeg" || Extension == "jpg") {

// To Display
    if (fuData.files && fuData.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
    $('#blah').attr('src', e.target.result);
    }

reader.readAsDataURL(fuData.files[0]);
}

}

//The file upload is NOT an image
else {
    alert("Photo only allows file types of GIF, PNG, JPG, JPEG and BMP. ");

    }
}
}*/

$(document).ready(function(){
    var tmp = $('#renderSportPositionsUrl').attr('value');
    var sportPositionsUrl = tmp.substring(0, tmp.length-1);

    $('#msp_my_teams_sport').on('change', function() {
        var ajaxUrl = sportPositionsUrl + this.value;
        $.ajax({
            url: ajaxUrl,
            success: function(data){
                $('#msp_my_teams_sportpositions').html(data);
                $('#msp_my_teams_sportpositions').selectBox('refresh');
            }
        });
        if($('#msp_my_teams_school').val()){
            // var defaultTeamName = $("#msp_my_teams_school_name").val() + ' ' + $("#msp_my_teams_sport option:selected").html() + ' Team';
            var defaultTeamName = $("#msp_my_teams_school_name").val().substr(0, $("#msp_my_teams_school_name").val().indexOf(',')) + ' ' + $("#msp_my_teams_sport option:selected").html();
            // alert(defaultTeamName)
            $('#msp_my_teams_teamName').val(defaultTeamName);
        } 
    });

    $('#enableTeamName').click(function(){
        $('#msp_my_teams_teamName').removeAttr('readonly');
    });
});