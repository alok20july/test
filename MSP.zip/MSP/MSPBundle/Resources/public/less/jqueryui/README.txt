﻿jQueryUI + LessCss

This is a beta release. It is meant to test an idea I have had for a while about mixing up the jQueryUI css framework and LessCss

In short it is meant to enable the use of the UI framework without using verbose classnames and adding :focus support without .js

To use these files you need to be running the LessCss parser --watch ing main.less

What has been done so far and notes why:

1) All variables changed by the jQueryUI themeroller engine can be affected using LessCss variables

Generating themes on themeroller is fine but once completed any minor modifications to the theme require you to either regenerate the whole thing using the themeroller app
or go in and modify the css. This makes the latter easier.

If you just want this functionallity then just use jqueryui.css and modify the variables to suit.

2) modified all the css selectors to be functions (as signified by the appended -f())
3) applied standard -f to mixin functions (signified by -m() in mixins.less)

This means we can call a single mixin function with desired styling AND means we can mixin :hover states in css against any selector without verbose class attributes

RFC

Paul Sullivan
