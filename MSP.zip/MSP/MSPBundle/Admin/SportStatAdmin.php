<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/8/13
 * Time: 10:27 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use MSP\MSPBundle\Entity;
use MSP\MSPBundle\Controller;

class SportStatAdmin extends Admin
{

    /**
     * @param \Sonata\AdminBundle\Show\ShowMapper $showMapper
     *
     * @return void
     */
    protected function configureShowField(ShowMapper $showMapper)
    {
        $showMapper
            ->add('id')
            ->add('name')
            ->add('abbrev')
            ->add('defaultValue')
            ->add('sortOrder')
            ->add('widgetType')
            ->add('tooltip')
            ->add('statType')
            ->add('options')
            ->add('sport')
            ->add('sportStatGroup')
        ;
    }

    /**
     * @param \Sonata\AdminBundle\Form\FormMapper $formMapper
     *
     * @return void
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')

            ->add('name')
            ->add('abbrev')
            ->add('sport')
            ->add('widgetType', 'choice', array(
                'choices'   => array('input' => 'Input', 'choice' => 'Choice', 'checkbox' => 'Checkbox',
                    'integer' => 'Integer', 'float' => 'Float'),
                'required'  => true,
            ))
            ->add('options')
            ->add('defaultValue')
            ->add('tooltip')

            ->add('statCategory', 'choice', array(
                'choices' => array(
                    Entity\SportStat::ALL_STAT => 'Show this Stat For Games/Events and Season',
                    Entity\SportStat::GAME_STAT => 'Game Stat (Do not show in season)',
                    Entity\SportStat::SEASON_STAT => 'Season Stat (Do not show in Game)',
                    Entity\SportStat::MEET_STAT => 'Event/Meet Stat (Do not show in Season)',
                )))
            ->add('sportStatGroup', null, array('required' => false))
            ->add('isGlobal')
            ->add('sortOrder')
            ->add('sportPositions', null, array('required' => false))
            ->add('statType', 'choice', array(
                'choices' => array('average' => 'average',
                    'sum' => 'sum', 'maximum' => 'maximum', 'minimum' => 'minimum'),
                'required' => true,))
            ->add('isHidden')
            ->add('isCalculation')
            ->add('parameters')
            ->add('methodName', 'choice', array(
                    'choices' => Controller\StatsCalculations::$calculationMethod,
                    'required' => false
                ))
            ->end()
        ;
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\ListMapper $listMapper
     *
     * @return void
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->addIdentifier('id')

            ->add('name')
            ->add('abbrev')
            ->add('sortOrder')
            ->add('widgetType')
            ->add('statType')
            ->add('sport')
            ->add('isCalculation')
            ->add('parameters')
            ->add('sportStatGroup')
            ->add('sportPositions')
        ;
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\DatagridMapper $datagridMapper
     *
     * @return void
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('name')
            ->add('sport')
        ;
    }
}
