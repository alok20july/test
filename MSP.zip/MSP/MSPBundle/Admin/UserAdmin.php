<?php
/**
 * Created by JetBrains PhpStorm.
 * User: hdorfman
 * Date: 7/8/13
 * Time: 10:27 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Form\FormMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Show\ShowMapper;
use MSP\MSPBundle\Entity;
use Sonata\UserBundle\Admin\Model\UserAdmin as BaseUserAdmin;
use FOS\UserBundle\Model\UserManagerInterface;

class UserAdmin extends BaseUserAdmin
{
    /**
     * @param \Sonata\AdminBundle\Form\FormMapper $formMapper
     *
     * @return void
     */
    protected function configureFormFields(FormMapper $formMapper)
    {
        $formMapper
            ->with('General')

            ->add('username')
            ->add('email')
            ->add('plainPassword', 'password')
            ->add('roles')
            ->add('firstname')
            ->add('middleName')
            ->add('nickName')
            ->add('mspGallery')
            ->add('gender', 'choice', array(
                'choices'   => array('Male' => 'Male', 'Female' => 'Female'),
                'required'  => true,))
            ->add('height')
            ->add('weight')
            ->add('bio')
            ->add('phone')
            ->add('address')
            ->add('city')
            ->add('stateRegion')
            ->add('country')
            ->add('postalCode')
            ->add('groups')

            //->add('sports', null, array('required' => false))//, 'expanded' => true, 'multiple' => true, 'by_reference' => false))
            //->add('sportpositions')//, null, array('required' => false, 'expanded' => true))
            //->add('games')

            ->add('image', 'sonata_type_model_list', array('required' => false), array('link_parameters' => array('context' => 'profile')))
            ->add('standing')

            ->end()

        ;
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\ListMapper $listMapper
     *
     * @return void
     */
    protected function configureListFields(ListMapper $listMapper)
    {
        $listMapper
            ->addIdentifier('id')

            ->add('username')
            ->add('email')
            ->add('firstname')
            ->add('middleName')
            ->add('lastName')
            ->add('nickName')
            ->add('gender')
            ->add('height')
            ->add('weight')
            ->add('bio')
            ->add('profileImage')
            ->add('phone')
            ->add('address')
            ->add('city')
            ->add('stateRegion')
            ->add('country')
            ->add('postalCode')
            ->add('groups')
            ->add('sports')
            ->add('standing')
        ;
    }

    /**
     * @param \Sonata\AdminBundle\Datagrid\DatagridMapper $datagridMapper
     *
     * @return void
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {
        $datagridMapper
            ->add('firstname')
            ->add('lastname')
            ->add('groups')
        ;
    }


    /**
     * {@inheritdoc}
     */
    protected function configureShowFields(ShowMapper $showMapper)
    {
        $showMapper
            ->with('General')
            ->add('username')
            ->add('email')
            ->end()
            ->with('Groups')
            ->add('groups')
            ->end()
            ->with('Profile')
            ->add('dateOfBirth')
            ->add('firstname')
            ->add('lastname')
            ->add('website')
            ->add('biography')
            ->add('gender')
            ->add('locale')
            ->add('timezone')
            ->add('phone')
            ->end()
            ->with('Social')
            ->add('facebookUid')
            ->add('facebookName')
            ->add('twitterUid')
            ->add('twitterName')
            ->add('gplusUid')
            ->add('gplusName')
            ->end()
            ->with('Security')
            ->add('token')
            ->add('twoStepVerificationCode')
            ->end()
        ;
    }

    public function preUpdate($user)
    {
        $this->getUserManager()->updateCanonicalFields($user);
        $this->getUserManager()->updatePassword($user);
    }

    public function setUserManager(UserManagerInterface $userManager)
    {
        $this->userManager = $userManager;
    }

    /**
     * @return UserManagerInterface
     */
    public function getUserManager()
    {
        return $this->userManager;
    }
}