<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 1/28/14
 * Time: 11:07 AM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Controller;

use MSP\MSPBundle\Entity\Game;
use MSP\MSPBundle\Entity\Team;
use MSP\MSPBundle\Entity\GameStatValue;
use MSP\MSPBundle\Entity\UserTeamSeason;
use MSP\MSPBundle\Entity\WallComment;
use MSP\MSPBundle\Entity\WallPost;
use MSP\MSPBundle\Entity\School;
use MSP\MSPBundle\Entity\SchoolRepository;

use MSP\MSPBundle\Form\AcademicInfoType;
use MSP\MSPBundle\Form\ProfileInformationType;
use MSP\MSPBundle\Form\WallCommentType;
use MSP\MSPBundle\Form\TheirTeamsType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;

class ComponentController extends Controller implements InitializableControllerInterface
{
    private $user;

    public function initialize(Request $request, SecurityContextInterface $security_context)
    {
        if (!$user = $this->getUser()) {
            return true;
        }else{
            return false;
        }
    }
    
    public function addTeamSeasonAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();

        $defaultSport = $this->getDoctrine()->getRepository('MSPBundle:Sport')->findOneByName('Soccer');
        $defaultSportPositions = $defaultSport->getSportPositions();

        $userTeamSeason = new UserTeamSeason();
        $userTeamSeason->setUser($user);
        $options = array('em' => $em);

        $form = $this->createForm('msp_team_season_type', $userTeamSeason, $options);

        if ($request->getMethod() == 'POST')
        {
            $data = array();
            $form->submit($request);
            $validator = $this->get('validator');
            $errorList = $validator->validate($userTeamSeason);

            if ($form->isValid()){
                $em->persist($userTeamSeason);
                $em->flush();
                $data['error'] = false;
                $data['data']['team_name'] = $userTeamSeason->getTeam()->getName();
                $data['data']['team_id'] = $userTeamSeason->getTeam()->getId();
                $data['data']['sport_id'] = $userTeamSeason->getSport()->getId();
            }else{                
                $data['error'] = true;
                if(count($errorList) > 0){
                    $data['msg'] = $errorList[0]->getMessage();
                }else{
                    $data['msg'] = "The form did not validate";
                }                
            }
            $response = new Response(json_encode($data));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        return $this->render('MSPBundle:Component:addTeamSeason.html.twig',
            array('form' => $form->createView(),
                'options' => array(
                    'defaultSport' => $defaultSport, 
                    'defaultSportPositions' => $defaultSportPositions,
                )
            )
        );
    }

    public function getTeamGameStatsAction(Request $request)
    {        
        if($request->getMethod() !== 'POST'){
            throw $this->createNotFoundException();
        }
        $teamId = $request->get('team_id');
        $team = $this->getDoctrine()->getRepository('MSPBundle:Team')->find($teamId);
        $wallPost = $this->initWallPostObject($team);
        // $allStatLists = $this->initWallPostObject($team);
        if($wallPost){
            $statGroupLists = array();
            if($wallPost->getGame()){
                foreach ($wallPost->getGame()->getGameStatValues() as $gameStatValues) {
                    if($gameStatValues->getSportStat()->getSportStatGroup()){
                        $groupName = $gameStatValues->getSportStat()->getSportStatGroup()->getName();
                        if(!array_key_exists($groupName, $statGroupLists)){
                            $$groupName = $gameStatValues->getSportStat()->getAbbrev().'#'.$gameStatValues->getSportStat()->getTooltip();
                        }else{
                            $$groupName .= ','.$gameStatValues->getSportStat()->getAbbrev().'#'.$gameStatValues->getSportStat()->getTooltip();;
                        }
                        $statGroupLists[$groupName] = $$groupName;
                    }
                }
            }
        }

        /*if($wallPost){
            $statGroupLists = array();
            foreach($wallPost->getGame()->getSport()->getSportStats() as $statList){
                if($statList->getSportStatGroup()){
                    if($statList->getIsGlobal() && !$statList->getIsCalculation()){
                        $groupName = $statList->getSportStatGroup()->getName();
                        if(!array_key_exists($groupName, $statGroupLists)){
                            $$groupName = $statList->getAbbrev().'#'.$statList->getTooltip();;
                        }else{
                            $$groupName .= ','.$statList->getAbbrev().'#'.$statList->getTooltip();;
                        }
                        $statGroupLists[$groupName] = $$groupName;
                    }
                }
            } 
        }*/
        
        $wallPostGameStatsForm = $this->createForm('msp_wall_type', $wallPost);
        return $this->render('MSPBundle:Component:teamGameStats.html.twig',
            array('wallForm' => $wallPostGameStatsForm->createView(), 'statGroupLists' => $statGroupLists));
    }

    /*
     * Used to initialize the wallPost Object based on team
     */
    public function initWallPostObject($team = null)
    {
        $user = $this->getUser();
        $wallPost = new  WallPost();
        $wallPost->setUser($user);
        if($team){
            $game = new Game();
            $game->setCreator($user);
            $game->setHomeTeam($team);
            $sport = $team->getSport();
            $game->setSport($sport);
            $sportStats = $user->getStatsForSport($sport);
            // $sportStats = $sport->getSportStats();
            if($sportStats && $sportStats->count()){
                foreach($sportStats as $stat){
                    $gameStatValue = new GameStatValue();
                    $gameStatValue->setSportStat($stat);
                    $gameStatValue->setGame($game);
                    $gameStatValue->setUser($user);
                    $game->addGameStatValue($gameStatValue);
                }
            }
            $wallPost->setGame($game);
        }
        return $wallPost;
    }

    public function academicInfoFormAction()
    {
        $user = $this->getUser();
        $form = new AcademicInfoType();

        $form = $this->createForm($form, $user);
        $request = $this->get('request');

        if ($request->getMethod() == 'POST')
        {
            $form->submit($request);
            if ($form->isValid())
            {
                $em = $this->getDoctrine()->getManager();
                $em->persist($user);
                $em->flush();
                $this->get('session')->getFlashBag()->add(
                    'notice',
                    'Your changes were saved!'
                );
                //return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_academic_info'));
            }
        }

        return $this->render('MSPBundle:Component:Forms/academicInfoForm.html.twig',
            array('form' => $form->createView()));
    }

    public function teamsInfoFormAction()
    {
        $em = $this->getDoctrine()->getManager();

        $userManager = $this->container->get('fos_user.user_manager');
        /*$user = $userManager->findUserByUsername($this->container->get('security.context')
            ->getToken()
            ->getUser());*/
         $user = $this->getUser();
        // default sport & sportPosition values
        $defaultSport = $this->getDoctrine()->getRepository('MSPBundle:Sport')->findOneByName('Soccer');
        $defaultSportPositions = $defaultSport->getSportPositions();

        $userTeamSeason = new UserTeamSeason();
        $userTeamSeason->setUser($user);
        $options = array('em' => $em);

        $form = $this->createForm('msp_my_teams', $userTeamSeason, $options);
        $request = $this->get('request');

        $userTeamSeasons = $this->getUser()->getUserTeamSeason();
        $userTeamSeasonForms = array();

        if ($request->getMethod() == 'POST')
        {
            $form->submit($request);
            if ($form->isValid())
            {
                $em->persist($userTeamSeason);
                $em->flush();
                $this->get('session')->getFlashBag()->add(
                    'notice',
                    'Your entry was added!'
                );
            }
            else
            {
                $this->get('session')->getFlashBag()->add(
                    'invalid',
                    'Your entry was invalid.'
                );
            }
        }

        foreach ($userTeamSeasons as $userTeamSeason)
        {
            $sport_id = $userTeamSeason->getSport()->getId();
            $options['sport_id'] = $sport_id;
            $userTeamSeasonForms[$userTeamSeason->getId()] = $this->createForm('msp_my_teams', $userTeamSeason, $options)->createView();
        }

        return $this->render('MSPBundle:Component:Forms/teamsInfoForm.html.twig',
            array('form' => $form->createView() , 'userTeamSeasonForms' => $userTeamSeasonForms, 'options' => array(
                'defaultSport' => $defaultSport,
                'defaultSportPositions' => $defaultSportPositions,
            )));
    }

    public function sportsInfoFormAction()
    {
        $user = $this->getUser();
        // form for athlete
        $form = new ProfileInformationType();
        $user->setImage($user->getImage());


        $form = $this->createForm($form, $user);

        $request = $this->get('request');

        if ($request->getMethod() == 'POST')
        {
            $form->submit($request);
            if ($form->isValid())
            {
                $em = $this->getDoctrine()->getManager();
                $em->persist($user);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
            }
        }

        return $this->render('MSPBundle:Component:Forms/sportsInfoForm.html.twig',
            array('form' => $form->createView(), 'user' => $user));
    }

    // used to save comments and render the comment form
    public function wallCommentFormAction()
    {
        $request = $this->getRequest();
        $wallComment = new WallComment();
        $wallComment->setUser($this->getUser());

        $form = $this->createForm(new WallCommentType(), $wallComment);

        if ($request->getMethod() == 'POST')
        {
            $form->submit($request);
            if ($form->isValid())
            {
                $em = $this->getDoctrine()->getManager();
                $em->persist($wallComment);
                $em->flush();

            }
        }

        return $this->render('MSPBundle:Component:Forms/wallCommentForm.html.twig',
            array('form' => $form->createView()));
    }


    public function renderSeasonStatAction()
    {
        $seasonStats = array();
        $gameStats = array();
        $uts = $this->getRequest()->get('uts');
        /* @var $uts UserTeamSeason
         */
        $tmpSeasonStats = $uts->getApplicableSeasonStats();
        $seasonStatValues = $this->getDoctrine()->getRepository('MSPBundle:UserTeamSeason')->getAllSeasonStatsValues($uts);

        // all season stat value needs to be added to the array.
        foreach($seasonStatValues as $ssv){
                if($ssv->getSportStat()->getSportStatGroup()){
                    if(isset($seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()])){
                        $seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()]['values'][$ssv->getSportStat()->getAbbrev()] = $ssv;
                    }else{
                        $seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()] = array(
                            'seasonStatGroup' => $ssv->getSportStat()->getSportStatGroup(),
                            'values' => array($ssv->getSportStat()->getAbbrev() => $ssv)
                        );
                    }
                }
        }

        // if some season stats are empty. We still show the labels and empty value
        foreach($tmpSeasonStats as $seasonStat){
            if($seasonStat->getSportStatGroup()){
                // if the stat group doesn't exist create it.
                if(!isset($seasonStats[$seasonStat->getSportStatGroup()->getId()])){
                    $seasonStats[$seasonStat->getSportStatGroup()->getId()] = array('seasonStatGroup' => $seasonStat->getSportStatGroup(),
                        'values' => array($seasonStat->getAbbrev() => null));
                }elseif(!isset($seasonStats[$seasonStat->getSportStatGroup()->getId()]['values'][$seasonStat->getAbbrev()])){
                    $seasonStats[$seasonStat->getSportStatGroup()->getId()]['values'][$seasonStat->getAbbrev()] = null;
                }
            }
        }

        if($uts->getSport()->getIsTeamSport()){
            // Team Sports will have games.
            $tmpGameStats = $uts->getApplicableGameStats();
            $games = $uts->getGames();

            if($games){
                foreach($games as $game){
                    $gameStatValues = $game->getGameStatValuesForUser($uts->getUser());

                    // first add all the game stat value users stored.
                    foreach($gameStatValues as $gsv){
                        $sportStatGroup = $gsv->getSportStat()->getSportStatGroup();
                        $sportStat = $gsv->getSportStat();

                        if(!isset($gameStats[$game->getId()])){
                            $gameStats[$game->getId()] = array(
                                'game' => $game,
                                'stats' => array($sportStatGroup->getId() => array($sportStat->getAbbrev() => $gsv->getValue()))
                            );
                        }else{
                            if(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()])){
                                $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()] = array($sportStat->getAbbrev() => $gsv->getValue());
                            }else{
                                $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$sportStat->getAbbrev()] = $gsv->getValue();
                            }
                        }
                    }

                    // add game stats that should be provided but are not with empty value.
                    foreach($tmpGameStats as $gs){
                        $sportStatGroup = $gs->getSportStatGroup();

                        if(!isset($gameStats[$game->getId()])){
                            $gameStats[$game->getId()] = array(
                                'game' => $game,
                                'stats' => array($sportStatGroup->getId() => array($gs->getAbbrev() => null))
                            );
                        }elseif(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()])){
                            $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()] = array($gs->getAbbrev() => null);
                        }elseif(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getAbbrev()])){
                            $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getAbbrev()] = null;
                        }

                    }

                }
            }
        }else{
            // @todo handle individual sports

        }

        return $this->render('MSPBundle:Component:renderSeasonStat.html.twig',
            array('seasonStats' => $seasonStats, 'uts' => $uts, 'gameStats' => $gameStats));
    }

    public function ajaxRenderSportPositionsAction($sportId)
    {
        $sportPositions = null;
        $sport = $this->getDoctrine()->getRepository('MSPBundle:Sport')->find($sportId);
        /* @var $sport Sport */
        if($sport){
            $sportPositions = $sport->getSportPositions();
        }

        return $this->render('MSPBundle:Component:ajaxRenderSportPositionOptions.html.twig',
            array('sportPositions' => $sportPositions));
    }

    public function addTheirTeamAction()
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();

        $theirTeam = new Team();
        $theirTeam->setCreatedBy($user);
        $options = array('em' => $em);

        $form = $this->createForm('msp_their_team', $theirTeam, $options);

        if ($request->getMethod() == 'POST')
        {    
            $theirTeamData = $request->request->get('msp_their_team');
            $theirTeamName = $theirTeamData['name'];
            $data = array();
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($theirTeam);
                $em->flush();
                $theirTeamId = $theirTeam->getId();
                $data['error'] = false;
                $data['data']['team_name'] = $theirTeamName;
                $data['data']['team_id'] = $theirTeamId;
            }else{
                $data['error'] = true;
                $data['msg'] = "The form did not validate";
            }
            $response = new Response(json_encode($data));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }

        return $this->render('MSPBundle:Component:addTheirTeam.html.twig',
            array('form' => $form->createView()));
    }


    /* Get list of schools using keyword search by user */
    public function ajaxGetSchoolListAction(Request $request){
        $value = $request->get('term');
        $state = 0;
        if($request->get('state')){
            $state = $request->get('state');
        }
        $em = $this->getDoctrine()->getManager();
        $schools = $em->getRepository('MSPBundle:School')->getSchools($value, $state);
        $json = array();
        if($schools){
            foreach ($schools as $school) {
                $json[] = array(
                    'label' => $school->getName().', '.$school->getCity(),
                    'value' => $school->getId()
                );       
            }
        }
        $response = new Response();
        $response->setContent(json_encode($json));
        return $response;
    }
}