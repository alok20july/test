<?php

namespace MSP\MSPBundle\Controller;

use MSP\MSPBundle\Form\GameStatsValuesFormType;
use MSP\MSPBundle\Form\WallType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use MSP\MSPBundle\Entity;
use MSP\MSPBundle\Entity\UserTeamSeason;
use MSP\MSPBundle\Entity\KeyMeasurableValue;
use MSP\MSPBundle\Entity\Game;
use MSP\MSPBundle\Entity\Meet;
use MSP\MSPBundle\Entity\WallPost;
use MSP\MSPBundle\Entity\WallComment;
use MSP\MSPBundle\Entity\GameStatValue;
use MSP\MSPBundle\Entity\SeasonStatValue;
use MSP\MSPBundle\Entity\CustomNewsFeed;
use MSP\MSPBundle\Entity\TrainingSession;
use MSP\MSPBundle\Entity\KeyMeasurable;
use MSP\MSPBundle\Entity\UserKeyMeasurableSession;
use MSP\MSPBundle\Admin;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use MSP\MSPBundle\Form\ProfileInformationType;
use MSP\MSPBundle\Form\CoachInformationType;
use MSP\MSPBundle\Form\FanInformationType;
use MSP\MSPBundle\Form\AcademicInfoType;
use MSP\MSPBundle\Form\GameType;
use MSP\MSPBundle\Form\MeetType;
use MSP\MSPBundle\Form\GameStatFormType;
use MSP\MSPBundle\Form\KeyMeasurablesType;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Translation\Exception\NotFoundResourceException;
use Application\Sonata\MediaBundle\Entity\Media;
use Symfony\Component\Form\DataTransformerInterface;
use Sonata\Bundle\DemoBundle\Model\MediaPreview;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Validator\Constraints\DateTime;
use Symfony\Component\HttpFoundation\Session\Session;

use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;

class DashboardController extends Controller implements InitializableControllerInterface
{
    private $user;

    public function initialize(Request $request, SecurityContextInterface $security_context)
    {
        if (!$user = $this->getUser()) {
            return true;
        }else{
            return false;
        }
    }

    public function dashAction(){
        return $this->render('MSPBundle:Dashboard:myProfile.html.twig');
    }

    /*
     * Used to initialize the wallPost Object based on team
     */
    public function initWallPostObject(Entity\Team $team = null)
    {
        $user = $this->getUser();
        $wallPost = new WallPost();
        $wallPost->setUser($user);
        if($team){
            $game = new Game();
            $game->setCreator($user);
            $game->setHomeTeam($team);
            $sport = $team->getSport();
            $game->setSport($sport);
            $sportStats = $user->getStatsForSport($sport);
            if($sportStats && $sportStats->count()){
                foreach($sportStats as $stat){
                    $gameStatValue = new GameStatValue();
                    $gameStatValue->setSportStat($stat);
                    $gameStatValue->setGame($game);
                    $gameStatValue->setUser($user);
                    $game->addGameStatValue($gameStatValue);
                }
            }
            $wallPost->setGame($game);
        }
        return $wallPost;
    }

    public function newsfeedAction()
    {
        
        $customNewsFeed = $this->getDoctrine()->getRepository('MSPBundle:CustomNewsFeed')->findBy(array('status' => 1));

        $user = $this->getUser();
        $wallPosts = $this->getDoctrine()->getRepository('MSPBundle:WallPost')->getWallPostsForUser($user);
        
        $trainingSession = new TrainingSession();
        $wallPostTrainingForm = $this->createForm('msp_user_session_keymeasurables', $trainingSession);
        
        $keyMeasurables = $this->getDoctrine()->getRepository('MSPBundle:KeyMeasurable')->getUserKeyMeasurableList($user);

        $comment = new WallComment();
        $comment->setUser($this->getUser());
        $commentForm = $this->createForm('msp_wall_comment_type', $comment);

        $myDefaultTeam = $this->getDoctrine()->getRepository('MSPBundle:User')->getMainTeamForUser($user);

        $wallPost = $this->initWallPostObject($myDefaultTeam);

        $userTeams = $this->getUser()->getMyTeamOptions();

        //exit(\Doctrine\Common\Util\Debug::dump($wallPost->getGame()->getGameStatValues()));
        if($wallPost){
            $statGroupLists = array();
            if($wallPost->getGame()){
                foreach ($wallPost->getGame()->getGameStatValues() as $gameStatValues) {
                    if($gameStatValues->getSportStat()->getSportStatGroup()){
                        $groupName = $gameStatValues->getSportStat()->getSportStatGroup()->getName();
                        if(!array_key_exists($groupName, $statGroupLists)){
                            $$groupName = $gameStatValues->getSportStat()->getAbbrev().'#'.$gameStatValues->getSportStat()->getTooltip();
                        }else{
                            $$groupName .= ','.$gameStatValues->getSportStat()->getAbbrev().'#'.$gameStatValues->getSportStat()->getTooltip();;
                        }
                        $statGroupLists[$groupName] = $$groupName;
                    }
                }
            }
        }

        // instantiate default forms for wall posting
        $wallPostGameForm = $this->createForm('msp_wall_type', $wallPost);
        $wallPostSimpleForm = $this->createForm('msp_wall_type', $wallPost);
        $wallPostVideoForm = $this->createForm('msp_wall_type', $wallPost);
        $wallPostImageForm = $this->createForm('msp_wall_type', $wallPost);

        // print_r($statGroupLists); 
        return $this->render('MSPBundle:Dashboard:newsfeed.html.twig',
            array(
                'myDefaultTeam' => $myDefaultTeam,
                'wallPostSimpleForm' => $wallPostSimpleForm->createView(),
                'wallPostVideoForm' => $wallPostVideoForm->createView(),
                'wallPostImageForm' => $wallPostImageForm->createView(),
                'wallPostGameForm' => $wallPostGameForm->createView(),
                'wallPostTrainingForm' => $wallPostTrainingForm->createView(),
                'wallPosts' => $wallPosts,
                'commentForm' => $commentForm->createView(),
                'customNewsFeed' => $customNewsFeed,
                'userTeams' => $userTeams,
                'keyMeasurables' => $keyMeasurables,
                'statGroupLists' => $statGroupLists
            )
        );
    }

    /* function to render game stat value */
    public function renderWallGameStatsAction(){
        $gameStats = array();
        $gameAbbrValues = array();
        $game = $this->getRequest()->get('game');
        $gameStatValues = $game->getGameStatValuesForUser($game->getCreator());
        $tmpGameStats = $game->getUserTeamSeason()->getApplicableGameStats();
        foreach($gameStatValues as $gsv){
            $sportStat = $gsv->getSportStat(); 
            if($sportStat->getSportStatGroup()){ 
                if(!$sportStat->getIsCalculation() && !$sportStat->getIsHidden()){
                    $gameStats[$sportStat->getSportStatGroup()->getId()][$sportStat->getSortorder()][$sportStat->getAbbrev().'#'.$sportStat->getTooltip()] = $gsv->getValue();
                }  
                $gameAbbrValues[$sportStat->getAbbrev()] = $gsv->getValue();
            }         
        }

        foreach($tmpGameStats as $gs){
            if($gs->getSportStatGroup()){
                if($gs->getIsCalculation() && !$gs->getIsHidden()){
                    // $parts = explode(',', $sportStat->getParameters());
                    $methodName = $gs->getMethodName();
                    if(method_exists(new StatsCalculations(), $methodName)){
                        $result = StatsCalculations::$methodName($gameAbbrValues, $gs->getParameters());
                        $gameStats[$gs->getSportStatGroup()->getId()][$gs->getSortorder()][$gs->getAbbrev().'#'.$gs->getTooltip()] = $result;    
                    }                    
                }
                ksort($gameStats[$gs->getSportStatGroup()->getId()]);
            }            
        }
        // exit(\Doctrine\Common\Util\Debug::dump($gameStats));
        return $this->render('MSPBundle:Dashboard/Partials:renderGameStats.html.twig',
            array('gameStats' => $gameStats, 'game' => $game));
    }

    public function addTrackSessionAction(){
        $request = $this->get('request');
        $user = $this->getUser();

        $em = $this->getDoctrine()->getManager();
        $wallPost = new WallPost();
        $wallPost->setUser($user);
        $content = $request->request->get('content');
        $trainingSession = new TrainingSession();
        $form = $this->createForm('msp_user_session_keymeasurables', $trainingSession);
        if ($request->getMethod() == 'POST'){                   
            $form->submit($request);
            if ($form->isValid()){               
                $em->persist($trainingSession);
                $em->flush();    

                $em = $this->getDoctrine()->getManager();
                $wallPost->setStats($trainingSession);
                $wallPost->setContent($content);
                $em->persist($wallPost);
                $em->flush();  
                
                foreach($request->request->get('value') as $key => $value){                    
                    if($value != '' ){
                        $em = $this->getDoctrine()->getManager();
                        $keyMeasurableValue = new KeyMeasurableValue();
                        $keyMeasurable = $em->getRepository('MSPBundle:KeyMeasurable')->findOneBy(array('id' => $key));
                        $keyMeasurableValue->setUser($user);
                        $keyMeasurableValue->setKeyMeasurable($keyMeasurable);
                        $keyMeasurableValue->setTrainingSession($trainingSession);
                        $keyMeasurableValue->setValue($value);
                        $em->persist($keyMeasurableValue);
                        $em->flush(); 
                    }                    
                }
                return $this->redirect($this->generateUrl('msp_dashboard_my_sport_page')); 
            }
        }    
    }

    public function newWallPostAction(Request $request)
    {
        $team = null;

        if ($request->getMethod() == 'POST'){
            $formData = $request->get('msp_wall_type');
            $submittedData = $request;
            if(isset($formData['game']['homeTeam'])){
                $team = $this->getDoctrine()->getRepository('MSPBundle:Team')->find($formData['game']['homeTeam']);
            }

            if(isset($formData['game']['gameStatValues'])){
                for($i=0; $i< count($formData['game']['gameStatValues']); $i++){
                    if($formData['game']['gameStatValues'][$i]['value'] == null)
                        $formData['game']['gameStatValues'][$i]['value'] = 0;
                }
                $submittedData = $formData;
            }
            // in case of a game add the dateTimeStart
            // print_r($submittedData); die;
            $wallPost = $this->initWallPostObject($team);            
            $wallForm = $this->createForm('msp_wall_type', $wallPost);
            $wallForm->submit($submittedData);
            if ($wallForm->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($wallPost);
                $em->flush();
                // assign game to a userTeamSeason
                $game = $wallPost->getGame();
                if($game){
                    $userTeamSeason = $this->getUserTeamSeasonForGame($game);             
                    $game->setUserTeamSeason($userTeamSeason);
                    $em->persist($game);
                    $em->flush();
                }               
            }/*else{
                print_r($wallForm->getErrors());
                die;
            }*/
        }
        return $this->redirect($this->generateUrl('msp_dashboard_my_sport_page'));
    }

    public function newWallCommentAction($id)
    {
        if($this->getRequest()->getMethod() !== 'POST'){
            throw $this->createNotFoundException();
        }
        $user = $this->getUser();
        $comment = new WallComment();
        $comment->setUser($user);
        $em = $this->getDoctrine()->getManager();
        $post = $em->getRepository('MSPBundle:WallPost')->findOneBy(array('id' => $id));
        $comment->setWallPost($post);
        $commentForm = $this->createForm('msp_wall_comment_type', $comment);
        $request = $this->get('request');
        $commentForm->submit($request);
        if ($commentForm->isValid()){
            $em = $this->getDoctrine()->getManager();
            $em->persist($comment);
            $em->flush();
            return $this->render('MSPBundle:Dashboard:Partials/wallPostComment.html.twig', array('comment' => $comment));
        }else{
            throw $this->createNotFoundException();
        }
    }

    public function deleteWallPostAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $post = $em->getRepository('MSPBundle:WallPost')->findOneBy(array('id' => $id));

        if($post){
            if($post->getUser()->getId() !== $this->getUser()->getId()){
                throw new AccessDeniedException();
            }
        }
        $em->remove($post);
        $em->flush();
        return $this->redirect($this->generateUrl('msp_dashboard_my_sport_page'));
    }

    public function deleteWallCommentAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $comment = $em->getRepository('MSPBundle:WallComment')->findOneBy(array('id' => $id));

        if($comment){
            if($comment->getWallPost()->getUser()->getId() !== $this->getUser()->getId()){
                throw new AccessDeniedException();
            }
        }
        $em->remove($comment);
        $em->flush();
        return $this->redirect($this->generateUrl('msp_dashboard_my_sport_page'));
    }

    public function myProfileAction()
    {
        $groups = $this->getUser()->getGroups();
        foreach($groups as $group){
            echo $group->getName();
        }
        return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
    }

    public function userProfileAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $options['em'] = $em;
        $profile = $em->getRepository('MSPBundle:User')->findOneBy(array('id' => $id));
        if($profile){
            return $this->render('MSPBundle:Dashboard:userProfile.html.twig', array('id' => $id, 'profile' => $profile));
        }
        return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
    }

    public function myPersonalInformationAction(Request $request)
    {
        $userManager = $this->container->get('fos_user.user_manager');
        $user = $this->getUser();
        if($user->getIsFirstTimeUser()){
            $em = $this->getDoctrine()->getManager();
            $session = $this->get('session');
            $session->set('activeTour', true);
            $user->setIsFirstTimeUser(false);
            $em->persist($user);
            $em->flush();
        }

        $form = new ProfileInformationType();
        $user->setImage($user->getImage());
        $form = $this->createForm($form, $user);
        $request = $this->get('request');
        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($user);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
            }
        }
        return $this->render('MSPBundle:Dashboard:myPersonalInformation.html.twig',
            array('form' => $form->createView(), 'user' => $user));
    }


    public function addTeamAction()
    {
        $em = $this->getDoctrine()->getManager();

        $userTeamSeason = new UserTeamSeason();
        $userTeamSeason->setUser($this->getUser());
        $options = array('em' => $em);

        $form = $this->createForm('msp_my_teams', $userTeamSeason, $options);
        $request = $this->get('request');

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($userTeamSeason);
                $em->flush();
                $this->get('session')->getFlashBag()->add(
                    'notice',
                    'Your entry was added!'
                );
            }
        }

        $sport_id = $userTeamSeason->getSport()->getId();
        $options['sport_id'] = $sport_id;
        $userTeamSeasonForm = $this->createForm('msp_my_teams', $userTeamSeason, $options)->createView();

        return $this->render('MSPBundle:Component:Forms/userTeamSeasonForm.html.twig',
            array('userTeamSeasonForm' => $userTeamSeasonForm, 'key' => $userTeamSeason->getId()));
    }

    public function myTeamsAction()
    {
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        $myGroups = $user->getGroups();

        if(!in_array('athlete', $myGroups->toArray()) && !in_array('coach', $myGroups->toArray())){
            // form for fan
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }
        $userTeamSeason = new UserTeamSeason();
        $userTeamSeason->setUser($this->getUser());
        $options = array('em' => $em);

        $form = $this->createForm('msp_my_teams', $userTeamSeason, $options);
        $request = $this->get('request');

        $userTeamSeasons = $this->getUser()->getUserTeamSeason();
        $userTeamSeasonForms = array();

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($userTeamSeason);
                $em->flush();
                $this->get('session')->getFlashBag()->add(
                    'notice',
                    'Your entry was added!'
                );
            }
            else{
                $this->get('session')->getFlashBag()->add(
                    'invalid',
                    'Your entry was invalid.'
                );
            }
        }

        foreach ($userTeamSeasons as $userTeamSeason){
            $sport_id = $userTeamSeason->getSport()->getId();
            $options['sport_id'] = $sport_id;
            $userTeamSeasonForms[$userTeamSeason->getId()] = $this->createForm('msp_my_teams', $userTeamSeason, $options)->createView();
        }

        return $this->render('MSPBundle:Dashboard:myTeams.html.twig',
            array('form' => $form->createView() , 'userTeamSeasonForms' => $userTeamSeasonForms));
    }

    public function updateMyTeamAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $option['post'] = 'update';
        $request = $this->get('request');

        $myTeam = $em->getRepository('MSPBundle:UserTeamSeason')->findOneBy(array('id' => $id));

        if(!$myTeam){
            throw new NotFoundResourceException('Object Not Found');
        }

        if($myTeam->getUser()->getId() !== $this->getUser()->getId()){
            throw new AccessDeniedException();
        }

        $options['sport_id'] = $myTeam->getSport()->getId();

        $form = $this->createForm('msp_my_teams', $myTeam, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($myTeam);
                $em->flush();
                $this->get('session')->getFlashBag()->add(
                    'notice',
                    'Your changes were saved!'
                );
                return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_teams'));
            }else{
                $this->get('session')->getFlashBag()->add(
                    'notice',
                    'Form did not validate'
                );
            }
        }

        return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_teams'));
    }

    public function deleteMyTeamAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $myTeam = $em->getRepository('MSPBundle:UserTeamSeason')->findOneBy(array('id' => $id));

        if($myTeam){
            if($myTeam->getUser()->getId() !== $this->getUser()->getId()){
                throw new AccessDeniedException();
            }
        }
        $em->remove($myTeam);
        $em->flush();
        return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_teams'));
    }

    public function academicInfoAction()
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $keyMeasurableValue = new KeyMeasurableValue();
        $keyMeasurableValue->setUser($this->getUser());
        $form = $this->createForm('msp_mspbundle_mykeymeasurables', $keyMeasurableValue, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($keyMeasurableValue);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_measurables'));
            }
        }
        return $this->render('MSPBundle:Dashboard:academicInfo.html.twig',
            array('form' => $form->createView()));
    }

    public function myMeasurablesAction()
    {
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();

        $myGroups = $user->getGroups();
        $keyMeasurable = new KeyMeasurableValue();
        $keyMeasurable->setUser($user);
        $options = array('em' => $em);
        if(in_array('athlete', $myGroups->toArray())) {
            // form for athlete
            $form = new KeyMeasurablesType($em);
        }
        else{
            // form for fan
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }

        $keys = $em->getRepository('MSPBundle:KeyMeasurable')->findAll();  //instead of finding all, find those related to the sport
        $keyForms = array();        //measurables that are set by the user and very relevant
        $someKeyForms = array();    //measurables that are set by the user
        $moreKeyForms = array();    //measurables that are universal or are attributed to the user
        $otherKeyForms = array();   //measurables that aren't related to the user

        foreach ($keys as $keyMeasurable) {
            $value = $user->getValueForKeyMeasurable($keyMeasurable);

            $options['keyMeasurable'] = $keyMeasurable;
            $form = $this->createForm('msp_mspbundle_mykeymeasurables', $value, $options);
            $used = false;

            foreach ($keyMeasurable->getSports() as $sport){
                if (!$used){
                    if($value!=null && ($user->hasSport($sport) || $keyMeasurable->getIsGlobal())){
                        $keyForms[] = $form->createView();
                        $used = true;
                    }
                    elseif($value!=null){
                        $someKeyForms[] =$form->createView();
                        $used = true;
                    }
                    elseif($user->hasSport($sport) || $keyMeasurable->getIsGlobal()){
                        $moreKeyForms[] =$form->createView();
                        $used = true;
                    }
                    else{
                        $otherKeyForms[] = $form->createView();
                        $used = true;
                    }
                }
            }
        }
        return $this->render('MSPBundle:Dashboard:myMeasurables.html.twig',
            array('keyForms' => $keyForms, 'someKeyForms' => $someKeyForms, 'moreKeyForms' => $moreKeyForms,
                'otherKeyForms' => $otherKeyForms));
    }

    public function updateMeasurablesAction($id)
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $measurable = $em->getRepository('MSPBundle:KeyMeasurableValue')->findOneBy(array('id' => $id));
        $options['keyMeasurable'] = $measurable->getKeyMeasurable();
        $form = $this->createForm('msp_mspbundle_mykeymeasurables', $measurable, $options);
        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($measurable);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_measurables'));
            }
        }
        return $this->render('MSPBundle:Dashboard:myMeasurables.html.twig');
    }

    public function newMeasurablesAction()
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $keyMeasurableValue = new KeyMeasurableValue();
        $keyMeasurableValue->setUser($this->getUser());
        $form = $this->createForm('msp_mspbundle_mykeymeasurables', $keyMeasurableValue, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($keyMeasurableValue);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_measurables'));
            }
        }
        return $this->redirect($this->generateUrl('msp_dashboard_my_measurables'));
    }

    public function mySummaryStatsAction()
    {
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();

        $myGroups = $user->getGroups();

        if(!in_array('athlete', $myGroups->toArray())){
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }

        $options = array('em' => $em);
        $teamSeasons = $this->getUser()->getUserTeamSeason();
        $newForms = array();
        $updateForms = array();

        foreach($teamSeasons as $teamSeason){
            $sportStats = $teamSeason->getSport()->getSportStats();
            foreach ($sportStats as $stat){
                $value = $this->getDoctrine()->getRepository('MSPBundle:GameStatValue')->getStatValueForTeamSeason($this->getUser(), $stat, $teamSeason);

                $new = false;
                if($value == null){
                    $value = new SeasonStatValue();
                    $value->setSportStat($stat);
                    $value->setUser($this->getUser());
                    $value->setUserTeamSeason($teamSeason);
                    $new = true;
                }
                $form = $this->createForm('msp_season_stat_type', $value, $options);
                if(!$new){
                    $updateForms[] = $form->createView();
                }
                else{
                    $newForms[] = $form->createView();
                }
            }
        }
        return $this->render('MSPBundle:Dashboard:mySummaryStats.html.twig',
            array('teamSeasons' => $teamSeasons, 'updateForms' => $updateForms, 'newForms' => $newForms));
    }

    public function updateSeasonStatsAction($id)
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();

        $options = array('em' => $em);
        $value = $em->getRepository('MSPBundle:SeasonStatValue')->findOneBy(array('id' => $id));

        $options['sportStat'] = $value->getSportStat();
        $form = $this->createForm('msp_season_stat_type', $value, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_summary_stats'));
            }
        }
        return $this->render('MSPBundle:Dashboard:mySummaryStats.html.twig');
    }

    public function newSeasonStatsAction()
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $value = new SeasonStatValue();
        $value->setUser($this->getUser());
        $form = $this->createForm('msp_season_stat_type', $value, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_summary_stats'));
            }
            else{
                die($form->getErrorsAsString());
            }
        }

        return $this->redirect($this->generateUrl('msp_dashboard_my_summary_stats'));
    }

    public function myGamesAction()
    {
        $myGames = array();
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        if(!$user->hasGroup('athlete')){
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }

        $game = new Game();
        $game->setCreator($user);
        $options = array('em' => $em);

        $games = $this->getUser()->getGames();
        $meets = $this->getUser()->getRaces();
        $gamesForms = array();

        $gameForm = $this->createForm('msp_game_type', $game, $options);
        $request = $this->get('request');

        if ($request->getMethod() == 'POST'){
            $gameForm->submit($request);
            if ($gameForm->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($game);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_games'));
            }
        }

        $teamSeasons = $this->getUser()->getUserTeamSeason();
        foreach($teamSeasons as $teamSeason){
            $game = new Game();
            $game->setSport($teamSeason->getSport());
            $game->setSeason($teamSeason->getSeason());
            $game->setHomeTeam($teamSeason->getTeam());
            $game->setName($game->getHomeTeam() . " VS. " . $game->getAwayTeam() . " Game" . $game->getId());
            $form =  $this->createForm('msp_game_type', $game, $options);

            $meet = new Meet();
            $meet->setSport($teamSeason->getSport());
            $meet->setSeason($teamSeason->getSeason());
            $meet->addTeam($teamSeason->getTeam());

            $mForm = $this->createForm('msp_meet_type', $meet, $options);
            $myGames[] = array('teamSeason' => $teamSeason, 'games' => $teamSeason->getGames(), 'form' => $form->createView(), 'meets' =>$teamSeason->getMeets(), 'mForm' => $mForm->createView());
            $gamesForms[$teamSeason->getId()] = $this->createForm('msp_game_type', $game, $options)->createView();
        }
        return $this->render('MSPBundle:Dashboard:myGames.html.twig',
            array('myGames' => $myGames,'gameForm' => $gameForm->createView(), 'gamesForms' => $gamesForms, 'teamSeasons' => $teamSeasons, 'games' => $games, 'meets' => $meets));
    }

    public function deleteMyGamesAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $myGame = $em->getRepository('MSPBundle:Game')->findOneBy(array('id' => $id));

        if($myGame){
            if($myGame->getCreator()->getId() !== $this->getUser()->getId()){
                throw new AccessDeniedException();
            }
        }
        $em->remove($myGame);
        $em->flush();

        return $this->redirect($this->generateUrl('msp_dashboard_my_games'));
    }

    public function existingGamesAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $options['em'] = $em;
        $myGame = $em->getRepository('MSPBundle:Game')->findOneBy(array('id' => $id));
        if($myGame && $myGame->getCreator()){
            if($myGame->getCreator()->getId() !== $this->getUser()->getId()){
                throw new AccessDeniedException();
            }
            else{
                $gamesForms[$id] = $this->createForm('msp_game_type', $myGame, $options)->createView();
                return $this->render('MSPBundle:Dashboard:existingGames.html.twig', array('id' => $id, 'form' => $gamesForms[$id]));
            }
        }
        return $this->redirect($this->generateUrl('msp_dashboard_my_games'));
    }

    public function myMeetsAction()
    {
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        $myGroups = $user->getGroups();

        if(!in_array('athlete', $myGroups->toArray()) && !in_array('coach', $myGroups->toArray())){
            // form for fan
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }

        $meet = new Meet();
        $meet->setCreator($user);
        $options = array('em' => $em);

        $meets = $this->getUser()->getMeets();
        $meetsForms = array();

        if(in_array('athlete', $myGroups->toArray())){
            // form for athlete
            $meetForm = new MeetType();
        }
        elseif(in_array('coach', $myGroups->toArray())){
            // form for coach
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }
        else{
            // form for fan
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }


        $meetForm = $this->createForm('msp_meet_type', $meet, $options);
        $request = $this->get('request');

        if ($request->getMethod() == 'POST'){
            $meetForm->submit($request);
            if ($meetForm->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($meet);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_games'));
            }
        }

        foreach ($meets as $meet){
            $sport = $meet->getSport();
            $options['season_id'] = $sport;
            $meetsForms[$meet->getId()] = $this->createForm('msp_meet_type', $meet, $options)->createView();
        }
        return $this->render('MSPBundle:Dashboard:myMeets.html.twig',
            array('meetForm' => $meetForm->createView(), 'meetsForms' => $meetsForms));
    }

    public function deleteMyMeetsAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $myMeet = $em->getRepository('MSPBundle:Meet')->findOneBy(array('id' => $id));

        if($myMeet){
            if($myMeet->getCreator()->getId() !== $this->getUser()->getId()){
                throw new AccessDeniedException();
            }
        }
        $em->remove($myMeet);
        $em->flush();
        return $this->redirect($this->generateUrl('msp_dashboard_my_meets'));
    }

    public function existingMeetsAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $options['em'] = $em;

        $myMeet = $em->getRepository('MSPBundle:Meet')->findOneBy(array('id' => $id));

        if($myMeet && $myMeet->getCreator()){
            if($myMeet->getCreator()->getId() !== $this->getUser()->getId()){
                throw new AccessDeniedException();
            }
            else{
                $meetsForms[$id] = $this->createForm('msp_meet_type', $myMeet, $options)->createView();
                return $this->render('MSPBundle:Dashboard:existingMeets.html.twig', array('id' => $id, 'form' => $meetsForms[$id]));
            }
        }
        return $this->redirect($this->generateUrl('msp_dashboard_my_meets'));
    }

    public function myGameStatsAction()
    {
        $myGames = array();
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();

        if(!$user->hasGroup('athlete')){
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }

        $options = array('em' => $em);
        $teamSeasons = $this->getUser()->getUserTeamSeason();
        foreach($teamSeasons as $teamSeason){
            $games = $teamSeason->getGames();
            $meets = $teamSeason->getMeets();
            $myMeetsAndStats = array();
            $myGamesAndStats = array();

            $newForms = array();
            $updateForms = array();

            if($teamSeason->getSport()->getIsTeamSport()){
                foreach ($games as $game){
                    $sportStats = $game->getSport()->getSportStats();

                    foreach ($sportStats as $stat){
                        $options['sportStat'] = $stat;
                        $value = $this->getDoctrine()->getRepository('MSPBundle:GameStatValue')->getStatValueForGame($this->getUser(), $stat, $game);

                        $new = false;
                        if($value == null){
                            $value = new GameStatValue();
                            $value->setSportStat($stat);
                            $value->setUser($this->getUser());
                            $value->setGame($game);
                            $new = true;
                        }
                        $form = $this->createForm('msp_game_stat_type', $value, $options);
                        if(!$new) {
                            $updateForms[] = $form->createView();
                        }
                        else{
                            $newForms[] = $form->createView();
                        }
                    }
                    $myGamesAndStats[] = array('game' => $game, 'newForms' => $newForms, 'updateForms' => $updateForms);
                }
            }
            else{
                foreach ($meets as $meet){
                    $sportStats = $meet->getSport()->getSportStats();
                    foreach ($sportStats as $stat){
                        $options['sportStat'] = $stat;
                        $value = $this->getDoctrine()->getRepository('MSPBundle:GameStatValue')->getStatValueForMeet($this->getUser(), $stat, $meet);
                        $new = false;
                        if($value == null){
                            $value = new GameStatValue();
                            $value->setSportStat($stat);
                            $value->setUser($this->getUser());
                            $value->setMeet($meet);
                            $new = true;
                        }
                        $form = $this->createForm('msp_game_stat_type', $value, $options);
                        if(!$new){
                            $updateForms[] = $form->createView();
                        }
                        else{
                            $newForms[] = $form->createView();
                        }
                    }
                    $myMeetsAndStats[] = array('meet' => $meet, 'newForms' => $newForms, 'updateForms' => $updateForms);
                }
            }
            $myGames[] = array('teamSeason' => $teamSeason, 'games' => $myGamesAndStats, 'meets' => $myMeetsAndStats);;
        }
        return $this->render('MSPBundle:Dashboard:myGameStats.html.twig',
            array('myGames' => $myGames));
    }

    public function updateGameStatsAction($id)
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();

        $options = array('em' => $em);
        $value = $em->getRepository('MSPBundle:GameStatValue')->findOneBy(array('id' => $id));

        $options['sportStat'] = $value->getSportStat();
        $form = $this->createForm('msp_game_stat_type', $value, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_game_stats'));
            }
        }
        return $this->render('MSPBundle:Dashboard:myGameStats.html.twig');
    }

    public function newGameStatsAction()
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $value = new GameStatValue();
        $value->setUser($this->getUser());
        $form = $this->createForm('msp_game_stat_type', $value, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_game_stats'));
            }
            else{
                die($form->getErrorsAsString());
            }
        }
        return $this->redirect($this->generateUrl('msp_dashboard_my_game_stats'));
    }

    public function myIndividualGameStatsAction($id)
    {

        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        $myGroups = $user->getGroups();

        if(!in_array('athlete', $myGroups->toArray()) && !in_array('coach', $myGroups->toArray())){
            // form for fan
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }

        $game = $em->getRepository('MSPBundle:Game')->findOneBy(array('id' => $id));
        $options = array('em' => $em);

        if($game){
            if($game->getCreator()->getId() !== $this->getUser()->getId()){
                throw new AccessDeniedException();
            }
        }

        $games = $this->getUser()->getGames();
        $listGameForms = array();

        foreach ($games as $game){
            $season_id = $game->getSeason()->getId();
            $options['season_id'] = $season_id;
            $listGameForms[$game->getId()] = $this->createForm('msp_game_type', $game, $options)->createView();

        }
        $user = $this->getUser();
        $myGroups = $user->getGroups();
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);

        if(in_array('athlete', $myGroups->toArray())){
            // form for athlete
            $gameForm = new GameType();
        }
        elseif(in_array('coach', $myGroups->toArray())){
            // form for coach
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }
        else{
            // form for fan
            return $this->redirect($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }
        $gameForm = $this->createForm('msp_game_type', $game, $options);
        $request = $this->get('request');

        if ($request->getMethod() == 'POST'){
            $gameForm->submit($request);
            if ($gameForm->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($game);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_my_game_stats'));
            }
        }
        return $this->render('MSPBundle:Dashboard:myGameStats.html.twig',
            array('gameForm' => $gameForm->createView(), 'listGameForms' => $listGameForms, 'i' => $id));
    }

    public function myConnectionsAction()
    {
        $user = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $teammates = $em->getRepository('MSPBundle:User')->getTeammatesForUser($user);
        return $this->render('MSPBundle:Dashboard:myConnections.html.twig', array(
            'genuineTeamMates' => $teammates
        ));
    }

    public function ajaxTeamAction(Request $request)
    {
        $value = $request->get('term');
        $em = $this->getDoctrine()->getManager();
        $qb = $em->createQueryBuilder();
        $teamId = $request->get('team_id');
        $teams = $em->getRepository('MSPBundle:Team')->getPossibleOponentTeams($value, $teamId);
        $json = array();
        if($teams){
            foreach ($teams as $team) {
                $json[] = array(
                    'label' => $team->getName(),
                    'value' => $team->getId()
                );
            }
        }
        $response = new Response();
        $response->setContent(json_encode($json));
        return $response;
    }

    public function ajaxSaveImageAction(Request $request)
    {
        $options = array('provider' => 'sonata.media.provider.image', 'context' => 'wall');
        $media = new Media();
        $media->setContext('wall');
        $media->setProviderName('sonata.media.provider.image');
        $form = $this->createForm('sonata_media_type', $media, $options);

        // create the form
        $builder = $this->createFormBuilder($media);
        $em = $this->getDoctrine()->getManager();
        if ($request->getMethod() == 'POST') {
            $form->submit($request);
            if($form->isValid()) {
                $em->persist($media);
                $em->flush();
            } else {
                var_dump($form->getErrors()); die();
            }
        }

        $format = 'big';
        $provider = $this->get('sonata.media.provider.image');
        $format = $provider->getFormatName($media, $format);
        $url = $provider->generatePublicUrl($media, $format, true);

        $serializer = new Serializer(array(
            new GetSetMethodNormalizer()
        ), array(
            'json' => new JsonEncoder()
        ));

        $response = $serializer->serialize(array(
            'success' => true,
            'data' => array(
                'id' => $media->getId(),
                'name' => $media->getName(),
                'url' => $url
            )
        ), 'json');
        return new Response($response, 200, array('Content-Type' => 'application/json'));
    }

    public function ajaxSaveVideoAction(Request $request)
    {
        $options = array('provider' => 'sonata.media.provider.youtube', 'context' => 'wall');

        $media = new Media();
        $media->setContext('wall');
        $media->setProviderName('sonata.media.provider.youtube');
        $form = $this->createForm('sonata_media_type', $media, $options);
        // create the form
        $builder = $this->createFormBuilder($media);
        $em = $this->getDoctrine()->getManager();
        if ($request->getMethod() == 'POST') {
            $form->submit($request);
            if($form->isValid()){
                $em->persist($media);
                $em->flush();
            } else {
                var_dump($form->getErrors()); die();
            }
        }

        $format = 'big';
        $provider = $this->get('sonata.media.provider.youtube');
        $format = $provider->getFormatName($media, $format);
        $url = $provider->generatePublicUrl($media, $format, true);

        $serializer = new Serializer(array(
            new GetSetMethodNormalizer()
        ), array(
            'json' => new JsonEncoder()
        ));

        $response = $serializer->serialize(array(
            'success' => true,
            'data' => array(
                'id' => $media->getId(),
                'name' => $media->getName(),
                'url' => $url,
                'link' => $media->getBinaryContent()
            )
        ), 'json');
        return new Response($response, 200, array('Content-Type' => 'application/json'));
    }

    public function ajaxSaveStatsAction(Request $request)
    {
        // $options = array('provider' => 'sonata.media.provider.stats', 'context' => 'wall');
        $media = new Media();
        $media->setContext('wall');
        return $this->redirect($this->generateUrl('msp_dashboard_my_sport_page'));
    }

    public function ajaxGetGameStatsFormAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        $sport = $em->getRepository('MSPBundle:Sport')->findOneBy(array('id' => $request->get('id')));

        if(!$sport){
            $sport = $user->getMainSport();
        }
        // if no sport or not athlete redirect
        if(!$user->hasGroup('athlete') || !$sport){
            return $this->r($this->generateUrl('msp_dashboard_my_profile_my_personal_information'));
        }
        $sportStats = $sport->getSportStats();
        $game = new Game();
        $game->setSport($sport);
        foreach($sportStats as $stat){
            $gameStatValue = new GameStatValue();
            $gameStatValue->setSportStat($stat);
            $gameStatValue->setGame($game);
            $gameStatValue->setUser($user);
            $game->addGameStatValue($gameStatValue);
        }
        $form = $this->createForm(new GameStatFormType(), $game);
        return $this->render('MSPBundle:Dashboard:Forms/ajaxGetGameStatsForm.html.twig', array('form'=>$form->createView()));
    }

    public function ajaxCheerPostAction($id)
    {
        $user = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $post = $em->getRepository('MSPBundle:WallPost')->findOneBy(array('id' => $id));

        if(!$post->getCheerUsers()->contains($user)){
            $post->addCheerUser($user);
            $post->setCheerCount($post->getCheerCount() + 1);
            $em->persist($post);
            $em->flush();        
        }

        return $this->render('MSPBundle:Dashboard:Partials/cheers.html.twig', array('post_id'=>$post->getId(), 'cheer_count' =>  $post->getCheerCount()));
    }

    public function ajaxThumbsUpAction($id)
    {
        $user = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $comment = $em->getRepository('MSPBundle:WallComment')->findOneBy(array('id' => $id));

        if($comment && !$comment->getThumbsUpUsers()->contains($user)){
            $comment->addThumbsUpUser($user);
            $comment->setThumbsUpCount($comment->getThumbsUpCount() + 1);
            if($comment->getThumbsDownUsers()->contains($user)){
                $comment->removeThumbsDownUser($user);
                $comment->setThumbsDownCount($comment->getThumbsDownCount() - 1);
            }
            $em->persist($comment);
            $em->flush();
        }
        return $this->render('MSPBundle:Dashboard:Partials/thumbsUp.html.twig', array('comment_id'=>$comment->getId(), 'thumbs_up_count' =>  $comment->getThumbsUpCount()));
    }

    public function ajaxThumbsDownAction($id)
    {
        $user = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $comment = $em->getRepository('MSPBundle:WallComment')->findOneBy(array('id' => $id));

        if($comment && !$comment->getThumbsDownUsers()->contains($user)){
            $comment->addThumbsDownUser($user);
            $comment->setThumbsDownCount($comment->getThumbsDownCount() + 1);
            if($comment->getThumbsUpUsers()->contains($user)){
                $comment->removeThumbsUpUser($user);
                $comment->setThumbsUpCount($comment->getThumbsUpCount() - 1);
            }
            $em->persist($comment);
            $em->flush();
        }
        return $this->render('MSPBundle:Dashboard:Partials/thumbsDown.html.twig',
            array('comment_id'=>$comment->getId(), 'thumbs_down_count' =>  $comment->getThumbsDownCount()));
    }

    public function getUserTeamSeasonForGame(Game $game)
    {
        $em = $this->getDoctrine()->getManager();
        $year = date_format($game->getDatetimeStart(), 'Y');
        $userTeamSeason = $em->getRepository('MSPBundle:UserTeamSeason')->findOneBy(array('user' => $this->getUser(), 'year' => $year, 'team'=>$game->getHomeTeam()));

        if(!$userTeamSeason){
            $userTeamSeason = new UserTeamSeason();
            $userTeamSeason->setYear($year);
            $userTeamSeason->setSport($game->getHomeTeam()->getSport());
            $userTeamSeason->setUser($game->getCreator());
            $userTeamSeason->setTeam($game->getHomeTeam());
            $userTeamSeason->setSeason($game->getHomeTeam()->getSport()->getSeason());
            $userTeamSeason->setTeamName($game->getHomeTeam()->getName());
            $userTeamSeason->setLevel('Varsity');
            $em->persist($userTeamSeason);
            $em->flush();
        }
        return $userTeamSeason;
    }

    /* function to convert existing height into inches */
    public function convertDataAction()
    {
        $em = $this->getDoctrine()->getManager();
        $users    = $em->getRepository('MSPBundle:User')->findAll();
        foreach($users as $user){
            echo '<li>'.$user->getHeight();
            $result = $user->getHeight();
            if (strpos($user->getHeight(), "'") !== false) {
                // echo '<li>'.$user->getHeight()
                $value = $user->getHeight();
                $value = str_replace('-', '', $value);
                $data = str_replace('"', '', $value);
                $dataParts = explode("'", $data);
                $result1 = $dataParts[0]*12+$dataParts[1];
                echo '<li>'.$user->getHeight().'##'.$result1;
                $user->setHeight($result1);
                $em->persist($user);
                $em->flush();
            }
            if (strpos($user->getHeight(), ".") !== false) {
                // echo '<li>'.$user->getHeight()
                $value = $user->getHeight();
                $value = str_replace('-', '', $value);
                $data = str_replace('"', '', $value);
                $dataParts = explode(".", $data);
                $result1 = $dataParts[0]*12+$dataParts[1];
                echo '<li>'.$user->getHeight().'##'.$result1;
                $user->setHeight($result1);
                $em->persist($user);
                $em->flush();
            }
            if (strlen(trim($user->getHeight())) == 1) {
                $result1 = $user->getHeight()*12;
                echo '<li>'.$user->getHeight().'##'.$result1;
                $user->setHeight($result1);
                $em->persist($user);
                $em->flush();
            }
            if (strpos($user->getHeight(), "-") !== false) {
                // echo '<li>'.$user->getHeight()
                $value = $user->getHeight();
                $value = str_replace('-', '', $value);
                if(strlen(trim($value))==1){
                    $result1 = $value*12;
                    echo '<li>'.$user->getHeight().'##'.$result1;
                    $user->setHeight($result1);
                    $em->persist($user);
                    $em->flush();
                }else{
                    $data = str_replace('"', '', $value);
                    $dataParts = explode(".", $data);
                    $result1 = $dataParts[0]*12+$dataParts[1];
                    echo '<li>'.$user->getHeight().'##'.$result1;
                    $user->setHeight($result1);
                    $em->persist($user);
                    $em->flush();
                }                
            }
            if (strpos($user->getHeight(), "feet") !== false) {
                // echo '<li>'.$user->getHeight()
                $value = $user->getHeight();
                $value = str_replace('feet', '', $value);
                if(strlen(trim($value))==1){
                    $result1 = $value*12;
                    echo '<li>'.$user->getHeight().'##'.$result1;
                    $user->setHeight($result1);
                    $em->persist($user);
                    $em->flush();
                }else{
                    $data = str_replace('"', '', $value);
                    $dataParts = explode(".", $data);
                    $result1 = $dataParts[0]*12+$dataParts[1];
                    echo '<li>'.$user->getHeight().'##'.$result1;
                    $user->setHeight($result1);
                    $em->persist($user);
                    $em->flush();
                }                
            }
        }
        die;
    }
}
