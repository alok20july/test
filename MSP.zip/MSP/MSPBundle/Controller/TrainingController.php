<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 5/20/14
 * Time: 5:56 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Controller;
use MSP\MSPBundle\Entity\KeyMeasurableValue;
use MSP\MSPBundle\Entity\TrainingSession;
use MSP\MSPBundle\Entity\KeyMeasurable;
use MSP\MSPBundle\Entity\UserKeyMeasurableSession;
use MSP\MSPBundle\Form\KeyMeasurablesType;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use Application\Sonata\MediaBundle\Entity\Media;
use Symfony\Component\Form\DataTransformerInterface;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;

class TrainingController extends Controller implements InitializableControllerInterface
{

    private $user;

    public function initialize(Request $request, SecurityContextInterface $security_context)
    {
        if (!$user = $this->getUser()) {
            return true;
        }else{
            return false;
        }
    }

    public function indexAction()
    { 
        $em       = $this->getDoctrine()->getManager();
        $user     = $this->getUser();

        $sessions = array();
        $trainingSessions = $em->getRepository('MSPBundle:TrainingSession')->findBy(array(), array('sessionCreated'=>'desc'));     
        foreach($trainingSessions as $trainingSession){
            $keyMeasurableValue = $em->getRepository('MSPBundle:KeyMeasurableValue')->findBy(array('user' => $user, 'keyTrainingSession' => $trainingSession->getId()));
            if($keyMeasurableValue) $sessions[$trainingSession->getSessionCreated()->format('Y-m-d').'#'.$trainingSession->getId()] = $keyMeasurableValue;
        }

        $em = $this->getDoctrine()->getManager();
        $keyMeasurableSessions = $em->getRepository('MSPBundle:UserKeyMeasurableSession')->getUserSessionChart($user);

        $charts = array();
        if($keyMeasurableSessions){
            foreach($keyMeasurableSessions as $keyMeasurableSession){
                $measurableName = str_replace(' ', '_', $keyMeasurableSession->getKeyMeasurable()->getName());
                if(!array_key_exists($measurableName, $charts)){
                    $$measurableName = '["'.$keyMeasurableSession->getKeyTrainingSession()->getSessionCreated()->format('Y-m-d').'",'.$keyMeasurableSession->getValue().']';
                }else{
                    $$measurableName .= ',["'.$keyMeasurableSession->getKeyTrainingSession()->getSessionCreated()->format('Y-m-d').'",'.$keyMeasurableSession->getValue().']';
                }   
                $charts[$measurableName] = '['.$$measurableName.']';
            }
        }else{
            $userKeyMeasurableSessions = $em->getRepository('MSPBundle:UserKeyMeasurableSession')->findBy(array('user' => $user, 'isStatus' => 1));
            foreach($userKeyMeasurableSessions as $userKeyMeasurableSession){
                $em = $this->getDoctrine()->getManager();
                $userKeyMeasurableSession->setIsStatus(0); 
                $em->flush();
            }
        }
        
        $keyMeasurables = $em->getRepository('MSPBundle:KeyMeasurable')->findBy(array('isPhysical' => 1));
        $keyMeasurableValues = $em->getRepository('MSPBundle:KeyMeasurableValue')->findBy(array('user' => $user, 'keyTrainingSession' => null));
        // exit(\Doctrine\Common\Util\Debug::dump($keyMeasurableValues));
        return $this->render('MSPBundle:Training:index.html.twig', array('sessions'=>$sessions, 'charts' => $charts, 'keyMeasurables' => $keyMeasurables, 'keyMeasurableValues' => $keyMeasurableValues));    
    }

    /*
     * function to add user training 
     */
    public function addUserTrainingAction()
    {   
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        $trainingSession = new TrainingSession();
        $form = $this->createForm('msp_user_session_keymeasurables', $trainingSession);

        $keyMeasurables = $this->getDoctrine()->getRepository('MSPBundle:KeyMeasurable')->getUserKeyMeasurableList($user);
        
        if ($request->getMethod() == 'POST'){                   
            $form->submit($request);
            if ($form->isValid()){               
                $em->persist($trainingSession);
                $em->flush();                
                $trainingId = $trainingSession->getId();
                $trainingSess = $em->getRepository('MSPBundle:TrainingSession')->findOneBy(array('id' => $trainingId));
                foreach($request->request->get('value') as $key => $value){                    
                    if($value != '' ){
                        $em = $this->getDoctrine()->getManager();
                        $keyMeasurableValue = new KeyMeasurableValue();
                        $keyMeasurable = $em->getRepository('MSPBundle:KeyMeasurable')->findOneBy(array('id' => $key));
                        $keyMeasurableValue->setUser($user);
                        $keyMeasurableValue->setKeyMeasurable($keyMeasurable);
                        $keyMeasurableValue->setTrainingSession($trainingSess);
                        $keyMeasurableValue->setValue($value);
                        $em->persist($keyMeasurableValue);
                        $em->flush(); 
                    }                    
                }
                return $this->redirect($this->generateUrl('msp_training')); 
            }
        }        
        return $this->render('MSPBundle:Training:measurable.html.twig',
            array('form' => $form->createView(), 'keyMeasurables' => $keyMeasurables));
    }

    /*
     * function to update user session
     */
    public function updateUserSessionAction($id)
    {

        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();

        $options = array('em' => $em);
        $value = $em->getRepository('MSPBundle:KeyMeasurableValue')->findOneBy(array('id' => $id));

        if (!$value) {
            $return = array("responseCode"=>200, "message"=>"data not found!");
        }

        $options['keyMeasurable'] = $value->getKeyMeasurable();
        $form = $this->createForm('msp_user_session_keymeasurables', $value, $options);

        if ($request->getMethod() == 'POST')
        {
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                $return = array("responseCode"=>400, "message"=>"Updated succesfully !");
            }else{
                $return = array("responseCode"=>400, "message"=>"Error in update !");
            }
        }
        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));      
    }

    /*
     * function to insert user training session
     */
    public function insertUserSessionAction()
    {
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $value = new KeyMeasurableValue();
        $value->setUser($this->getUser());
        $form = $this->createForm('msp_user_session_keymeasurables', $value, $options);

        if ($request->getMethod() == 'POST')
        {
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                $return = array("responseCode"=>400, "message"=>"Created succesfully !");
            }
            else{
                $return = array("responseCode"=>400, "message"=>"Error in update !");
            }
        }
        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));   
    }

    public function getKeyMeasurableListAction()
    {
        $em       = $this->getDoctrine()->getManager();
        $user     = $this->getUser();

        $keyMeasurables = $em->getRepository('MSPBundle:KeyMeasurable')->getUserKeyMeasurableList($user);     
        foreach($keyMeasurables as $keyMeasurable){
            $userKeyMeasurableSession = $em->getRepository('MSPBundle:UserKeyMeasurableSession')->findBy(array('user'=>$user, 'keyMeasurable'=>$keyMeasurable));
            if(!$userKeyMeasurableSession){
                $em = $this->getDoctrine()->getManager();
                $keyMeasurableSession = new UserKeyMeasurableSession();
                $keyMeasurableSession->setUser($user);
                $keyMeasurableSession->setKeyMeasurable($keyMeasurable);
                $keyMeasurableSession->setIsStatus(0);
                $em->persist($keyMeasurableSession);
                $em->flush(); 
            }
        }
        $keyMeasurableSession = $em->getRepository('MSPBundle:UserKeyMeasurableSession')->getChartListByUser($user);
        return $this->render('MSPBundle:Training:listMeasurable.html.twig',
            array('keyMeasurableSession' => $keyMeasurableSession));
    }

    public function updateKeyMeasurableListAction()
    {
        // get key measurable id & value
        $request    = $this->get('request');
        $measurable_id   = $request->get('measurable_id');
        $value   = $request->get('value');
        $value   = ($value == 0 || $value == null) ? 1 : 0;

        // get key measurable object
        $em = $this->getDoctrine()->getManager();
        $keyMeasurableSession = $em->getRepository('MSPBundle:UserKeyMeasurableSession')->find($measurable_id);

        if (!$keyMeasurableSession) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !", "value" => $request->get('value'));
        }

        if ($request->getMethod() == 'POST') {
            $keyMeasurableSession->setIsStatus($value);
            $em->flush();
            $return = array("responseCode"=>400, "message"=>"Updated value succesfully", "value" => $value);
        }
        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }

    public function ajaxDeleteUserSessionAction($sessionId){

        $request    = $this->get('request');
        $user     = $this->getUser();
        $em = $this->getDoctrine()->getManager();
        $keyMeasurableValues = $em->getRepository('MSPBundle:KeyMeasurableValue')->findBy(array('user'=>$user, 'keyTrainingSession'=>$sessionId));

        if (!$keyMeasurableValues) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !");
        }

        if ($request->getMethod() == 'POST') {
            foreach($keyMeasurableValues as $keyMeasurableValue){
                $em = $this->getDoctrine()->getManager();
                $em->remove($keyMeasurableValue);
                $em->flush();
            }            
            $return = array("responseCode"=>400, "message"=>"Delete value succesfully", 'value' => $sessionId);
        }
        $response = json_encode($return); // jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }

    public function ajaxUpdateSessionPhysicalAttrAction($id){

        $request = $this->get('request');
        $value = $request->get('value');
        $em = $this->getDoctrine()->getManager();

        $keyMeasurableValue = $em->getRepository('MSPBundle:KeyMeasurableValue')->findOneBy(array('id' => $id));

        if (!$keyMeasurableValue) {
            $return = array("responseCode"=>200, "message"=>"data not found!");
        }

        if ($request->getMethod() == 'POST') {
            $keyMeasurableValue->setValue($value);
            $em->flush();
            $return = array("responseCode"=>400, "message"=>"Updated value succesfully");
        }else{
            $return = array("responseCode"=>400, "message"=>"Error in update !");
        }

        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));        
    } 

    public function addPhysicalAttributeAction()
    {   
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        // print_r($request->request->get('value')); die;
        if ($request->getMethod() == 'POST'){
            if($request->request->get('action') == 'insert'){  
                foreach($request->request->get('value') as $key => $value){      
                    $value = ($value == null) ? 0 : $value;              
                    $em = $this->getDoctrine()->getManager();
                    $keyMeasurableValue = new KeyMeasurableValue();
                    $keyMeasurable = $em->getRepository('MSPBundle:KeyMeasurable')->findOneBy(array('id' => $key));
                    $keyMeasurableValue->setUser($user);
                    $keyMeasurableValue->setKeyMeasurable($keyMeasurable);
                    $keyMeasurableValue->setValue($value);
                    $em->persist($keyMeasurableValue);
                    $em->flush();                   
                }
            }
            else if($request->request->get('action') == 'update'){  
                foreach($request->request->get('value') as $key => $value){  
                    $value = ($value == null) ? 0 : $value;       
                    $em = $this->getDoctrine()->getManager();
                    $keyMeasurableValue = $em->getRepository('MSPBundle:KeyMeasurableValue')->findOneBy(array('id' => $key));
                    $keyMeasurableValue->setValue($value);
                    $em->persist($keyMeasurableValue);
                    $em->flush();
                }
            }
            return $this->redirect($this->generateUrl('msp_training'));   
        } 
        return $this->redirect($this->generateUrl('msp_training'));               
    }   
}