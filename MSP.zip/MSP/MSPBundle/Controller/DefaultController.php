<?php

namespace MSP\MSPBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use MSP\MSPBundle\Entity;
use MSP\MSPBundle\Admin;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use MSP\MSPBundle\Entity\Logo;


class DefaultController extends Controller
{

    public function homepageAction()
    {
        $user = $this->getUser();
        if($user){
           return $this->redirect($this->generateUrl('msp_dashboard_my_sport_page'));
        }
        return $this->render('MSPBundle:Default:homepage.html.twig');
    }

    public function findSchoolsAction()
    {
        return $this->render('MSPBundle:Default:findSchools.html.twig');
    }

    public function resourcesAction()
    {
        return $this->render('MSPBundle:Default:resources.html.twig');
    }

    public function faqAction()
    {
        return $this->render('MSPBundle:Default:faq.html.twig');
    }

    public function aboutUsAction()
    {
        return $this->render('MSPBundle:Default:aboutUs.html.twig');
    }

    public function contactUsAction()
    {
        return $this->render('MSPBundle:Default:contactUs.html.twig');
    }
    
    public function loginAction()
    {
        return $this->render('MSPBundle:Default:login.html.twig');
    }
    
    public function newLayoutAction()
    {
        return $this->render('MSPBundle:Default:newLayout.html.twig');
    }

    public function newHomepageAction()
    {
        return $this->render('MSPBundle:Default:newHomepage.html.twig');
    }
}
