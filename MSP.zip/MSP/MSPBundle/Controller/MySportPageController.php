<?php
/**
 * Used for the public profile page (mySportPage)
 * User: soumaouche
 * Date: 3/27/14
 * Time: 2:36 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use MSP\MSPBundle\Form\ProfileImage;
use MSP\MSPBundle\Form\HeaderImage;
use Application\Sonata\MediaBundle\Entity\Media;
use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;
use Symfony\Component\HttpFoundation\Response;

class MySportPageController extends Controller // implements InitializableControllerInterface
{
    private $user;

    // public function initialize(Request $request, SecurityContextInterface $security_context)
    // {
    //     if (!$user = $this->getUser()) {
    //         return true;
    //     }else{
    //         return false;
    //     }
    // }

    public function indexAction()
    {
        // init
        $userRepo = $this->getDoctrine()->getRepository('MSPBundle:User');
        $user = $userRepo->findOneBy(array('slug' => $this->getRequest()->get('slug')));

        // $user = $this->getUser();
        if (!$user) {
            $user = $this->getUser();
            if(!$user){
                throw $this->createNotFoundException('User Does Not Exist');
            }
        }

        $mainTeamSeason = $userRepo->getMainTeamSeasonForUser($user);

        $teamLogo = null;
        $sport = null;
        $position = null;
        $jerseyNumber = null;
        $schoolName = null;
        $schoolState = null;
        $schoolCity = null;
        if($mainTeamSeason){
            // userTeamSeason for no team sports doesn't have a team.
            if($mainTeamSeason->getTeam()){
                $teamLogo = $mainTeamSeason->getTeam()->getLogo();
            }
            $sport = $mainTeamSeason->getSport()->getName();
            $position = $mainTeamSeason->getSportPositions()->first();
            $jerseyNumber = $mainTeamSeason->getJerseyNumber();
        }


        if($user->getSchool()){
            $school = $user->getSchool();
        }elseif($mainTeamSeason){
            $school = $mainTeamSeason->getSchool();
        }else{            
            $school = '';
        }

        if($school){
            $schoolName = $school->getName();
            $schoolState = $school->getState();
            $schoolCity = $school->getCity();
        }else{
            $schoolName = '';
            $schoolState = '';
            $schoolCity = '';
        }

        $header = array(
            'mspHeaderImage' => $user->getMspHeaderImage(),
            'avatar' => $user->getImage(),
            'firstName' => $user->getFirstname(),
            'lastName' => $user->getLastname(),
            'schoolName' => $schoolName,
            'schoolCity' => $schoolCity,
            'schoolState' => $schoolState,
            'city' => $schoolCity,
            'state' => $schoolState,
            'sport' => $sport,
            'position' => $position,
            'gender' => $user->getGender(),
            'age'    => $user->getAge(),
            'height' => $user->getHeight(),
            'weight' => $user->getWeight(),
            'jerseyNumber' => $jerseyNumber,
            'class' => $user->getClass(),
            'bio'    => $user->getBio(),
            'teamLogo' => $teamLogo,
        );

        $newsFeeds = $userRepo->getLastWallPostsForUser($user, 3);

        // get user's msp gallery to display at top
        $mspGallery  = $this->getDoctrine()->getManager()->getRepository('MSPBundle:UserMedia')->getUserMediaById($user, 1);
        // $mspGallery = $user->getMspGallery();

        $seasonStats = $userRepo->getSeasonStatsForUser($user);

        $userTeamSeasons = $user->getUserTeamSeason();

        $userAcademics = $user->getUserAcademicInformation();

        // $userKeyMeasurables = $user->getKeyMeasurableValues();

        $userKeyMeasurables = $this->getDoctrine()->getManager()->getRepository('MSPBundle:KeyMeasurableValue')->findBy(array('user' => $user, 'keyTrainingSession' => null));

        // get user training session list 
        $userTrainingSessions = array();
        $trainingSessions = $this->getDoctrine()->getManager()->getRepository('MSPBundle:TrainingSession')->findBy(array(), array('sessionCreated'=>'desc'));     
        foreach($trainingSessions as $trainingSession){
            $keyMeasurableValue = $this->getDoctrine()->getManager()->getRepository('MSPBundle:KeyMeasurableValue')->findBy(array('user' => $user, 'keyTrainingSession' => $trainingSession->getId()));
            if($keyMeasurableValue) $userTrainingSessions[] = $keyMeasurableValue;
        }

        $profileImage = new ProfileImage();
        $user->setImage($user->getImage());
        $profileImage = $this->createForm($profileImage, $user);

        $headerImage = new HeaderImage();
        $user->setMspHeaderImage($user->getMspHeaderImage());
        $headerImage = $this->createForm($headerImage, $user);

        return $this->render('MSPBundle:MySportPage:index.html.twig', array(
            'header' => $header,
            'newsFeeds' => $newsFeeds,
            'mspGallery' => $mspGallery,
            'seasonStats' => $seasonStats,
            'userAcademics' => $userAcademics,
            'userTeamSeasons' => $userTeamSeasons,
            'userKeyMeasurables' => $userKeyMeasurables,
            'user' => $user,
            'profileImage' => $profileImage->createView(),
            'headerImage' => $headerImage->createView(),
            'userTrainingSessions' => $userTrainingSessions
        ));
    }


    public function renderSeasonStatAction()
    {
        $seasonStats = array();
        $gameStats = array();
        $uts = $this->getRequest()->get('uts');
        /* @var $uts UserTeamSeason
         */
        $tmpSeasonStats = $uts->getApplicableSeasonStats();
        $seasonStatValues = $this->getDoctrine()->getRepository('MSPBundle:UserTeamSeason')->getAllSeasonStatsValues($uts);

        // all season stat value needs to be added to the array.
        foreach($seasonStatValues as $ssv){
                if($ssv->getSportStat()->getSportStatGroup()){
                    if(isset($seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()])){
                        $seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()]['values'][$ssv->getSportStat()->getAbbrev()] = $ssv;
                    }else{
                        $seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()] = array(
                            'seasonStatGroup' => $ssv->getSportStat()->getSportStatGroup(),
                            'values' => array($ssv->getSportStat()->getAbbrev() => $ssv)
                        );
                    }
                }
        }

        // if some season stats are empty. We still show the labels and empty value
        foreach($tmpSeasonStats as $seasonStat){
            if($seasonStat->getSportStatGroup()){
                // if the stat group doesn't exist create it.
                if(!isset($seasonStats[$seasonStat->getSportStatGroup()->getId()])){
                    $seasonStats[$seasonStat->getSportStatGroup()->getId()] = array('seasonStatGroup' => $seasonStat->getSportStatGroup(),
                        'values' => array($seasonStat->getAbbrev() => null));
                }elseif(!isset($seasonStats[$seasonStat->getSportStatGroup()->getId()]['values'][$seasonStat->getAbbrev()])){
                    $seasonStats[$seasonStat->getSportStatGroup()->getId()]['values'][$seasonStat->getAbbrev()] = null;
                }
            }
        }

        if($uts->getSport()->getIsTeamSport()){
            // Team Sports will have games.
            $tmpGameStats = $uts->getApplicableGameStats();
            $games = $uts->getGames();

            if($games){
                foreach($games as $game){
                    $gameStatValues = $game->getGameStatValuesForUser($uts->getUser());

                    // first add all the game stat value users stored.
                    foreach($gameStatValues as $gsv){
                        $sportStatGroup = $gsv->getSportStat()->getSportStatGroup();
                        $sportStat = $gsv->getSportStat();
                        if($sportStatGroup){
                            if(!isset($gameStats[$game->getId()])){
                                $gameStats[$game->getId()] = array(
                                    'game' => $game,
                                    'stats' => array($sportStatGroup->getId() => array($sportStat->getAbbrev() => $gsv->getValue()))
                                );
                            }else{
                                if(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()])){
                                    $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()] = array($sportStat->getAbbrev() => $gsv->getValue());
                                }else{
                                    $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$sportStat->getAbbrev()] = $gsv->getValue();
                                }
                            }
                        }                        
                    }

                    // add game stats that should be provided but are not with empty value.
                    foreach($tmpGameStats as $gs){
                        $sportStatGroup = $gs->getSportStatGroup();

                        if($sportStatGroup){
                            if(!isset($gameStats[$game->getId()])){
                                $gameStats[$game->getId()] = array(
                                    'game' => $game,
                                    'stats' => array($sportStatGroup->getId() => array($gs->getAbbrev() => null))
                                );
                            }elseif(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()])){
                                $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()] = array($gs->getAbbrev() => null);
                            }elseif(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getAbbrev()])){
                                $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getAbbrev()] = null;
                            }
                        }
                    }
                }
            }
        }else{
            // @todo handle individual sports

        }

        return $this->render('MSPBundle:Component:renderSeasonStat.html.twig',
            array('seasonStats' => $seasonStats, 'uts' => $uts, 'gameStats' => $gameStats));
    }

    public function ajaxUploadUserProfileImageAction(Request $request){

        $user = $this->getUser();
        $form = new ProfileImage();
        $user->setImage($user->getImage());
        $form = $this->createForm($form, $user);
        $request = $this->get('request');
        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($user);
                $em->flush();
                return $this->redirect($this->generateUrl('my_sport_page_athlete', array('slug' => $user->getSlug())));
            }
            return $this->redirect($this->generateUrl('my_sport_page_athlete', array('slug' => $user->getSlug())));
        }
    }

    public function ajaxUploadUserHeaderImageAction(Request $request){

        $user = $this->getUser();
        $form = new HeaderImage();
        $user->setMspHeaderImage($user->getMspHeaderImage());
        $form = $this->createForm($form, $user);
        $request = $this->get('request');

        if ($request->getMethod() == 'POST'){            
            $form->submit($request);
            if ($form->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($user);
                $em->flush();
                return $this->redirect($this->generateUrl('my_sport_page_athlete', array('slug' => $user->getSlug())));
            }
            return $this->redirect($this->generateUrl('my_sport_page_athlete', array('slug' => $user->getSlug())));
        }
    }


    /* function to render game stat value */
    public function renderWallGameStatsAction(){
        $gameStats = array();
        $gameAbbrValues = array();
        $game = $this->getRequest()->get('game');
        $gameStatValues = $game->getGameStatValuesForUser($game->getCreator());
        $tmpGameStats = $game->getUserTeamSeason()->getApplicableGameStats();
        foreach($gameStatValues as $gsv){
            $sportStat = $gsv->getSportStat(); 
            if($sportStat->getSportStatGroup()){ 
                if(!$sportStat->getIsCalculation() && !$sportStat->getIsHidden()){
                    $gameStats[$sportStat->getSportStatGroup()->getId()][$sportStat->getSortorder()][$sportStat->getAbbrev().'#'.$sportStat->getTooltip()] = $gsv->getValue();
                }  
                $gameAbbrValues[$sportStat->getAbbrev()] = $gsv->getValue();
            }         
        }

        foreach($tmpGameStats as $gs){
            if($gs->getSportStatGroup()){
                if($gs->getIsCalculation() && !$gs->getIsHidden()){
                    // $parts = explode(',', $sportStat->getParameters());
                    $methodName = $gs->getMethodName();
                    if(method_exists(new StatsCalculations(), $methodName)){
                        $result = StatsCalculations::$methodName($gameAbbrValues, $gs->getParameters());
                        $gameStats[$gs->getSportStatGroup()->getId()][$gs->getSortorder()][$gs->getAbbrev().'#'.$gs->getTooltip()] = $result;    
                    }                    
                }
                if(isset($gameStats[$gs->getSportStatGroup()->getId()]) && $gameStats[$gs->getSportStatGroup()->getId()]){
                    ksort($gameStats[$gs->getSportStatGroup()->getId()]);
                }
            }            
        }
        // exit(\Doctrine\Common\Util\Debug::dump($gameStats));
        return $this->render('MSPBundle:Dashboard/Partials:renderGameStats.html.twig',
            array('gameStats' => $gameStats, 'game' => $game));
    }
}