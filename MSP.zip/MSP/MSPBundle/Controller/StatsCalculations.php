<?php

namespace MSP\MSPBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class StatsCalculations
{

    static $calculationMethod = array(
        'calculateFieldPercentage' => 'calculateFieldPercentage:Use this method to calculate percentages, arg2 * 100 / arg1',
        'calculateFieldSum' => 'calculateFieldSum:Use this to sum up fields'
    );

    public static function calculateFieldPercentage($array, $params)
    {
    	$data = explode(',', $params);

    	for($i = 0; $i < count($data); $i++){
    		if(!array_key_exists(trim($data[$i]),$array)){
    			return false;
    		}
    	}
        // print_r($array);
        if($array[trim($data[0])] <= 0)
            return false;
        // @todo careful with division by 0. This needs to be fixed, also you can add the sign "%"
    	return round(($array[trim($data[1])]*100/$array[trim($data[0])]), 2).'%'; 
    }

    public static function calculateFieldSum($array, $params)
    {
    	$sum = 0;
    	$data = explode(',', $params);
    	for($i = 0; $i < count($data); $i++){
    		if(!array_key_exists(trim($data[$i]), $array)){
    			// return false;
    		}else{
    			$sum += $array[trim($data[$i])];
    		}
    	}
    	return $sum;
    }
}
