<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 14/05/14
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */
namespace MSP\MSPBundle\Controller;
use MSP\MSPBundle\Form\MediaType;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Application\Sonata\MediaBundle\Entity\Media;
use Application\Sonata\MediaBundle\Entity\Gallery;
use MSP\MSPBundle\Entity\UserMedia;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Form\AbstractType;

use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;

class GalleryController extends Controller implements InitializableControllerInterface
{
    private $user;

    public function initialize(Request $request, SecurityContextInterface $security_context)
    {
        if (!$user = $this->getUser()) {
            return true;
        }else{
            return false;
        }
    }

    /*
    * display the UserMedia and MSP Media gallery list
    */
	public function indexAction()
    {
        $user = $this->getUser();

        $userMedia = new UserMedia();
        $userMedia->setUser($user);

        // creaet media image & video form
        $mediaImageForm = $this->createForm('msp_media_type', $userMedia); 
        $mediaVideoForm = $this->createForm('msp_media_type', $userMedia);

        $em = $this->getDoctrine()->getManager();
        
        // get user's msp gallery to display at top  
        $mspGallery    = $em->getRepository('MSPBundle:UserMedia')->getUserMediaById($user, 1);

        // get user's main gallery to display at bottom
        $mainGallery = $em->getRepository('MSPBundle:UserMedia')->getUserMediaById($user, 0);

        return $this->render('MSPBundle:Gallery:index.html.twig',
            array(
                'mspGallery' => $mspGallery,
                'mainGallery' => $mainGallery,
                'mediaImageForm' => $mediaImageForm->createView(),
                'mediaVideoForm' => $mediaVideoForm->createView()
            )
        );
    }

    /*
    * This action is called when we click on post button to upload photo
    */
    public function uploadPhotoAction(Request $request)
    {
        $user = $this->getUser();
        $myMedia = new UserMedia();
        $myMedia->setUser($user);
        $mediaImageForm = $this->createForm('msp_media_type', $myMedia);     

        if ($request->getMethod() == 'POST')
        {              
            $mediaImageForm->submit($request);
            if ($mediaImageForm->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($myMedia);
                $em->flush();
            }          
            return $this->redirect($this->generateUrl('my_sport_page_media'));
        }
    }

    /*
    * This action is called when we click on post button to upload video
    */
    public function uploadVideoAction(Request $request)
    {        
        $user = $this->getUser();
        $myMedia = new UserMedia();
        $myMedia->setUser($user);
        $mediaVideoForm = $this->createForm('msp_media_type', $myMedia);     

        if ($request->getMethod() == 'POST')
        {              
            $mediaVideoForm->submit($request);
            if ($mediaVideoForm->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($myMedia);
                $em->flush();
            }          
            return $this->redirect($this->generateUrl('my_sport_page_media'));
        }
    }

    /*
    * This action is called via ajax when dragging and dropping the media file and save media in database.
    */
    public function addToMspGalleryAction()
    {
        // get media Id
        $request    = $this->get('request');
        $media_id   = $request->get('media_id');

        // get media object.
        $em = $this->getDoctrine()->getManager();
        $userMedia = $em->getRepository('MSPBundle:UserMedia')->find($media_id);

        if (!$userMedia) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !");
        }

        if ($request->getMethod() == 'POST') {
            // save & add media to mspGallery 
            // mspGallery - 1
            // mainGallery - 0
            $userMedia->setGalleryType(1);
            $em->flush();
            $return = array("responseCode"=>400, "message"=>"Added succesfully in user MSP gallery");
        }
        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }

    /*
    * This action is called via ajax when delete Main Gallery and MSP Gallery media
    */
    public function removeFromMspGalleryAction(){
        // get media Id & media type
        $request    = $this->get('request');
        $media_id   = $request->get('media_id');
        $media_type = $request->get('media_type');

        // get media object.
        $em = $this->getDoctrine()->getManager();
        $userMedia = $em->getRepository('MSPBundle:UserMedia')->find($media_id);

        if (!$userMedia) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !");
        }

        if ($request->getMethod() == 'POST') {
            if('mspgallery' == $media_type){                
                $userMedia->setGalleryType(0);
            }else{
                $em->remove($userMedia);
            }
            $em->flush();
            $return = array("responseCode"=>400, "message"=>"media removed successfully");
        }
        $response = json_encode($return); //json encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }
}
