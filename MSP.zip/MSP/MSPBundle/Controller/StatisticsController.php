<?php
/**
 * Created by Alok Kumar.
 * User: alok
 * Date: 17/05/14
 * Time: 5:15 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use MSP\MSPBundle\Entity;
use MSP\MSPBundle\Entity\SeasonStatValue;
use MSP\MSPBundle\Entity\UserTeamSeason;
use MSP\MSPBundle\Entity\GameStatValue;
use MSP\MSPBundle\Entity\User;
use MSP\MSPBundle\Entity\Game;
use MSP\MSPBundle\Entity\WallPost;
use MSP\MSPBundle\Entity\StatisticsSeasonResult;
use MSP\MSPBundle\Entity\UserSeasonGameStatValue;
use MSP\MSPBundle\Entity\UserSeasonStatValue;

use MSP\MSPBundle\Form;
use MSP\MSPBundle\Form\MediaType;
use MSP\MSPBundle\Form\WallType;
use MSP\MSPBundle\Form\GameStatFormType;
use MSP\MSPBundle\Form\GameStatsValuesFormType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\DataTransformerInterface;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;

class StatisticsController extends Controller implements InitializableControllerInterface
{

    private $user;

    public function initialize(Request $request, SecurityContextInterface $security_context)
    {
        if (!$user = $this->getUser()) {
            return true;
        }else{
            return false;
        }
    }

    /*
    * display the User Statistics
    */
	public function indexAction()
    {
        $user = $this->getUser();
        $userTeamSeasons = $user->getUserTeamSeason();
        $charts = array();
        $scharts = array();
        $startDate = array();
        $chartStartDate = null;
        foreach($userTeamSeasons as $uts){
            if($uts->getSport()->getIsTeamSport()){
                $games = $uts->getGames();
                if($games){
                    foreach($games as $game){
                        $gameStatValues = $game->getGameStatValuesForUser($uts->getUser());

                        foreach($gameStatValues as $gsv){
                            $sportStatGroup = $gsv->getSportStat()->getSportStatGroup();
                            $sportStat = $gsv->getSportStat();

                            if($sportStatGroup){
                                $userSeasonGameStatValue = $this->getDoctrine()->getRepository('MSPBundle:UserSeasonGameStatValue')->getUserSeasonGameStatus($gsv->getUser()->getId(), $gsv->getGame()->getUserTeamSeason()->getId(), $sportStatGroup->getId(), $sportStat->getId());
                                if($userSeasonGameStatValue){ 
                                    $startDate[] = strtotime($game->getDatetimeStart()->format('Y-m-d'));
                                    // echo '<li>'.$game->getDatetimeStart()->format('Y').'-Season-Points-'.str_replace(' ', '_', $sportStat->getName()).'-'.$sportStatGroup->getId();
                                    $abbrName = $game->getDatetimeStart()->format('Y').'-Season-Points-'.str_replace(' ', '_', $sportStat->getName()).'-'.$sportStatGroup->getId();
                                    $value = ($gsv->getValue()==null)?0:$gsv->getValue();
                                    
                                    if(!array_key_exists($abbrName, $charts)){
                                        $$abbrName = '["'.$game->getDatetimeStart()->format('Y-m-d').'",'.$value.']';
                                    }else{
                                        $$abbrName .= ',["'.$game->getDatetimeStart()->format('Y-m-d').'",'.$value.']';
                                    }
                                    $charts[$abbrName] = '['.$$abbrName.']';   
                                    $startDate = array_keys(array_count_values($startDate));
                                    asort($startDate); 
                                    // print_r($startDate);
                                }   
                            }                                                     
                        }
                    }
                }
                $i = 0;
                if($startDate){
                    foreach($startDate as $key => $value){
                        if($i == 0){
                            $chartStartDate = date('Y-m-d', $value);
                            break;
                        }
                    }            
                }   
            }

            $seasonStatValues = $this->getDoctrine()->getRepository('MSPBundle:UserTeamSeason')->getAllSeasonStatsValues($uts);

            // all season stat value needs to be added to the array.
            foreach($seasonStatValues as $ssv){
                if($ssv->getSportStat()->getSportStatGroup()){
                    // echo '<li>'.$ssv->getUser()->getId(), $ssv->getSportStat()->getId(), $uts->getSport()->getId();
                    $userSeasonStatValue = $this->getDoctrine()->getRepository('MSPBundle:UserSeasonStatValue')->getUserSeasonStatus($ssv->getUser()->getId(), $uts->getTeam()->getId(), $ssv->getSportStat()->getSportStatGroup()->getId(), $ssv->getSportStat()->getId());

                    if($userSeasonStatValue){
                        $abbrName = $uts->getTeam()->getId().'-Season-Points-'.str_replace(' ', '_', $ssv->getSportStat()->getName()).'-'.$ssv->getSportStat()->getId();
                        $value = ($ssv->getValue()==null)?0:$ssv->getValue();
                        
                        if(!array_key_exists($abbrName, $scharts)){
                            $$abbrName = '['.$uts->getYear().','.$value.']';
                        }else{
                            $$abbrName .= ',['.$uts->getYear().','.$value.']'; 
                        }   
                        $scharts[$abbrName] = '['.$$abbrName.']';                        
                    }
                }
            }
        }
        return $this->render('MSPBundle:Statistics:index.html.twig', array('userTeamSeasons' => $userTeamSeasons, 'charts' => $charts, 'scharts' => $scharts, 'startDate' => $chartStartDate));
    }

    /*
    * render user statistics page
    */
    public function renderSeasonStatAction()
    {
        $seasonAbbrValues = array();
        $gameAbbrValues = array();
        $seasonStats = array();
        $gameStats = array();
        $scharts = array();
        $uts = $this->getRequest()->get('uts');

        /* 
            @var $uts UserTeamSeason
        */
        $tmpSeasonStats = $uts->getApplicableSeasonStats();
        $seasonStatValues = $this->getDoctrine()->getRepository('MSPBundle:UserTeamSeason')->getAllSeasonStatsValues($uts);

        // all season stat value needs to be added to the array.
        foreach($seasonStatValues as $ssv){

            if(!$ssv->getSportStat()->getIsHidden()){
                if($ssv->getSportStat()->getSportStatGroup()){
                    if(isset($seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()])){
                        $seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()]['values'][$ssv->getSportStat()->getSortorder()][$ssv->getSportStat()->getAbbrev()] = $ssv->getValue();
                        //echo $ssv->getValue();
                    }else{
                        //echo $ssv->getValue();
                        $seasonStats[$ssv->getSportStat()->getSportStatGroup()->getId()] = array(
                            'seasonStatGroup' => $ssv->getSportStat()->getSportStatGroup(),
                            'values' => array($ssv->getSportStat()->getSortorder() => array($ssv->getSportStat()->getAbbrev() => $ssv->getValue())),
                            'status' => true
                        );                
                    }  

                    $userSeasonStatValue = $this->getDoctrine()->getRepository('MSPBundle:UserSeasonStatValue')->getUserSeasonStatus($ssv->getUser()->getId(), $uts->getId(), $ssv->getSportStat()->getSportStatGroup()->getId(), $ssv->getSportStat()->getId(), $uts->getSport()->getId());
                    if($userSeasonStatValue){
                        $abbrName = $uts->getTeam()->getId().'-Season-Points-'.str_replace(' ', '_', $ssv->getSportStat()->getName()).'-'.$ssv->getSportStat()->getId();
                        $value = ($ssv->getValue()==null)?0:$ssv->getValue();
                        
                        if(!array_key_exists($abbrName, $scharts)){
                            $$abbrName = '['.$uts->getYear().','.$value.']';
                        }else{
                            $$abbrName .= ',['.$uts->getYear().','.$value.']'; 
                        }   
                        $scharts[$abbrName] = '['.$$abbrName.']';                        
                    }                  
                }
            } 
            $seasonAbbrValues[trim($ssv->getSportStat()->getAbbrev())] = $ssv->getValue();           
        }


        // if some season stats are empty. We still show the labels and empty value
        foreach($tmpSeasonStats as $seasonStat){
            if(!$seasonStat->getIsHidden()){
                if($seasonStat->getSportStatGroup()){                
                    // if the stat group doesn't exist create it.
                    if(!isset($seasonStats[$seasonStat->getSportStatGroup()->getId()])){
                        $seasonStats[$seasonStat->getSportStatGroup()->getId()] = array(
                            'seasonStatGroup' => $seasonStat->getSportStatGroup(),
                            'values' => array($seasonStat->getSortorder() => array($seasonStat->getAbbrev() => null)),
                            'status' => false
                        );
                    }elseif(!isset($seasonStats[$seasonStat->getSportStatGroup()->getId()]['values'][$seasonStat->getSortorder()][$seasonStat->getAbbrev()])){
                        $seasonStats[$seasonStat->getSportStatGroup()->getId()]['values'][$seasonStat->getSortorder()][$seasonStat->getAbbrev()] = null;
                    }
                }
            }  
            if($seasonStat->getIsCalculation()){
                if($seasonStat->getSportStatGroup()){  
                    $methodName = $seasonStat->getMethodName();
                    if(method_exists(new StatsCalculations(), $methodName)){
                        $result = StatsCalculations::$methodName($seasonAbbrValues, $seasonStat->getParameters());
                        $seasonStats[$seasonStat->getSportStatGroup()->getId()]['values'][$seasonStat->getSortorder()][$seasonStat->getAbbrev()] = $result;
                    }   
                }                 
            }          
        }

        ksort($seasonStats[$seasonStat->getSportStatGroup()->getId()]['values']);

        $charts = array();
        if($uts->getSport()->getIsTeamSport()){
            // Team Sports will have games.
            $tmpGameStats = $uts->getApplicableGameStats();
            $games = $uts->getGames();
            
            if($games){
                foreach($games as $game){
                    $gameStatValues = $game->getGameStatValuesForUser($uts->getUser());

                    // first add all the game stat value users stored.
                    foreach($gameStatValues as $gsv){
                        $sportStatGroup = $gsv->getSportStat()->getSportStatGroup();
                        $sportStat = $gsv->getSportStat();
                        if($sportStatGroup){
                            if(!$sportStat->getIsHidden()){
                                if(!isset($gameStats[$game->getId()])){
                                    $gameStats[$game->getId()] = array(
                                        'game' => $game,
                                        'stats' => array($sportStatGroup->getId() => array($sportStat->getSortorder() => array($sportStat->getAbbrev() => $gsv->getValue()))
                                        )
                                    );
                                }else{
                                    if(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$sportStat->getSortorder()])){
                                        $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$sportStat->getSortorder()] = array(
                                            $sportStat->getAbbrev() => $gsv->getValue()
                                        );
                                    }else{
                                        $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$sportStat->getSortorder()][$sportStat->getAbbrev()] = $gsv->getValue();
                                    }
                                }
                            }
                            // echo '<li>'.$sportStat->getAbbrev().'##'.$gsv->getValue();
                            $gameAbbrValues[trim($sportStat->getAbbrev())] = $gsv->getValue();
                            
                            $userSeasonGameStatValue = $this->getDoctrine()->getRepository('MSPBundle:UserSeasonGameStatValue')->getUserSeasonGameStatus($gsv->getUser()->getId(), $gsv->getGame()->getUserTeamSeason()->getId(), $sportStatGroup->getId(), $sportStat->getId());
                            // echo '<li>'.$gsv->getGame()->getUserTeamSeason()->getId().'##'.$sportStatGroup->getId().'##'.$sportStat->getId();

                            if($userSeasonGameStatValue){
                                $abbrName = $game->getDatetimeStart()->format('Y').'-Season-Points-'.str_replace(' ', '_', $sportStat->getName()).'-'.$sportStatGroup->getId();
                                $value = ($gsv->getValue()==null)?0:$gsv->getValue();
                                
                                if(!array_key_exists($abbrName, $charts)){
                                    $$abbrName = '["'.$game->getDatetimeStart()->format('Y-m-d').'",'.$value.']';
                                }else{
                                    $$abbrName .= ',["'.$game->getDatetimeStart()->format('Y-m-d').'",'.$value.']'; 
                                }   
                                $charts[$abbrName] = '['.$$abbrName.']';                        
                            }
                        }   
                    }

                    // add game stats that should be provided but are not with empty value.
                    foreach($tmpGameStats as $gs){
                        // echo '<li>'.$gs->getIsHidden();
                        $sportStatGroup = $gs->getSportStatGroup();
                        if($sportStatGroup){
                            if(!$gs->getIsHidden()){
                                if(!isset($gameStats[$game->getId()])){
                                    $gameStats[$game->getId()] = array(
                                        'game' => $game,
                                        'stats' => array(
                                                $sportStatGroup->getId() => array($gs->getSortorder() => 
                                            array(
                                                    $gs->getAbbrev() => null
                                                )
                                            )
                                        )
                                    );
                                }elseif(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getSortorder()])){
                                    $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getSortorder()] = array(
                                        $gs->getAbbrev() => null
                                    );
                                }elseif(!isset($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getSortorder()][$gs->getAbbrev()])){
                                    $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getSortorder()][$gs->getAbbrev()] = null;
                                }
                            }
                            // echo '<li>'.$gs->getMethodName();
                            if($gs->getIsCalculation()){
                                // $parts = explode(',', $sportStat->getParameters());
                                $methodName = $gs->getMethodName();
                                if(method_exists(new StatsCalculations(), $methodName)){
                                    $result = StatsCalculations::$methodName($gameAbbrValues, $gs->getParameters());
                                    $gameStats[$game->getId()]['stats'][$sportStatGroup->getId()][$gs->getSortorder()][$gs->getAbbrev()] = $result;
                                }                    
                            }
                            ksort($gameStats[$game->getId()]['stats'][$sportStatGroup->getId()]);
                        }                        
                    }

                }
            }

        }else{
            // @todo handle individual sports
        }
        // exit(\Doctrine\Common\Util\Debug::dump($seasonStats));
        // print_r($seasonStats); die;
        return $this->render('MSPBundle:Statistics:renderSeasonStat.html.twig',
            array('seasonStats' => $seasonStats, 'uts' => $uts, 'gameStats' => $gameStats, 'charts' => $charts, 'scharts' => $scharts));
    }


    /*
    *  open edit form to edit the user team season value
    */
    public function editUserTeamSeasonAction($teamSeasonId, $teamSportGroupId){

        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();

        $userId = $user->getId();

        $options = array('em' => $em);
        $updateForms = array();
        $newForms = array();

        $teamSeason = $em->getRepository('MSPBundle:UserTeamSeason')->findOneBy(array('id' => $teamSeasonId));
        $sportStats = $teamSeason->getSport()->getSportStats();

        foreach ($sportStats as $stat)
        {
            if($stat->getSportStatGroup()){
                if($teamSportGroupId == $stat->getSportStatGroup()->getId() && !$stat->getIsCalculation()){
                // echo '<li>'.$this->getUser()->getId().'###'.$stat->getId().'###'.$teamSeason->getId();
                    $value = $this->getDoctrine()->getRepository('MSPBundle:GameStatValue')->getStatValueForTeamSeason($this->getUser(), $stat, $teamSeason);

                    $new = false;
                    if($value == null){
                        $value = new SeasonStatValue();
                        $value->setSportStat($stat);
                        $value->setUser($this->getUser());
                        $value->setUserTeamSeason($teamSeason);
                        $new = true;
                    }
                    $form = $this->createForm('msp_statistics_season_stat_type', $value, $options);
                    if(!$new){
                        $updateForms[] = $form->createView();
                    }
                    else{
                        $newForms[] = $form->createView();
                    }
                } 
            }                       
        }

        return $this->render('MSPBundle:Statistics:editSeasonStat.html.twig',
            array('teamSeason' => $teamSeason, 'updateForms' => $updateForms, 'newForms' => $newForms));
    }


    /*
    *  open add form form to edit the user team season value
    */
    public function addUserTeamSeasonAvgAction($teamSeasonId, $teamSportGroupId){
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        $statGroupLists = array();
        $teamSeason = $em->getRepository('MSPBundle:UserTeamSeason')->findOneBy(array('id' => $teamSeasonId));
        $sportStats = $teamSeason->getSport()->getSportStats();
        foreach ($sportStats as $stat)
        {
            if($stat->getSportStatGroup()){
                if($teamSportGroupId == $stat->getSportStatGroup()->getId() && !$stat->getIsCalculation() ){
                    $statGroupLists[$stat->getSportStatGroup()->getName()][$stat->getId()] = $stat->getAbbrev().'#'.$stat->getTooltip();    
                } 
            }                       
        }
        return $this->render('MSPBundle:Statistics:addSeasonStat.html.twig',
            array('teamSeasonId' => $teamSeasonId,'teamSeason' => $teamSeason, 'statGroupLists' => $statGroupLists,'seasonYear' => $teamSeason->getYear()));
    }

    /*
    *  isert data into database for the season 
    */
    function insertUserTeamSeasonAvgAction(){
        $request = $this->get('request');
        $formData = $request->request->get('msp_statistics_season_stat_type');
        $userTeamSeason = $this->getDoctrine()->getManager()->getRepository('MSPBundle:UserTeamSeason')->findOneBy(array('id' => $formData['userTeamSeason']));
        foreach($request->request->get('value') as $key => $value){                    
            $em = $this->getDoctrine()->getManager();
            $sportStat = $em->getRepository('MSPBundle:SportStat')->findOneBy(array('id' => $key));
            $seasonStat = new SeasonStatValue();            
            $seasonStat->setUser($this->getUser());
            $seasonStat->setValue($value);
            $seasonStat->setSportStat($sportStat);
            $seasonStat->setUserTeamSeason($userTeamSeason);            
            $em->persist($seasonStat);
            $em->flush();                
        }                
        return $this->redirect($this->generateUrl('msp_statistics'));         
    }

    /*
    *  update the user team season value
    */
    public function updateUserTeamSeasonStatsAction($id){

        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();

        $options = array('em' => $em);
        $value = $em->getRepository('MSPBundle:SeasonStatValue')->findOneBy(array('id' => $id));

        if (!$value) {
            $return = array("responseCode"=>200, "message"=>"data not found!");
        }

        $form = $this->createForm('msp_statistics_season_stat_type', $value, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                $return = array("responseCode"=>400, "message"=>"Updated succesfully !");
            }else{
                $return = array("responseCode"=>400, "message"=>"Error in update !");
            }
        }

        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));        
    }

    /*
    *  insert user team season value if not exist
    */
    public function insertUserTeamSeasonStatsAction(){

        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $value = new SeasonStatValue();
        $value->setUser($this->getUser());
        $form = $this->createForm('msp_statistics_season_stat_type', $value, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                $return = array("responseCode"=>400, "message"=>"Insert succesfully");
            }else{
                $return = array("responseCode"=>200, "message"=>"Something went wrong !");
            }
            $response = json_encode($return);//jscon encode the array
            return new Response($response, 200, array('Content-Type'=>'application/json'));          
        }
    }

    /*
    * add new UserTeam
    */
    public function addUserTeamSeasonAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();

        $defaultSport = $this->getDoctrine()->getRepository('MSPBundle:Sport')->findOneByName('Soccer');
        $defaultSportPositions = $defaultSport->getSportPositions();

        $userTeamSeason = new UserTeamSeason();
        $userTeamSeason->setUser($user);
        $options = array('em' => $em);
        $form = $this->createForm('msp_staistics_team_season_type', $userTeamSeason, $options);
        if ($request->getMethod() == 'POST')
        {
            $data = array();
            $form->submit($request);
            $validator = $this->get('validator');
            $errorList = $validator->validate($userTeamSeason);

            if ($form->isValid()){
                $em->persist($userTeamSeason);
                $em->flush();
                $data['error'] = false;
            }else{                
                $data['error'] = true;
                $data['msg'] = $errorList[0]->getMessage();         
            }            
            $response = new Response(json_encode($data));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }
        return $this->render('MSPBundle:Statistics:addTeamSeason.html.twig', 
            array('form' => $form->createView(),
                'options' => array(
                    'defaultSport' => $defaultSport, 
                    'defaultSportPositions' => $defaultSportPositions,
                )
            )
        );
    }


    /*
    *  open edit form to edit the user game stat value
    */
    public function editUserGameStatAction($gameId, $sportGroupId){

        // echo $gameId .'###'.$sportGroupId; die;

        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();

        $userId = $user->getId();

        $options = array('em' => $em);
        $updateForms = array();
        $newForms = array();

        $game = $em->getRepository('MSPBundle:Game')->findOneBy(array('id' => $gameId));

        $sportStats = $game->getSport()->getSportStats();

        foreach ($sportStats as $stat){
            if($stat->getSportStatGroup()){
                if($sportGroupId == $stat->getSportStatGroup()->getId() && !$stat->getIsCalculation()){
                    $value = $this->getDoctrine()->getRepository('MSPBundle:GameStatValue')->getStatValueForGame($this->getUser(), $stat, $game);
                    $new = false;
                    if($value == null){
                        $value = new GameStatValue();
                        $value->setSportStat($stat);
                        $value->setUser($this->getUser());
                        $value->setGame($game);
                        $new = true;
                    }
                    $form = $this->createForm('msp_user_game_stat_type', $value, $options);
                    if(!$new){
                        $updateForms[] = $form->createView();
                    }
                    else{
                        $newForms[] = $form->createView();
                    }
                } 
            }                       
        }
        return $this->render('MSPBundle:Statistics:editGameStat.html.twig',
            array('game' => $game, 'updateForms' => $updateForms, 'newForms' => $newForms));
    }

    /*
    *  update the user game stat value
    */
    function updateUserGameStatValueAction($id){
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();

        $options = array('em' => $em);
        $value = $em->getRepository('MSPBundle:GameStatValue')->findOneBy(array('id' => $id));

        if (!$value) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !");
        }
        
        $form = $this->createForm('msp_user_game_stat_type', $value, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                $return = array("responseCode"=>400, "message"=>"Updated succesfully");
            }else{
                $return = array("responseCode"=>400, "message"=>"Error in update !");
            }
        }
        $response = json_encode($return); //jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }

    /*
    *  insert user game stat value if not exist
    */
    function insertUserGameStatValueAction(){
        $request = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $options = array('em' => $em);
        $value = new GameStatValue();
        $value->setUser($this->getUser());
        $form = $this->createForm('msp_user_game_stat_type', $value, $options);

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($value);
                $em->flush();
                $return = array("responseCode"=>400, "message"=>"Insert succesfully");
            }else{
                $return = array("responseCode"=>200, "message"=>"Something went wrong !");
            }
            $response = json_encode($return);//jscon encode the array
            return new Response($response, 200, array('Content-Type'=>'application/json'));          
        }
    }

    /*
     * show add season game stat form in popup
    */
    public function ajaxShowUserSeasonGamesAction($teamSeasonId, $teamSportGroupId){
        
        $user = $this->getUser();
        $myDefaultTeam = $this->getDoctrine()->getRepository('MSPBundle:User')->getMainTeamForUser($user);
        $userTeams = $this->getUser()->getMyTeamOptions();
        $teamSeason = $this->getDoctrine()->getRepository('MSPBundle:UserTeamSeason')->find(array('id' => $teamSeasonId));
        $sportStats = $teamSeason->getSport()->getSportStats();
        $statGroupLists = array();
        foreach ($sportStats as $stat){
            if($stat->getSportStatGroup()){
                if(!$stat->getIsCalculation()){/*$teamSportGroupId == $stat->getSportStatGroup()->getId() && */
                    $statGroupLists[$stat->getSportStatGroup()->getName()][$stat->getId()] = $stat->getAbbrev().'#'.$stat->getTooltip();    
                }
            }               
        }
        return $this->render('MSPBundle:Statistics:addGameStat.html.twig',
            array(
                'myDefaultTeam' => $myDefaultTeam,
                'userTeams' => $userTeams,
                'statGroupLists' => $statGroupLists,
                'seasonYear' => $teamSeason->getYear(),
                'teamId' => $teamSeason->getTeam()->getId(),
                'teamSportGroupId' => $teamSportGroupId,
                'teamSeasonId' => $teamSeasonId
            )
        );
    }

    /*
    * function to add user season games 
    */
    public function addUserSeasonGamesAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $user = $this->getUser();
        if ($request->getMethod() == 'POST'){     

            $teamSportGroupId = $request->get('teamSportGroupId');
            $teamSeasonId = $request->get('teamSeasonId');
            $datetimeStart = $request->get('datetimeStart');
            $points1 = $request->get('points1');
            $points2 = $request->get('points2');

            $homeTeam = $this->getDoctrine()->getRepository('MSPBundle:Team')->find($request->get('homeTeam'));
            $awayTeam = $this->getDoctrine()->getRepository('MSPBundle:Team')->find($request->get('awayTeam'));
            $teamSeason = $this->getDoctrine()->getRepository('MSPBundle:UserTeamSeason')->find(array('id' => $teamSeasonId));

            $sport = $teamSeason->getSport();
            $game  = new Game();
            $game->setDatetimeStart(new \DateTime($datetimeStart));
            $game->setCreator($user);
            $game->setSport($sport);
            $game->setPoints1($points1);
            $game->setPoints2($points2);
            $game->setUserTeamSeason($teamSeason);
            $game->setHomeTeam($homeTeam);
            $game->setAwayTeam($awayTeam);

            $em->persist($game);
            $em->flush();  
            foreach($request->get('value') as $key => $value){
                $em = $this->getDoctrine()->getManager();
                $sportStat = $this->getDoctrine()->getRepository('MSPBundle:SportStat')->find(array('id' => $key));
                $value = ($value==null)?0:$value;
                $gameStatValue = new GameStatValue();
                $gameStatValue->setSportStat($sportStat);
                $gameStatValue->setGame($game);
                $gameStatValue->setUser($user);
                $gameStatValue->setValue($value);
                $em->persist($gameStatValue);
                $em->flush(); 
            }
            return $this->redirect($this->generateUrl('msp_statistics'));
        }        
    }

    /*
    * function to show game stat value in poup to enabled or disabled graph
    */
    public function ajaxShowUserGameStatBySeasonAction($teamSeasonId, $teamSportGroupId){
        $user = $this->getUser();
        $teamSeason = $this->getDoctrine()->getRepository('MSPBundle:UserTeamSeason')->find(array('id' => $teamSeasonId));
        $teamSportGroup = $this->getDoctrine()->getRepository('MSPBundle:SportStatGroup')->find(array('id' => $teamSportGroupId));
        // $statGroupLists = array();
        if($teamSeason->getSport()){
            foreach ($teamSeason->getSport()->getSportStats() as $stat){
                if($stat->getSportStatGroup()){
                    if($teamSportGroupId == $stat->getSportStatGroup()->getId()){      
                        // $statGroupLists[$stat->getId()] = $stat->getAbbrev();   
                        $sportStat = $this->getDoctrine()->getRepository('MSPBundle:SportStat')->find(array('id' => $stat->getId()));
                        if(!$sportStat->getIsCalculation()){
                            $userSeasonGameStatValue = $this->getDoctrine()->getRepository('MSPBundle:UserSeasonGameStatValue')->findBy(array('user'=>$user, 'userTeamSeason'=>$teamSeason, 'sportStatGroup'=>$teamSportGroup, 'sportStat' => $sportStat));
                            if(!$userSeasonGameStatValue){
                                $em = $this->getDoctrine()->getManager();
                                $userSeasonGameStatValue = new UserSeasonGameStatValue();
                                $userSeasonGameStatValue->setUser($user);
                                $userSeasonGameStatValue->setUserTeamSeason($teamSeason);
                                $userSeasonGameStatValue->setSportStatGroup($teamSportGroup);
                                $userSeasonGameStatValue->setSportStat($sportStat);
                                $userSeasonGameStatValue->setIsStatus(0);
                                $em->persist($userSeasonGameStatValue);
                                $em->flush(); 
                            }  
                        }
                    }
                }                  
            }
        }
        
        $statGroupLists = $this->getDoctrine()->getRepository('MSPBundle:UserSeasonGameStatValue')->findBy(array('user'=>$user, 'userTeamSeason'=>$teamSeason, 'sportStatGroup'=>$teamSportGroup));

        return $this->render('MSPBundle:Statistics:showGameStatListBySeason.html.twig',
            array(
                'statGroupLists' => $statGroupLists,
            )
        );
    }

    /*
    * function to update status of user season stat value 
    */
    public function updateSeasonGameStatValueAction()
    {
        // get user season game id & value
        $request    = $this->get('request');
        $seasonGameId   = $request->get('season_game_id');
        $value   = $request->get('value');
        $value   = ($value == 0 || $value == null) ? 1 : 0;

        // get key measurable object
        $em = $this->getDoctrine()->getManager();
        $userSeasonGameStatValue = $em->getRepository('MSPBundle:UserSeasonGameStatValue')->find($seasonGameId);

        if (!$userSeasonGameStatValue) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !", "value" => $request->get('value'));
        }

        if ($request->getMethod() == 'POST') {
            $userSeasonGameStatValue->setIsStatus($value);
            $em->flush();
            $return = array("responseCode"=>400, "message"=>"Updated value succesfully", "value" => $value);
        }
        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }

    /*
    * function to show season stat value in poup to enabled or disabled graph
    */
    public function ajaxShowUserSeasonStatBySportAction($teamSeasonId, $sportId){
        $user = $this->getUser();
        $sports = $this->getDoctrine()->getRepository('MSPBundle:Sport')->find(array('id' => $sportId));
        $userTeamSeason = $this->getDoctrine()->getRepository('MSPBundle:UserTeamSeason')->find(array('id' => $teamSeasonId));

        $sportStats = $this->getDoctrine()->getRepository('MSPBundle:SportStat')->findBy(array('sport' => $sportId));

        foreach($sportStats as $sportStat){
            if(!$sportStat->getIsCalculation()){
                $userSeasonStatValue = $this->getDoctrine()->getRepository('MSPBundle:UserSeasonStatValue')->findBy(array('user'=>$user, 'team' => $userTeamSeason->getTeam(), 'sportStatGroup' => $sportStat->getSportStatGroup(), 'sportStat'=>$sportStat));
                if(!$userSeasonStatValue){
                    $em = $this->getDoctrine()->getManager();
                    $userSeasonStatValue = new UserSeasonStatValue();
                    $userSeasonStatValue->setUser($user);
                    $userSeasonStatValue->setTeam($userTeamSeason->getTeam());
                    $userSeasonStatValue->setSportStatGroup($sportStat->getSportStatGroup());
                    $userSeasonStatValue->setSportStat($sportStat);
                    $userSeasonStatValue->setIsStatus(0);
                    $em->persist($userSeasonStatValue);
                    $em->flush(); 
                }
            }            
        }

        $seasonGroupLists = $this->getDoctrine()->getRepository('MSPBundle:UserSeasonStatValue')->findBy(array('user'=>$user, 'team'=>$userTeamSeason->getTeam()));

        return $this->render('MSPBundle:Statistics:showSeasonStatList.html.twig',
            array(
                'seasonGroupLists' => $seasonGroupLists,
            )
        );
    }


        /*
    * function to update status of user season status value 
    */
    public function updateSeasonStatValueAction()
    {
        // get user season game id & value
        $request    = $this->get('request');
        $seasonId   = $request->get('season_id');
        $value   = $request->get('value');
        $value   = ($value == 0 || $value == null) ? 1 : 0;

        // get key measurable object
        $em = $this->getDoctrine()->getManager();
        $userSeasonStatValue = $em->getRepository('MSPBundle:UserSeasonStatValue')->find($seasonId);

        if (!$userSeasonStatValue) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !", "value" => $request->get('value'));
        }

        if ($request->getMethod() == 'POST') {
            $userSeasonStatValue->setIsStatus($value);
            $em->flush();
            $return = array("responseCode"=>400, "message"=>"Updated value succesfully", "value" => $value);
        }
        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }
}