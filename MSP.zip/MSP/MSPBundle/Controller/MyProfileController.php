<?php

namespace MSP\MSPBundle\Controller;

use MSP\MSPBundle\Form\GameStatsValuesFormType;
use MSP\MSPBundle\Form\WallType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use MSP\MSPBundle\Entity;
use MSP\MSPBundle\Entity\UserTeamSeason;
use MSP\MSPBundle\Entity\KeyMeasurableValue;
use MSP\MSPBundle\Entity\Game;
use MSP\MSPBundle\Entity\Meet;
use MSP\MSPBundle\Entity\WallPost;
use MSP\MSPBundle\Entity\WallComment;
use MSP\MSPBundle\Entity\GameStatValue;
use MSP\MSPBundle\Entity\SeasonStatValue;
use MSP\MSPBundle\Admin;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use MSP\MSPBundle\Form\ProfileInformationType;
use MSP\MSPBundle\Form\CoachInformationType;
use MSP\MSPBundle\Form\FanInformationType;
use MSP\MSPBundle\Form\AcademicInfoType;
use MSP\MSPBundle\Form\GameType;
use MSP\MSPBundle\Form\MeetType;
use MSP\MSPBundle\Form\GameStatFormType;
use MSP\MSPBundle\Form\KeyMeasurablesType;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use Symfony\Component\Translation\Exception\NotFoundResourceException;
use Application\Sonata\MediaBundle\Entity\Media;
use Symfony\Component\Form\DataTransformerInterface;
use Sonata\Bundle\DemoBundle\Model\MediaPreview;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\Normalizer\GetSetMethodNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Validator\Constraints\DateTime;

use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;

class MyProfileController extends Controller implements InitializableControllerInterface
{

    private $user;

    public function initialize(Request $request, SecurityContextInterface $security_context)
    {
        if (!$user = $this->getUser()) {
            return true;
        }else{
            return false;
        }
    }

    /* Get user personal information details */
	public function personalInformationAction(Request $request)
    {
        $isNew = false;
        $session = $this->container->get('session');
        if($session->get('register')){
            $isNew = true;
        }

        $userManager = $this->container->get('fos_user.user_manager');
        $user = $this->getUser();
        if($user->getIsFirstTimeUser()){
            $em = $this->getDoctrine()->getManager();
            $session = $this->get('session');
            $session->set('activeTour', true);
            $user->setIsFirstTimeUser(false);
            $em->persist($user);
            $em->flush();
        }
        $form = new ProfileInformationType();
        $user->setImage($user->getImage());
        $form = $this->createForm($form, $user);
        $request = $this->get('request');
        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($user);
                $em->flush();
                return $this->redirect($this->generateUrl('msp_dashboard_team_information'));
            }
        }
        return $this->render('MSPBundle:MyProfile:personalInformation.html.twig',
            array('form' => $form->createView(), 'user' => $user, 'isNew' => $isNew));
    }

    /* Get user team information details */
    public function teamInformationAction()
    {
        $isNew = false;
        $session = $this->container->get('session');
        if($session->get('register')){
            $isNew = true;
        }
        $em = $this->getDoctrine()->getManager();
        $userManager = $this->container->get('fos_user.user_manager');
        $user = $this->getUser();
        // default sport & sportPosition values
        $defaultSport = $this->getDoctrine()->getRepository('MSPBundle:Sport')->findOneByName('Soccer');
        $defaultSportPositions = $defaultSport->getSportPositions();
        $userTeamSeason = new UserTeamSeason();
        $userTeamSeason->setUser($user);
        $options = array('em' => $em);
        $form = $this->createForm('msp_my_teams', $userTeamSeason, $options);
        $request = $this->get('request');
        $userTeamSeasons = $this->getUser()->getUserTeamSeason();
        $userTeamSeasonForms = array();

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($userTeamSeason);
                $em->flush();
                $this->get('session')->getFlashBag()->add(
                    'notice',
                    'Your entry was added!'
                );
            }
            else{
                $this->get('session')->getFlashBag()->add(
                    'invalid',
                    'Your entry was invalid.'
                );
            }
        }

        foreach ($userTeamSeasons as $userTeamSeason){
            $sport_id = $userTeamSeason->getSport()->getId();
            $options['sport_id'] = $sport_id;
            $userTeamSeasonForms[$userTeamSeason->getId()] = $this->createForm('msp_my_teams', $userTeamSeason, $options)->createView();
        }

        return $this->render('MSPBundle:MyProfile:myTeamInformation.html.twig', array(
                'form' => $form->createView() , 
                'userTeamSeasonForms' => $userTeamSeasonForms, 
                'isNew' => $isNew,
                'options' => array(
                    'defaultSport' => $defaultSport, 
                    'defaultSportPositions' => $defaultSportPositions,
                )
            )
        );
    }

    /* Get user academic information details */
    public function academicInformationAction()
    {
        $isNew = false;
        $session = $this->container->get('session');
        if($session->get('register')){
            $isNew = true;
        }
        $user = $this->getUser();
        $form = new AcademicInfoType();
        $form = $this->createForm($form, $user);
        $request = $this->get('request');

        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em = $this->getDoctrine()->getManager();
                $em->persist($user);
                $em->flush();
                return $this->redirect($this->generateUrl('my_sport_page_athlete', array('slug' => $user->getSlug())));
            }
        }
        return $this->render('MSPBundle:MyProfile:myAcademicInformation.html.twig',
            array('form' => $form->createView(), 'isNew' => $isNew));
    }

    /* Function to add user team */
    public function addMyTeamAction()
    {
        $em = $this->getDoctrine()->getManager();

        $userTeamSeason = new UserTeamSeason();
        $userTeamSeason->setUser($this->getUser());
        $options = array('em' => $em);

        $form = $this->createForm('msp_my_teams', $userTeamSeason, $options);
        $request = $this->get('request');
        $myTeams = $request->get('msp_my_teams');

        if(!isset($myTeams['teamName']) || $myTeams['teamName'] == null){
            $this->get('session')->getFlashBag()->add(
                'error',
                'Please add team name !'
            );
            return $this->redirect($this->generateUrl('msp_dashboard_team_information'));      
        }
        
        if ($request->getMethod() == 'POST'){
            $form->submit($request);
            if ($form->isValid()){
                $em->persist($userTeamSeason);
                $em->flush();
                $this->get('session')->getFlashBag()->add(
                    'notice',
                    'Your entry was added!'
                );
            }
        }
        $sport_id = $userTeamSeason->getSport()->getId();
        $options['sport_id'] = $sport_id;
        $userTeamSeasonForm = $this->createForm('msp_my_teams', $userTeamSeason, $options)->createView();
        return $this->redirect($this->generateUrl('msp_dashboard_team_information'));
    }

    /* Function to delete user team by id */
    public function deleteMyTeamAction($id)
    {
        $request    = $this->get('request');
        $em = $this->getDoctrine()->getManager();
        $myTeam = $em->getRepository('MSPBundle:UserTeamSeason')->findOneBy(array('id' => $id));

        if (!$myTeam) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !");
        }
        if ($request->getMethod() == 'GET' && $myTeam) {
            if($myTeam->getUser()->getId() !== $this->getUser()->getId()){
                $return = array("responseCode"=>200, "message"=>"Something went wrong !");
            }
            $em->remove($myTeam);
            $em->flush();
            $return = array("responseCode"=>400, "message"=>"team removed successfully");
        }      
        $response = json_encode($return); //json encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }
}