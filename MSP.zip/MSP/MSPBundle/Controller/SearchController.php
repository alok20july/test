<?php
namespace MSP\MSPBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use MSP\MSPBundle\Entity;
use MSP\MSPBundle\Entity\User;
use MSP\MSPBundle\Entity\Sport;
use MSP\MSPBundle\Entity\School;
use MSP\MSPBundle\Entity\SchoolRepository;
use MSP\MSPBundle\Entity\UserTeamSeason;
use MSP\MSPBundle\Entity\Connection;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;


class SearchController extends Controller // implements InitializableControllerInterface
{

    private $user;

    /*public function initialize(Request $request, SecurityContextInterface $security_context){
        if (!$user = $this->getUser()) {
            return true;
        }else{
            return false;
        }
    }*/

    public  function indexAction(Request $request){

        $user = $this->getUser();
        if($user)
            $userId = $user->getId();
        else
            $userId = null;

        $users = null;
        $status = false;
        $search = false;
        $advanceSearch = array();
        $simpleSearch = array();
        $em     = $this->getDoctrine()->getManager();
        if ($request->getMethod() == 'POST'){ 
            if($request->get('by_type') == 'simple'){
                $order_by    = $request->get('order_by');
                $users = $em->getRepository('MSPBundle:User')->searchUserByName($request->get('search_by_name'), $userId);
                $search = 'simple_search';
                $simpleSearch = array(
                    'name' => $request->get('search_by_name')
                );
            }
            else{
                $class      = $request->get('search_by_class');
                $sport      = $request->get('search_by_sport');
                $position   = $request->get('search_by_position');
                $sex        = $request->get('search_by_sex');
                $min_age    = $request->get('search_by_min_age');
                $max_age    = $request->get('search_by_max_age');
                $min_height = $request->get('search_by_min_height');
                $max_height = $request->get('search_by_max_height');
                $min_weight = $request->get('search_by_min_weight');
                $max_weight = $request->get('search_by_max_weight');
                $hand       = $request->get('search_by_hand');
                $school     = $request->get('search_by_school'); 
                $state      = $request->get('search_by_state');    
                $order_by   = $request->get('order_by');     

                $users = $em->getRepository('MSPBundle:User')->searchUserByList($userId, $class, $sport, $position, $sex, $min_age, $max_age, $min_height, $max_height, $min_weight, $max_weight, $hand, $school, $state, $order_by);
                $search = 'advanced_search';
                $advanceSearch = array(
                    'class' => $class, 
                    'sport' => $sport,
                    'position' => $position,
                    'sex' => $sex,
                    'min_age' => $min_age,
                    'max_age' => $max_age,
                    'min_height' => $min_height,
                    'max_height' => $max_height,
                    'min_weight' => $min_weight,
                    'max_weight' => $max_weight,
                    'hand' => $hand,
                    'school' => $school,
                    'state' => $state,
                );
            }
            $status = true;
        }
        
        // exit(\Doctrine\Common\Util\Debug::dump($users));
        $sports         = $em->getRepository('MSPBundle:Sport')->findAll();
        $sportPositions = $em->getRepository('MSPBundle:SportPosition')->findAll();
        $states         = $em->getRepository('MSPBundle:School')->getSchoolListByState();
        
        return $this->render('MSPBundle:Search:search.html.twig', array('sports' => $sports, 'sportPositions' => $sportPositions, 'states' => $states, 'users' => $users, 'status' => $status, 'search' => $search, 'advanceSearch' => $advanceSearch, 'simpleSearch' => $simpleSearch));
    }


    public function getPositionBySportAction(Request $request){
        $sportPositions = null;
        $sportId = $request->request->get('sport_id');        
        $sport = $this->getDoctrine()->getRepository('MSPBundle:Sport')->find($sportId);

        /* @var $sport Sport */
        if($sport){
            $sportPositions = $sport->getSportPositions();
        }
        return $this->render('MSPBundle:Search:renderSportPositions.html.twig',
            array('sportPositions' => $sportPositions));
    }

    public function createUserConnectionAction($userId){

        $requestedUser = $this->getUser();
        $requesterUser = $this->getDoctrine()->getRepository('MSPBundle:User')->find($userId);
        
        if (!$requestedUser || !$requesterUser) {
            $return = array("responseCode"=>200, "message"=>"Something went wrong !");
        }

        $result = $this->getDoctrine()->getRepository("MSPBundle:User")->getConnectToUser($requestedUser, $requesterUser);
        $username = $requesterUser->getFirstname().' '.$requesterUser->getLastname();
        if(!$result && $requestedUser !== $requesterUser){
            $this->getDoctrine()->getRepository('MSPBundle:User')->forceTeamConnect($requestedUser, $requesterUser);
            $return = array("responseCode"=>400, "message"=>"You are now connected to ".$username);
        }else{
            $return = array("responseCode"=>200, "message"=>"You are already connected to ".$username);
        }

        $response = json_encode($return);//jscon encode the array
        return new Response($response, 200, array('Content-Type'=>'application/json'));
    }
}