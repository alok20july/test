<?php
 
namespace MSP\MSPBundle\Model;
 
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\SecurityContextInterface;
 
/**
* @author Alok Kumar
*/
interface InitializableControllerInterface
{
	public function initialize(Request $request, SecurityContextInterface $security_context);
}