<?php
namespace MSP\MSPBundle\EventListener;
 
use Symfony\Component\HttpKernel\Event\FilterControllerEvent;
use Symfony\Component\Security\Core\SecurityContextInterface;
use MSP\MSPBundle\Model\InitializableControllerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;

/**
* @author Alok Kumar
*/
class BeforeControllerListener
{
	private $security_context;
	 
	public function __construct(SecurityContextInterface $security_context)
	{
		$this->security_context = $security_context;
	}
	 
	public function onKernelController(FilterControllerEvent $event)
	{
		$controller = $event->getController();
		 
		if (!is_array($controller)) {
			// not a object but a different kind of callable. Do nothing
			return;
		}
		 
		$controllerObject = $controller[0];		 
		// skip initializing for exceptions
		if ($controllerObject instanceof ExceptionController) {
			return;
		}
		 
		if ($controllerObject instanceof InitializableControllerInterface) {
			// this method is the one that is part of the interface.
			// $status  = $controllerObject->initialize($event->getRequest(), $this->security_context);
			$status  = $controllerObject->initialize($event->getRequest(), $this->security_context);
			if($status){
				$redirectUrl = $controllerObject->generateUrl('msp_homepage');
		    	$event->setController(function() use ($redirectUrl) {
			        return new RedirectResponse($redirectUrl);
			    });
			}else{
				return true;
			}	    	
		}
	}
}