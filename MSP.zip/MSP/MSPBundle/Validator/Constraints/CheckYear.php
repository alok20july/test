<?php
namespace MSP\MSPBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * @Annotation
 */
class CheckYear extends Constraint
{
    public $message1 = 'Year should be less than or equal to %string%';
    public $message2 = 'Year should be greater than or equal to %string%';

    public function validatedBy()
	{
    	return 'CheckYear';
	}
}
