<?php

namespace MSP\MSPBundle\Validator\Constraints;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

class CheckYearValidator extends ConstraintValidator {
    public function validate($value, Constraint $constraint) {

        if ($value > date('Y')) {
            $this->context->addViolation(
                $constraint->message1, array('%string%' => date('Y'))
            );
        }else if($value < (date('Y') - 10) ){
        	$this->context->addViolation(
                $constraint->message2, array('%string%' => date('Y') - 10)
            );
        }
    }
}
