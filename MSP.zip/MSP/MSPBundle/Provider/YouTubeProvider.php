<?php
/**
 * Created by JetBrains PhpStorm.
 * User: soumaouche
 * Date: 5/9/14
 * Time: 9:25 PM
 * To change this template use File | Settings | File Templates.
 */

namespace MSP\MSPBundle\Provider;

use Sonata\MediaBundle\Model\MediaInterface;
use Sonata\MediaBundle\Provider\YouTubeProvider as BaseYouTubeProvider;

class YouTubeProvider extends BaseYouTubeProvider{


    /**
     * {@inheritdoc}
     */
    protected function fixBinaryContent(MediaInterface $media)
    {
        if (!$media->getBinaryContent()) {
            return;
        }

        if (preg_match("/(?<=v(\=|\/))([-a-zA-Z0-9_]+)|(?<=youtu\.be\/)([-a-zA-Z0-9_]+)/", $media->getBinaryContent(), $matches)) {
            $media->setBinaryContent(isset($matches[3]) && $matches[3] ? $matches[3] : $matches[2]);
        }
    }
}